#!/usr/bin/env node
/*
 * Prüft, ob alle Datendienste der PilzKarte noch so antworten, wie die App es erwartet.
 * Aufruf (Node 18+, Internet nötig):  node tools/dienste-pruefen.js
 * Ergebnis: je Dienst OK / WARNUNG / FEHLER; Exit-Code 1 bei Fehlern.
 * Gedacht für die Claude-Routine („Claude nach Neuigkeiten suchen lassen“) und für Entwickler.
 */
"use strict";
const fs = require("fs");
const path = require("path");

// Testpunkt: Wald im Spessart (Buche/Eiche/Kiefer), sicher in Deutschland
const P = { lat: 50.0012, lng: 9.4521 };
const UA = "PilzKarte-Dienstpruefung/1.0 (Wartung)";
const ergebnisse = [];

function bbox(d) { return [P.lng - d, P.lat - d, P.lng + d, P.lat + d].join(","); }
async function holen(url, opt) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), 25000);
  try {
    const r = await fetch(url, Object.assign({ headers: { "User-Agent": UA }, signal: ac.signal }, opt || {}));
    const text = await r.text();
    return { status: r.status, typ: r.headers.get("content-type") || "", text };
  } finally { clearTimeout(t); }
}
function lax(text) { return JSON.parse(String(text).replace(/\b-?NaN\b/g, "null")); }
function zahlAus(j) {
  const f = j && j.features && j.features[0];
  if (!f || !f.properties) return null;
  for (const k in f.properties) { const v = parseFloat(f.properties[k]); if (isFinite(v)) return v; }
  return null;
}
function gfi(base, layer, version) {
  const d = 0.0005;
  return base + "?service=WMS&version=1.1.1&request=GetFeatureInfo&layers=" + encodeURIComponent(layer) +
    "&query_layers=" + encodeURIComponent(layer) + "&styles=&srs=EPSG:4326&bbox=" + bbox(d) +
    "&width=11&height=11&x=5&y=5&info_format=application/json&feature_count=1";
}
async function pruefe(name, fn) {
  try {
    const r = await fn();
    ergebnisse.push({ name, stufe: r && r.stufe || "OK", info: r && r.info || "" });
  } catch (e) {
    ergebnisse.push({ name, stufe: "FEHLER", info: String(e && e.message || e).slice(0, 200) });
  }
}
function erwarte(bedingung, text) { if (!bedingung) throw new Error(text); }

(async () => {
  // ---------- Thünen ----------
  const THUENEN = "https://atlas.thuenen.de/geoserver/wms";
  await pruefe("Thünen Boden-pH 0–30 cm", async () => {
    const r = await holen(gfi(THUENEN, "geonode:pH_map_0_30"));
    erwarte(r.status === 200, "HTTP " + r.status);
    const v = zahlAus(lax(r.text));
    erwarte(v != null && v > 2 && v < 11, "kein pH-Wert am Testpunkt (Antwort: " + r.text.slice(0, 120) + ")");
    return { info: "pH " + v.toFixed(2) };
  });
  await pruefe("Thünen Boden-pH 30–100 cm", async () => {
    const r = await holen(gfi(THUENEN, "geonode:pH_map_30_100"));
    erwarte(r.status === 200, "HTTP " + r.status);
    const v = zahlAus(lax(r.text));
    erwarte(v != null, "kein Wert");
    return { info: "pH " + v.toFixed(2) };
  });
  await pruefe("Thünen Baumarten 2017/18", async () => {
    const r = await holen(gfi(THUENEN, "geonode:Dominant_Species_Class"));
    erwarte(r.status === 200, "HTTP " + r.status);
    return { info: "Wert " + zahlAus(lax(r.text)) };
  });

  // ---------- DLR ----------
  const DLR = "https://geoservice.dlr.de/eoc/land/wms";
  await pruefe("DLR Baumarten 2022", async () => {
    const r = await holen(gfi(DLR, "TREE_SPECIES_DE_2022"));
    erwarte(r.status === 200, "HTTP " + r.status);
    const v = zahlAus(lax(r.text));
    erwarte(v == null || (v >= 0 && v <= 9) || v === 666, "unerwarteter Wert " + v);
    return { info: "Wert " + v + " (0 Kiefer … 9 Sonstige, 666 Verlust)" };
  });
  await pruefe("DLR Waldverlust (FCCL)", async () => {
    const r = await holen(gfi(DLR, "FCCL_DE_P1M"));
    erwarte(r.status === 200, "HTTP " + r.status);
    return { info: "Wert " + zahlAus(lax(r.text)) + " (0 = intakt, 1–98 = Monat seit 09/2017)" };
  });
  await pruefe("DLR Capabilities (neue Versionen?)", async () => {
    const r = await holen(DLR + "?service=WMS&version=1.3.0&request=GetCapabilities");
    erwarte(r.status === 200, "HTTP " + r.status);
    const namen = Array.from(new Set((r.text.match(/<Name>([^<]*(TREE_SPECIES|FCCL)[^<]*)<\/Name>/g) || [])
      .map((x) => x.replace(/<\/?Name>/g, ""))));
    ["TREE_SPECIES_DE_2022", "FCCL_DE_P1M", "FCCL_DE_P1M_MASK"].forEach((n) => erwarte(namen.indexOf(n) >= 0, "Layer fehlt: " + n));
    const neu = namen.filter((n) => ["TREE_SPECIES_DE_2022", "FCCL_DE_P1M", "FCCL_DE_P1M_MASK"].indexOf(n) < 0);
    return neu.length ? { stufe: "WARNUNG", info: "weitere Layer – evtl. neuere Version: " + neu.join(", ") } : { info: namen.join(", ") };
  });

  // ---------- BGR ----------
  const BGR = "https://services.bgr.de/arcgis/rest/services";
  for (const id of [8, 7]) {
    await pruefe("BGR Gestein GÜK250 Layer " + id, async () => {
      const r = await holen(BGR + "/geologie/guek250/MapServer/" + id + "/query?geometry=" + P.lng + "," + P.lat +
        "&geometryType=esriGeometryPoint&inSR=4326&spatialRel=esriSpatialRelIntersects" +
        "&outFields=klartext_kurz,klartext,gkart_legtxt_stat,p_zusatz&returnGeometry=false&f=json");
      erwarte(r.status === 200, "HTTP " + r.status);
      const j = JSON.parse(r.text);
      erwarte(!j.error, "Fehler: " + JSON.stringify(j.error));
      const a = j.features && j.features[0] && j.features[0].attributes;
      if (id === 8) erwarte(a && a.klartext_kurz, "kein Gestein am Testpunkt");
      return { info: a ? String(a.klartext_kurz || "").slice(0, 80) : "keine Deckschicht (normal)" };
    });
  }
  await pruefe("BGR nutzbare Feldkapazität", async () => {
    const d = 0.01;
    const r = await holen(BGR + "/boden/nfkwe1000/MapServer/identify?geometry=" + P.lng + "," + P.lat +
      "&geometryType=esriGeometryPoint&sr=4326&layers=all&tolerance=1&mapExtent=" + bbox(d) +
      "&imageDisplay=400,400,96&returnGeometry=false&f=json");
    erwarte(r.status === 200, "HTTP " + r.status);
    const a = JSON.parse(r.text).results[0].attributes;
    const k = Object.keys(a).filter((x) => /pixel value/i.test(x))[0];
    erwarte(k, "Feld „Pixel Value“ fehlt: " + Object.keys(a).join(", "));
    return { info: k + " = " + a[k] };
  });
  await pruefe("BGR Karten (WMS)", async () => {
    for (const u of ["https://services.bgr.de/wms/geologie/guek250/", "https://services.bgr.de/wms/boden/nfkwe1000/"]) {
      const r = await holen(u + "?service=WMS&request=GetCapabilities");
      erwarte(r.status === 200 && /WMS_Capabilities|WMT_MS_Capabilities/.test(r.text), u + " antwortet nicht wie erwartet");
    }
  });

  // ---------- DWD ----------
  await pruefe("DWD Niederschlag (WMS)", async () => {
    const r = await holen("https://maps.dwd.de/geoserver/dwd/wms?service=WMS&version=1.3.0&request=GetCapabilities");
    erwarte(r.status === 200, "HTTP " + r.status);
    ["SF-Produkt", "RADOLAN-W4", "Niederschlagsradar"].forEach((n) =>
      erwarte(new RegExp("<Name>(dwd:)?" + n + "</Name>").test(r.text), "Layer fehlt: dwd:" + n));
  });

  // ---------- BfN ----------
  await pruefe("BfN Schutzgebiete", async () => {
    const base = "https://geodienste.bfn.de/ogc/wms/schutzgebiet";
    const r = await holen(base + "?SERVICE=WMS&VERSION=1.1.1&REQUEST=GetFeatureInfo&LAYERS=Naturschutzgebiete&QUERY_LAYERS=Naturschutzgebiete" +
      "&STYLES=&SRS=EPSG:4326&BBOX=" + bbox(0.0005) + "&WIDTH=11&HEIGHT=11&X=5&Y=5&INFO_FORMAT=application/geo%2Bjson&FEATURE_COUNT=1");
    erwarte(r.status === 200, "HTTP " + r.status);
    JSON.parse(r.text);
    const c = await holen(base + "?SERVICE=WMS&REQUEST=GetCapabilities");
    ["Naturschutzgebiete", "Nationalparke"].forEach((n) => erwarte(c.text.indexOf("<Name>" + n + "</Name>") >= 0, "Layer fehlt: " + n));
  });

  // ---------- Open-Meteo ----------
  await pruefe("Open-Meteo Wetter", async () => {
    const r = await holen("https://api.open-meteo.com/v1/forecast?latitude=50&longitude=9.5" +
      "&daily=precipitation_sum,temperature_2m_max,temperature_2m_min,et0_fao_evapotranspiration,wind_speed_10m_max" +
      "&hourly=soil_moisture_3_to_9cm,soil_moisture_9_to_27cm,relative_humidity_2m&past_days=92&forecast_days=8&timezone=Europe%2FBerlin");
    erwarte(r.status === 200, "HTTP " + r.status + " " + r.text.slice(0, 150));
    const j = JSON.parse(r.text);
    ["precipitation_sum", "temperature_2m_max", "temperature_2m_min", "et0_fao_evapotranspiration", "wind_speed_10m_max"]
      .forEach((k) => erwarte(j.daily && Array.isArray(j.daily[k]), "daily." + k + " fehlt"));
    ["soil_moisture_3_to_9cm", "soil_moisture_9_to_27cm", "relative_humidity_2m"]
      .forEach((k) => erwarte(j.hourly && Array.isArray(j.hourly[k]), "hourly." + k + " fehlt"));
    return { info: j.daily.time.length + " Tage" };
  });
  await pruefe("Open-Meteo Höhenmodell", async () => {
    const r = await holen("https://api.open-meteo.com/v1/elevation?latitude=" + P.lat + "&longitude=" + P.lng);
    const j = JSON.parse(r.text);
    erwarte(Array.isArray(j.elevation), "elevation fehlt");
    return { info: j.elevation[0] + " m" };
  });

  // ---------- GBIF ----------
  await pruefe("GBIF Pilzfunde", async () => {
    const j = new Date().getFullYear();
    const r = await holen("https://api.gbif.org/v1/occurrence/search?limit=0&kingdomKey=5&hasCoordinate=true&hasGeospatialIssue=false" +
      "&year=" + (j - 20) + "," + j + "&coordinateUncertaintyInMeters=0,1000&decimalLatitude=49.9,50.1&decimalLongitude=9.3,9.6");
    erwarte(r.status === 200, "HTTP " + r.status);
    const n = JSON.parse(r.text).count;
    erwarte(typeof n === "number", "count fehlt");
    const r2 = await holen("https://api.gbif.org/v1/occurrence/search?limit=1&scientificName=Boletus%20edulis&decimalLatitude=47,55&decimalLongitude=6,15");
    erwarte(JSON.parse(r2.text).count > 0, "Suche nach scientificName liefert nichts");
    return { info: n + " Pilzmeldungen im Testgebiet" };
  });

  // ---------- Nominatim ----------
  await pruefe("Nominatim Ortssuche", async () => {
    const r = await holen("https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=de&accept-language=de&q=Lohr%20am%20Main");
    erwarte(r.status === 200, "HTTP " + r.status);
    erwarte(JSON.parse(r.text).length > 0, "kein Treffer");
  });

  // ---------- Grundkarten ----------
  await pruefe("TopPlusOpen (BKG)", async () => {
    const r = await holen("https://sgx.geodatenzentrum.de/wmts_topplus_open/tile/1.0.0/web/default/WEBMERCATOR/10/347/538.png");
    erwarte(r.status === 200 && /image/.test(r.typ), "HTTP " + r.status + " " + r.typ);
  });

  // ---------- Luftbilder der Länder (aus app.js) ----------
  const appJs = fs.readFileSync(path.join(__dirname, "..", "app", "src", "main", "assets", "app.js"), "utf8");
  const re = /\{ land: "([^"]+)", url: "([^"]+)", layers: "([^"]+)"/g;
  let m;
  while ((m = re.exec(appJs))) {
    const [, land, url, layer] = m;
    await pruefe("Luftbild " + land, async () => {
      const r = await holen(url + (url.indexOf("?") >= 0 ? "&" : "?") + "SERVICE=WMS&REQUEST=GetCapabilities");
      erwarte(r.status === 200, "HTTP " + r.status);
      erwarte(r.text.indexOf("<Name>" + layer + "</Name>") >= 0,
        "Layer „" + layer + "“ nicht in den Capabilities. Vorhanden u. a.: " +
        (r.text.match(/<Name>[^<]{1,60}<\/Name>/g) || []).slice(0, 8).join(" ").replace(/<\/?Name>/g, ""));
    });
  }

  // ---------- Ausgabe ----------
  let fehler = 0;
  for (const e of ergebnisse) {
    if (e.stufe === "FEHLER") fehler++;
    console.log((e.stufe === "OK" ? "OK      " : e.stufe === "WARNUNG" ? "WARNUNG " : "FEHLER  ") + e.name + (e.info ? " – " + e.info : ""));
  }
  console.log("\n" + ergebnisse.length + " Prüfungen, " + fehler + " Fehler.");
  process.exit(fehler ? 1 : 0);
})();
