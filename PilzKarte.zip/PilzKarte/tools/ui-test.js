#!/usr/bin/env node
/*
 * Oberflächen-Test der PilzKarte im Browser – ohne Internet: alle Datendienste werden nachgebildet,
 * die Android-Brücke (AndroidBridge) wird simuliert.
 *
 * Einmalig:  npm i -D playwright   und   npx playwright install chromium
 * Aufruf:    node tools/ui-test.js            (Bildschirmfotos landen in tools/out/)
 * Exit-Code 1, wenn eine Prüfung fehlschlägt.
 */
"use strict";
const fs = require("fs");
const path = require("path");
const http = require("http");

let chromium;
try { ({ chromium } = require("playwright")); } catch (e) {
  console.error("Playwright fehlt: npm i -D playwright && npx playwright install chromium");
  process.exit(2);
}
const ASSETS = path.join(__dirname, "..", "app", "src", "main", "assets");
const OUT = path.join(__dirname, "out");
fs.mkdirSync(OUT, { recursive: true });
const PNG = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==", "base64");
const MIME = { ".html": "text/html", ".js": "application/javascript", ".css": "text/css", ".png": "image/png", ".svg": "image/svg+xml" };

const pruefungen = [];
function pruefe(name, ok, info) { pruefungen.push({ name, ok: !!ok, info: info || "" }); }

function iso(d) { return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0"); }
function wetterMock() {
  // 92 Tage zurück + 7 Tage Vorhersage: warme Phase vor 15–18 Tagen, dann Abkühlung mit Regen (Auslöser)
  const heute = new Date(); heute.setHours(12);
  const time = [], p = [], mx = [], mn = [], et = [], wind = [];
  for (let i = -92; i <= 7; i++) {
    time.push(iso(new Date(heute.getTime() + i * 864e5)));
    const alter = -i;
    p.push(alter === 5 ? 16 : alter === 12 ? 6 : alter > 0 && alter % 6 === 0 ? 2 : i === 2 ? 8 : 0.3);
    mx.push(alter >= 15 && alter <= 18 ? 28 : alter < 8 ? 17 : 21);
    mn.push(alter >= 15 && alter <= 18 ? 15 : 7);
    et.push(alter > 30 ? 3.2 : 1.6);
    wind.push(14);
  }
  const ht = [], s1 = [], s2 = [], rh = [];
  for (let i = 0; i < time.length; i++) for (let h = 0; h < 24; h++) {
    ht.push(time[i] + "T" + String(h).padStart(2, "0") + ":00");
    s1.push(0.2 + (i > 85 ? 0.05 : 0)); s2.push(0.24); rh.push(h < 8 ? 92 : 74);
  }
  return { daily: { time, precipitation_sum: p, temperature_2m_max: mx, temperature_2m_min: mn, et0_fao_evapotranspiration: et, wind_speed_10m_max: wind },
    hourly: { time: ht, soil_moisture_3_to_9cm: s1, soil_moisture_9_to_27cm: s2, relative_humidity_2m: rh } };
}

const server = http.createServer((req, res) => {
  const p = path.normalize(decodeURIComponent(req.url.split("?")[0])).replace(/^(\.\.[/\\])+/, "");
  const f = path.join(ASSETS, p === "/" ? "index.html" : p);
  if (!f.startsWith(ASSETS) || !fs.existsSync(f)) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { "Content-Type": MIME[path.extname(f)] || "application/octet-stream" });
  fs.createReadStream(f).pipe(res);
});

server.listen(0, "127.0.0.1", async () => {
  const basis = "http://127.0.0.1:" + server.address().port + "/index.html";
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 800 }, deviceScaleFactor: 2, hasTouch: true, isMobile: true,
    geolocation: { latitude: 49.955, longitude: 9.352 }, permissions: ["geolocation"] });
  await ctx.addInitScript(() => {
    const ablage = {}, geheim = {};
    window.__log = [];
    const log = (x) => window.__log.push(x);
    let sperre = false, schutz = false;
    window.AndroidBridge = {
      storeGet: (k) => (k in ablage ? ablage[k] : null),
      storeSet: (k, v) => { if (v == null) delete ablage[k]; else ablage[k] = v; },
      storeClear: () => { for (const k in ablage) delete ablage[k]; },
      appInfo: () => JSON.stringify({ versionCode: 42, versionName: "1.0.42" }),
      getSettings: () => JSON.stringify({ lock: sperre, secure: schutz, lockAvailable: true }),
      setAppLock: (on) => { log("lock:" + on); if (on) setTimeout(() => { sperre = true; window.__sperreErgebnis(true); }, 30); else sperre = false; return true; },
      cancelRequest: (id) => log("cancel:" + id),
      setSecureScreen: (on) => { schutz = on; log("secure:" + on); },
      setKeepScreenOn: (on) => log("wach:" + on),
      setSecret: (k, v) => { geheim[k] = v; log("secret:" + k); return true; },
      hasSecret: (k) => k in geheim,
      deleteSecret: (k) => { delete geheim[k]; },
      fireRoutine: (id, url, text) => { log("fire:" + url); setTimeout(() => window.__httpDone(id, 200, JSON.stringify({ type: "routine_fire", claude_code_session_url: "https://claude.ai/code/session_01X" })), 50); },
      cacheInfo: () => JSON.stringify({ dateien: 1234, bytes: 25 * 1048576 }),
      downloadTiles: (json) => { const n = JSON.parse(json).length; log("download:" + n); setTimeout(() => window.__offlineProgress(n, n, 0, true, false), 50); },
      cancelDownload: () => log("cancel"),
      clearTileCache: () => log("clearcache"),
      openWeb: (u) => log("web:" + u),
      openExternal: (u) => log("ext:" + u),
      saveFile: (n) => log("save:" + n)
    };
  });
  const page = await ctx.newPage();
  const fehler = [];
  page.on("pageerror", (e) => fehler.push("pageerror: " + e.message));
  page.on("console", (m) => { if (m.type() === "error" || /Content Security Policy|Refused/.test(m.text())) fehler.push("console: " + m.text()); });
  page.on("dialog", (d) => d.accept());
  let n = 0;
  const WETTER = JSON.stringify(wetterMock());
  await page.route(/^https:\/\//, (route) => {
    const u = route.request().url();
    n++;
    const json = (o) => route.fulfill({ contentType: "application/json", headers: { "Access-Control-Allow-Origin": "*" }, body: typeof o === "string" ? o : JSON.stringify(o) });
    if (u.includes("bfn.de") && u.includes("GetFeatureInfo")) return json({ features: [] });
    if (u.includes("/elevation")) {
      const cnt = new URL(u).searchParams.get("latitude").split(",").length, el = [];
      for (let i = 0; i < cnt; i++) { const k = i % 5; el.push(300 + (k === 1 ? -8 : k === 2 ? 8 : k === 3 ? 2 : k === 4 ? -2 : 0)); }
      return json({ elevation: el });
    }
    if (u.includes("api.gbif.org/v1/occurrence/search")) {
      const q = new URL(u).searchParams;
      if (q.get("limit") === "0") return json({ count: 60, results: [] });
      const la = q.get("decimalLatitude").split(",").map(Number), lo = q.get("decimalLongitude").split(",").map(Number), res = [];
      for (let i = 0; i < 12; i++) res.push({ decimalLatitude: la[0] + (la[1] - la[0]) * ((i * 37) % 100) / 100, decimalLongitude: lo[0] + (lo[1] - lo[0]) * ((i * 61) % 100) / 100, species: i % 2 ? "Cantharellus cibarius" : "Boletus edulis", eventDate: "2025-09-1" + (i % 9), datasetName: "iNaturalist", coordinateUncertaintyInMeters: 30 });
      return json({ results: res, count: 12 });
    }
    if (u.includes("geoservice.dlr.de") && u.includes("GetFeatureInfo")) {
      const v = u.includes("FCCL_DE_P1M_MASK") ? 3 : u.includes("FCCL_DE_P1M") ? (n % 9 === 0 ? 95 : 0) : [5, 1, 0, 666, "NaN", 6, 8][n % 7];
      return json('{"type":"FeatureCollection","features":[{"type":"Feature","properties":{"GRAY_INDEX":' + v + "}}]}");
    }
    if (u.includes("GetFeatureInfo")) return json({ features: [{ properties: { GRAY_INDEX: u.includes("Dominant") ? 3 : 4 + (n % 30) / 10 } }] });
    if (u.includes("guek250/MapServer/8/query") && u.includes("Envelope")) {
      const g = new URL(u).searchParams.get("geometry").split(",").map(Number), feats = [];
      const txt = ["Kalkstein, Mergelstein", "Buntsandstein", "Löss", "Granit", "<img src=x id=xss>", "unbekannt"];
      for (let i = 0; i < 6; i++) { const x0 = g[0] + (g[2] - g[0]) * i / 6, x1 = g[0] + (g[2] - g[0]) * (i + 1) / 6;
        feats.push({ attributes: { klartext_kurz: txt[i], klartext: txt[i] }, geometry: { rings: [[[x0, g[1]], [x1, g[1]], [x1, g[3]], [x0, g[3]], [x0, g[1]]]] } }); }
      return json({ features: feats });
    }
    if (u.includes("guek250/MapServer/8/query")) return json({ features: [{ attributes: { klartext_kurz: "Sandstein, Tonstein", klartext: "Sandstein, Tonstein", gkart_legtxt_stat: "Sedimentgestein" } }] });
    if (u.includes("guek250/MapServer/7/query")) return json({ features: [{ attributes: { klartext_kurz: "Löss, Lösslehm", klartext: "Löss, entkalkt" } }] });
    if (u.includes("identify")) return json({ results: [{ attributes: { "Classify.Pixel Value": "117,949997" } }] });
    if (u.includes("api.open-meteo.com/v1/forecast")) return json(WETTER);
    if (u.includes("nominatim")) return json([{ display_name: "Spessart", lat: "50.0", lon: "9.4", boundingbox: ["49.9", "50.1", "9.3", "9.5"] }]);
    if (u.includes("api.github.com")) return json({ tag_name: "v1.0.99", body: "## Neu\n- Test", assets: [{ name: "PilzKarte.apk", browser_download_url: "https://github.com/x/y/releases/download/v1.0.99/PilzKarte.apk" }] });
    return route.fulfill({ contentType: "image/png", body: PNG });
  });

  try {
    await page.goto(basis);
    await page.waitForTimeout(800);
    const u = await page.evaluate(() => [PK.monatAusIndex(1), PK.monatAusIndex(98)]);
    pruefe("Waldverlust-Monate", u[0] === "09/2017" && u[1] === "10/2025", u.join(" / "));

    // Standort-Analyse
    await page.evaluate(() => PK.map.setView([49.95, 9.35], 13));
    await page.mouse.click(200, 300);
    await page.waitForTimeout(1800);
    const detail = await page.$eval("#detailBody", (e) => e.innerText);
    pruefe("Analyse zeigt Punktzahl & Teile", /Wald & Baumart/.test(detail) && /Temperatur & Luft/.test(detail) && /Waldzustand/.test(detail), detail.slice(0, 80));
    await page.screenshot({ path: path.join(OUT, "detail.png") });

    // Scan
    await page.click("#bottomnav button[data-sheet=chancen]");
    await page.click("#btnScan");
    await page.waitForTimeout(4000);
    pruefe("Scan liefert Ergebnisse", /Beste Stellen/i.test(await page.$eval("#scanResults", (e) => e.innerText)));
    await page.screenshot({ path: path.join(OUT, "chancen.png") });

    // Ebenen & XSS
    await page.click("#bottomnav button[data-sheet=ebenen]");
    await page.check("input[data-ov=geoph]");
    await page.click("#bottomnav button[data-sheet=ebenen]");
    await page.evaluate(() => PK.map.setView([49.95, 9.35], 11));
    await page.waitForTimeout(1500);
    for (let x = 30; x < 380; x += 50) { await page.mouse.move(x, 250); await page.waitForTimeout(50); }
    pruefe("Kein eingeschleustes HTML (XSS)", !(await page.evaluate(() => !!document.getElementById("xss"))));
    pruefe("Legende mit Datenstand", /Stand:/.test(await page.$eval("#legendDock", (e) => e.innerText)));

    // Wissen
    await page.click("#bottomnav button[data-sheet=wissen]");
    await page.click("#sheet-wissen .seg button[data-tab=gift]");
    pruefe("Giftpilz-Karten", (await page.$$eval("#giftpilzListe .art", (l) => l.length)) >= 5);
    await page.screenshot({ path: path.join(OUT, "giftpilze.png") });
    await page.click("#bottomnav button[data-sheet=wissen]");

    // Ähnlichkeit (reine Logik)
    const sim = await page.evaluate(() => {
      const fp = { baum: "Buche", ph: 5.0, klasse: "sauer", nfk: 120, hoehe: 300, expo: 180, neigung: 6 };
      return [PK.aehnlich({ baum: { wald: true, art: "Buche" }, ph0: 5.2, nfk: 110, gelaende: { hoehe: 320, expo: 170, neigung: 5 } }, fp),
        PK.aehnlich({ baum: { wald: true, art: "Fichte" }, ph0: 7.5, nfk: 40, gelaende: { hoehe: 700, expo: 10, neigung: 8 } }, fp)];
    });
    pruefe("Ähnlichkeit zu Fundorten", sim[0] >= 80 && sim[1] <= 20, sim.join(" / "));

    // Rückweg mit Kompass
    await page.click("#bottomnav button[data-sheet=mehr]");
    await page.click("#btnAutoMerken");
    await page.waitForTimeout(800);
    await ctx.setGeolocation({ latitude: 49.965, longitude: 9.37 });
    await page.click("#btnRueck");
    await page.waitForTimeout(1500);
    await page.evaluate(() => { const ev = new Event("deviceorientationabsolute"); ev.absolute = true; ev.alpha = 90; window.dispatchEvent(ev); });
    await page.waitForTimeout(200);
    pruefe("Rückweg-Pfeil folgt dem Kompass", /rotate\(319deg\)/.test(await page.$eval("#rueckPill .pfeil", (e) => e.style.transform)));
    await page.screenshot({ path: path.join(OUT, "rueckweg.png") });
    await page.click("#rueckStop");

    // Offline, Updates, Claude
    await page.click("#bottomnav button[data-sheet=mehr]");
    await page.evaluate(() => PK.map.setView([49.95, 9.35], 14));
    await page.click("#btnOffline");
    await page.waitForTimeout(400);
    pruefe("Offline-Karten laden", /Fertig/.test(await page.$eval("#offlineProgress", (e) => e.innerText)));
    await page.click("#btnUpdateSuchen");
    await page.waitForTimeout(500);
    pruefe("Update-Prüfung", /v1\.0\.99/.test(await page.$eval("#updateErgebnis", (e) => e.innerText)));
    await page.evaluate(() => document.querySelectorAll("#sheet-mehr details").forEach((d) => { d.open = true; }));
    await page.fill("#routineUrl", "https://api.anthropic.com/v1/claude_code/routines/trig_01ABCdef/fire");
    await page.fill("#routineToken", "sk-ant-oat01-test");
    await page.click("#btnClaudeSpeichern");
    await page.waitForTimeout(200);
    pruefe("Claude eingerichtet", /Eingerichtet/.test(await page.$eval("#claudeStatus", (e) => e.innerText)));
    await page.click("#btnClaude");
    await page.waitForTimeout(400);
    pruefe("Claude gestartet", /Claude sucht jetzt/.test(await page.$eval("#updateErgebnis", (e) => e.innerText)));
    await page.screenshot({ path: path.join(OUT, "mehr.png") });
    const log = await page.evaluate(() => window.__log);
    pruefe("Sitzung wird geöffnet", log.some((x) => x === "ext:https://claude.ai/code/session_01X"));
    await page.check("#optSperre").catch(() => {});
    await page.waitForTimeout(200);
    pruefe("App-Sperre erst nach Bestätigung an", await page.$eval("#optSperre", (e) => e.checked && !e.disabled));
  } catch (e) {
    fehler.push("Test abgebrochen: " + e.message);
  }
  pruefe("Keine Skript- oder Sicherheitsfehler", fehler.length === 0, fehler.join(" | ").slice(0, 400));

  let schlecht = 0;
  for (const p of pruefungen) {
    if (!p.ok) schlecht++;
    console.log((p.ok ? "OK      " : "FEHLER  ") + p.name + (p.info ? " – " + p.info : ""));
  }
  console.log("\n" + pruefungen.length + " Prüfungen, " + schlecht + " Fehler. Bildschirmfotos: " + OUT);
  await browser.close();
  server.close();
  process.exit(schlecht ? 1 : 0);
});
