# Wissen & Datenquellen der PilzKarte

**Zuletzt geprüft: 2026-10-05** (Version 4)

Diese Datei sammelt alle Fakten, auf denen die App beruht. Die Claude-Routine prüft sie bei jedem
Lauf auf Neuigkeiten und hält sie aktuell. Technische Details zur Pflege: `CLAUDE.md`.

## 1. Datendienste

| Funktion | Anbieter | Adresse / Layer | Werte & Besonderheiten | Lizenz | Datenstand |
|---|---|---|---|---|---|
| Boden-pH 0–30 / 30–100 cm | Thünen-Institut | WMS `https://atlas.thuenen.de/geoserver/wms`, `geonode:pH_map_0_30`, `geonode:pH_map_30_100` | GetFeatureInfo (JSON) → pH als Zahl; eigene Farbskala per `SLD_BODY`, bei Fehler Original-Stil | CC BY 4.0 | Karte 2021, Messungen BZE II 2006–2018 |
| Baumarten 2022 | DLR (Earth Observation Center) | WMS `https://geoservice.dlr.de/eoc/land/wms`, `TREE_SPECIES_DE_2022` | 0 Kiefer, 1 Fichte, 2 Douglasie, 3 Lärche, 4 Tanne, 5 Buche, 6 Eiche, 7 Birke, 8 Erle, 9 Sonstige, 666 Kronendachverlust; `NaN` = kein Wald (App ersetzt `NaN` durch `null`) | siehe DLR | Sentinel-1/2 2022, 10 m |
| Waldverlust | DLR | `FCCL_DE_P1M`, Maske `FCCL_DE_P1M_MASK` | `NaN` kein Wald, 0 intakt, 1–98 = Monat des Verlusts (1 = 09/2017, 98 = 10/2025), letzte 2–3 Monate vorläufig. Maske: 1 dauerhaft, 2–4 vorübergehend. **In app.js: `FCCL_LETZTER_MONAT = 98`** | siehe DLR | 09/2017–10/2025 |
| Baumarten 2017/18 (Rückfall) | Thünen-Institut | `geonode:Dominant_Species_Class` | 2 Birke, 3 Buche, 4 Douglasie, 5 Eiche, 6 Erle, 8 Fichte, 9 Kiefer, 10 Lärche, 14 Tanne, 16/17 sonstige Laubbäume | CC BY 4.0 | 2017/18 |
| Gesteine (Karte) | BGR | WMS `https://services.bgr.de/wms/geologie/guek250/`, Layer `4` | Originalfarben der GÜK250 | © BGR | GÜK250 (2019) |
| Gesteine (Abfrage, pH-Einfärbung) | BGR | REST `https://services.bgr.de/arcgis/rest/services/geologie/guek250/MapServer/8` (Basis) und `/7` (Deckschicht) | Felder `klartext_kurz`, `klartext`, `gkart_legtxt_stat`, `p_zusatz`; Zuordnung zu Gesteinen über Muster in `gesteine.js` (Reihenfolge der Nennung zählt) | © BGR | GÜK250 (2019) |
| Nutzbare Feldkapazität | BGR | WMS `https://services.bgr.de/wms/boden/nfkwe1000/` Layer `0`; REST `…/boden/nfkwe1000/MapServer/identify` | Feld `Classify.Pixel Value` in mm, **Komma als Dezimaltrenner** | © BGR | 2014 |
| Niederschlag | DWD | WMS `https://maps.dwd.de/geoserver/dwd/wms`: `dwd:SF-Produkt` (24 h), `dwd:RADOLAN-W4` (30 Tage), `dwd:Niederschlagsradar` | Live-Daten, werden nicht offline gespeichert | DWD (frei) | aktuell |
| Schutzgebiete | BfN | WMS `https://geodienste.bfn.de/ogc/wms/schutzgebiet`, `Naturschutzgebiete`, `Nationalparke` | GetFeatureInfo `application/geo+json` | © BfN | laufend |
| Wetter | Open-Meteo | `https://api.open-meteo.com/v1/forecast` | daily: `precipitation_sum`, `temperature_2m_max/min`, `et0_fao_evapotranspiration`, `wind_speed_10m_max`; hourly: `soil_moisture_3_to_9cm`, `soil_moisture_9_to_27cm`, `relative_humidity_2m`; `past_days=92`, `forecast_days=8`; Koordinaten immer auf 0,1° gerundet | CC BY 4.0 | aktuell |
| Höhen / Hanglage | Open-Meteo | `https://api.open-meteo.com/v1/elevation` | bis 100 Punkte je Abfrage (90-m-Modell) | CC BY 4.0 | – |
| Pilzfunde | GBIF | `https://api.gbif.org/v1/occurrence/search` | `scientificName` (mehrfach), `year=J-20,J`, `coordinateUncertaintyInMeters=0,1000`, `hasGeospatialIssue=false`; Beobachtungsdichte: `kingdomKey=5&limit=0` → `count` | je Datensatz | laufend |
| Ortssuche | Nominatim (OSM) | `https://nominatim.openstreetmap.org/search` | max. 1 Anfrage/s, eindeutiger User-Agent | ODbL | laufend |
| Grundkarte amtlich | BKG TopPlusOpen | `https://sgx.geodatenzentrum.de/wmts_topplus_open/tile/1.0.0/web/default/WEBMERCATOR/{z}/{y}/{x}.png` | Quellenvermerk „Kartendarstellung: © BKG (Jahr) dl-de/by-2-0“; **Speichern/Vorab-Laden erlaubt** | dl-de/by-2-0 | laufend |
| Grundkarten OSM | OpenStreetMap, OpenTopoMap | Kachel-Server | Kein Vorab-Laden (Tile Usage Policy); Zwischenspeichern angesehener Kacheln ok (App: 7 Tage frisch) | ODbL / CC BY-SA | laufend |
| Luftbilder | Vermessungsverwaltungen der 16 Länder | Liste `DOP_LAENDER` in app.js (WMS je Land) | Hamburg-Layername `wms_dop_zeitreihe_unbelaubt` **unsicher** – mit `tools/dienste-pruefen.js` prüfen | dl-de/by-2-0 | je Land 1–3 Jahre |
| Satellit | Esri World Imagery | ArcGIS-Kacheldienst | nicht offline gespeichert | Esri-Bedingungen | unterschiedlich |
| Updates | GitHub | `https://api.github.com/repos/<Projekt>/releases/latest` | Tag `v1.0.<Laufnummer>` = versionCode | – | – |
| Claude-Routine | Anthropic | `POST https://api.anthropic.com/v1/claude_code/routines/<id>/fire` | Header `Authorization: Bearer sk-ant-oat01-…`, `anthropic-version: 2023-06-01`, `anthropic-beta: experimental-cc-routine-2026-04-01` (optional); Body `{"text": …}` (max. 65 536 Zeichen) → `claude_code_session_url`; max. 30 Starts/Stunde je Routine; Text kommt als „untrusted“ in `<routine-fire-payload>` an | – | Forschungsvorschau |

## 2. Fachwissen in der Bewertung

- **Mykorrhiza:** Steinpilz, Pfifferling, Maronen, Täublinge usw. brauchen lebende Partnerbäume (Fichte, Kiefer, Buche, Eiche, Birke, Tanne, Douglasie, Lärche). Auf frischen Kahlflächen (Borkenkäfer, Sturm, Dürre seit 2018) fehlen sie weitgehend; Ränder zum gesunden Wald bleiben interessant.
- **Regen:** Etwa 1–3 Wochen nach ergiebigem Regen (≥ 10 l/m² am Tag) erscheinen Fruchtkörper; > 80 mm in einer Woche hemmen eher. Nach langer Trockenheit braucht der Boden mehrere Regentage mit zusammen deutlich über 30 l/m².
- **Auslöser:** Abkühlung um einige Grad nach einer warmen Phase (≥ 25 °C) mit Regen gilt bei Sammlern als Startsignal für Steinpilz-Schübe (ca. eine Woche später).
- **Temperatur:** Tagesmittel 10–18 °C optimal; Frostnächte beenden die Saison der meisten Arten (Ausnahmen: Austernseitling, Samtfußrübling, Trompetenpfifferling).
- **Luft:** hohe Luftfeuchte und wenig Wind halten Fruchtkörper frisch; große Tag-Nacht-Schwankungen trocknen den Oberboden.
- **Gelände:** bei Hitze/Trockenheit Nord-/Osthänge und Senken, in der kühlen Jahreszeit Südhänge.
- **Boden-pH:** 4–6 ideal für viele Speisepilze; Kalkböden (> 7) mit eigenem Artenspektrum.
- **Cäsium-137 (BfS-Pilzbericht 2026):** Semmel-Stoppelpilze teils über 2.000 Bq/kg (Bayerischer Wald), Maronen-Röhrlinge und Trompetenpfifferlinge über 1.000 Bq/kg; Handelsgrenzwert 600 Bq/kg; maßvoller Verzehr laut BfS unbedenklich.
- **Giftnotruf-Zentralen:** Berlin 030 19240, Bonn 0228 19240, Erfurt 0361 730730, Freiburg 0761 19240, Göttingen 0551 19240, Mainz 06131 19240, München 089 19240 (in `pilze.js`).

## 3. Technik-Stand

- **Android:** compileSdk/targetSdk 34, minSdk 26, keine AndroidX-Bibliotheken. Google-Play-Vorgaben zum Ziel-SDK betreffen die App nicht (kein Play Store).
- **Entwicklerprüfung:** ab 30.09.2026 in Brasilien, Indonesien, Singapur, Thailand; weltweit (also auch Deutschland) ab 2027. Unverifizierte Apps danach über den „erweiterten Installationsweg“ (Entwickleroptionen, Bestätigung, Neustart, einmalig 24 Stunden Wartezeit, dann für 7 Tage oder dauerhaft), über ADB unverändert, oder per kostenlosem Konto für begrenzte Verteilung (bis 20 Geräte, ohne Ausweisprüfung).
- **GitHub Actions:** Laut GitHub wird Node 20 ab 23.09.2026 von den Runnern entfernt (Node 24 ist seit 16.06.2026 Standard). Verwendet: `actions/checkout@v5`, `actions/setup-java@v5`, `gradle/actions/setup-gradle@v5` (v6 lagert das Caching in eine nicht quelloffene Bibliothek aus), `softprops/action-gh-release@v3`.
- **Build:** AGP 8.5.2, Kotlin 1.9.24, Gradle 8.9, Java 17.

## 4. Offene Punkte

- Hamburg-Luftbild: Layername prüfen.
- Gibt es eine neuere DLR-Baumartenkarte (2023/2024) oder eine verlängerte Waldverlust-Zeitreihe?
- Datum der nächsten BGR-nFK-Aktualisierung unbekannt.

## 5. Prüfprotokoll

| Datum | Was | Wer |
|---|---|---|
| 2026-10-05 | Version 4: alle Dienste, Layer und Werte geprüft; DLR-Daten, Länder-Luftbilder, BfS 2026, Actions-Versionen, Routinen-API ergänzt | Claude |
