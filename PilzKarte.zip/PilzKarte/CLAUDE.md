# PilzKarte – Hinweise für Claude

Android-App (Kotlin, **ohne AndroidX**) mit einer WebView, die eine Leaflet-Karte aus den App-Assets zeigt.
Sie hilft beim Finden von Pilzstellen in Deutschland (Boden-pH, Gesteine, Wasserspeicher, Baumarten,
Waldverlust, Regen, Wetter, Funde) und berechnet „Pilz-Chancen“ (0–100).
Der Nutzer ist **kein Programmierer**: Antworten, Oberfläche und Commit-Nachrichten auf Deutsch, einfach erklärt.

Fakten zu allen Datenquellen: **WISSEN.md**. Ablauf der Update-Routine: **ROUTINE.md**. Änderungen: **CHANGELOG.md**.

## Aufbau

| Datei | Inhalt |
|---|---|
| `app/src/main/assets/index.html` | Oberfläche (Menüs Ebenen, Chancen, Wissen, Mehr), Sicherheitsrichtlinie (CSP) im `<meta>` |
| `app/src/main/assets/app.js` | gesamte Logik in 19 Abschnitten (Übersicht im Dateikopf): Dienste & Tabellen, Hilfsfunktionen, HTTP, Karte, Legenden, Datenabfragen, Wetter, Bewertung, Analyse, Scan, Wissen, Externe Seiten, Fundorte, Rückweg, GPS & Suche, Offline-Karten, Updates, Datenschutz, Menü & Start |
| `app/src/main/assets/pilze.js` | `PILZARTEN` (Saison, Boden, Bäume, Lebensraum, Gefahr, `roh`, `cs`), `GIFTPILZE`, `MONATE`, `GIFTNOTRUF` |
| `app/src/main/assets/gesteine.js` | `PH_KLASSEN`, `GESTEINE` (Suchmuster für BGR-Texte), `gesteineAusText()`, `PILZ_TENDENZ` |
| `app/src/main/assets/lib/` | Leaflet 1.9.4 (nicht ändern) |
| `…/MainActivity.kt` | WebView, Brücke `AndroidBridge`, App-Sperre, Netz-Sperre im Hintergrund, Server-Freigabe |
| `…/Kachelspeicher.kt` | Offline-Speicher für Kartenbilder (Regeln je Anbieter), Vorab-Laden nur TopPlusOpen |
| `…/Tresor.kt` | Geheimnisse verschlüsselt im Android-Keystore (JS kann sie setzen, aber nie lesen) |
| `…/Netz.kt` | Weiterleitungen nur zu freigegebenen Servern |
| `…/WebActivity.kt`, `…/Tracker.kt` | externe Seiten mit Tracker-Blocker |
| `.github/workflows/build.yml` | baut bei Push auf `main` (außer *.md, tools/, .github/) → Release `v1.0.<Laufnummer>` mit `PilzKarte.apk`; versionCode = Laufnummer; Release-Text = oberster Abschnitt von CHANGELOG.md |
| `tools/dienste-pruefen.js` | prüft alle Datendienste live (Node 18+, Internet) |
| `tools/ui-test.js` | Browser-Test mit nachgebildeten Diensten und Brücke (Playwright) |

Brückenfunktionen (JS ↔ Kotlin): `httpGet, cancelRequest, fireRoutine, openWeb, openExternal, storeGet, storeSet,
storeClear, saveFile, appInfo, getSettings, setAppLock, setSecureScreen, setKeepScreenOn, setSecret, hasSecret,
deleteSecret, cacheInfo, clearTileCache, downloadTiles, cancelDownload`. Rückrufe: `window.__httpDone(id, status, body)`,
`window.__offlineProgress(fertig, gesamt, fehler, beendet, abgebrochen)`, `window.__sperreErgebnis(ok)`,
`window.onAppPause/onAppResume/handleBack`.

Im Hintergrund (oder bei gesperrter App) hält MainActivity Datenabfragen zurück und beantwortet Kartenbilder mit
503; app.js lädt betroffene Kartenebenen nach der Rückkehr neu (`kachelnUeberwachen`).

## Unverrückbare Regeln

1. **Datenschutz zuerst.** Keine Tracker, Werbung, Analyse- oder Absturzmelde-Dienste. Netzabfragen nur bei
   geöffneter App und auf Nutzeraktion; nichts im Hintergrund, nichts nach Zeitplan. Standort nur auf Knopfdruck.
   Koordinaten für Datenabfragen im Datensparmodus auf ~100 m runden (`abfragePunkt`), Wetter immer auf 0,1°.
   Fundorte/Startpunkt bleiben nur auf dem Handy. Neue Server nur, wenn der Nutzer zugestimmt hat.
2. **Server-Freigaben an allen Stellen pflegen:** `ERLAUBTE_HOSTS` in app.js **und** MainActivity.kt
   (Datenabfragen), Host-Listen in Kachelspeicher.kt (Kartenbilder offline), ggf. CSP in index.html.
3. **Kompatibilität:** Speicher-Schlüssel `pk_*`, `app/pilzkarte.keystore`, `applicationId de.pilzkarte.app` und
   die Namen der Brückenfunktionen nie ändern – sonst gehen Fundorte verloren oder Updates lassen sich nicht installieren.
4. **Sicherheit:** keine Inline-Skripte oder `onclick=` (CSP `script-src 'self'`); Texte aus Datenquellen immer
   mit `esc()` ausgeben; keine Schlüssel oder Passwörter ins Repository.
5. **Updates nur auf Knopfdruck:** keine automatische Update-Suche, keine geplanten Abläufe in der App.
6. **`.github/workflows/` nicht ändern** (der GitHub-Zugang der Routine darf das meist nicht). Ist dort etwas
   nötig, dem Nutzer Schritt für Schritt erklären, was er auf github.com bearbeiten soll.
7. Lieber kleine, sichere Änderungen als große Umbauten. Bestehende Funktionen nicht entfernen, ohne zu fragen.

## Testen

```bash
for f in app/src/main/assets/*.js; do node --check "$f"; done   # Syntax (läuft auch im Build)
node tools/dienste-pruefen.js                                    # Datendienste live (Internet nötig)
npm i -D playwright && npx playwright install chromium            # einmalig
node tools/ui-test.js                                            # Oberfläche mit Testdaten
```

Kotlin lässt sich ohne Android-SDK nicht bauen – der Bau läuft auf GitHub. Nach dem Push den Lauf prüfen
(`gh api repos/TheMushroomdart/Pilzkarte/actions/runs?per_page=1` oder https://github.com/TheMushroomdart/Pilzkarte/actions);
bei Fehlern das Log lesen, beheben, erneut pushen. Kotlin-Code ohne Warnungen halten; Android-APIs über
`Build.VERSION.SDK_INT` absichern (minSdk 26).

## Bewertung (app.js, Abschnitt 8)

Wald & Baumart 25 · Boden-pH 15 · Wasserspeicher 10 · Regen 15 · Bodenfeuchte 10 · Temperatur & Luft 10 ·
Gelände 7 · Funde 8 = 100. Deckel: Kahlfläche 35, kein Wald 15. Bei Änderungen die Tabelle
„Wie wird bewertet?“ in index.html mitpflegen.

## Häufige Wartungsaufgaben

- **DLR verlängert die Waldverlust-Karte:** `FCCL_LETZTER_MONAT` in app.js (Wert des letzten Monats, 1 = 09/2017),
  `stand` der Ebene `verlust` und ggf. `VERLUST_JAHRE` anpassen; WISSEN.md aktualisieren.
- **Neue Baumartenkarte** (z. B. `TREE_SPECIES_DE_2024`): Layername in `OVERLAYS` (`baum22`) und `fetchBaum()`,
  Wertetabelle `BAUM_DLR` mit der DLR-Beschreibung abgleichen.
- **Dienst-Adresse geändert:** Konstante in app.js Abschnitt 1, Freigaben (Regel 2), WISSEN.md, tools/dienste-pruefen.js.
- **Neue Pilzart:** Eintrag in pilze.js (Felder im Dateikopf); der wissenschaftliche Name dient auch der GBIF-Suche.
- **Luftbild eines Landes defekt:** Eintrag in `DOP_LAENDER` (URL, Layer) korrigieren; mit `tools/dienste-pruefen.js` prüfen.
