# Änderungen

## Version 4 (Oktober 2026)
- Neue Karten: Baumarten 2022 per Satellit (DLR, 10 m) und Waldverlust seit 2017 (Kahlflächen), amtliche Luftbilder der Bundesländer; bei jeder Ebene steht jetzt, wie alt die Daten sind.
- Genauere Pilz-Chancen: Kahlflächen werden erkannt; das Wetter berücksichtigt Luftfeuchte, Wind, Tag-Nacht-Schwankung, den Auslöser „Abkühlung nach Wärme mit Regen“ und Trockenheit der letzten 90 Tage; gemeldete Funde zählen im Verhältnis dazu, wie gut eine Gegend beobachtet ist.
- Persönliche Hotspots: 🧡 markiert Stellen, die deinen Fundorten ähneln (nur auf dem Handy berechnet); „Meine Stellen prüfen“ zeigt das Pilzwetter an all deinen Fundorten.
- Wissen: 29 Pilzarten (12 neu), Saison verschiebt sich mit dem Wetter, neue Seite „Die gefährlichsten Giftpilze“, Cäsium-Hinweise nach dem BfS-Pilzbericht 2026.
- Unterwegs: Offline-Karten (angesehene Kartenbilder werden gespeichert, Ausschnitt der amtlichen Karte vorab laden), Kompass-Pfeil für den Rückweg, Bildschirm bleibt auf Wunsch an, Navigations-App frei wählbar.
- Sicherheit: App-Sperre mit Fingerabdruck/PIN, Bildschirmschutz, Tracker-Blocker auf externen Seiten, Daten nur von freigegebenen Servern, Schutz gegen eingeschleuste Inhalte.
- Updates auf Knopfdruck: „Nach neuer Version suchen“ und „Claude nach Neuigkeiten suchen lassen“ – eingebaut wird erst nach deiner Zustimmung.

## Version 3 (September 2026)
- Datenschutz: Abfragen nur bei geöffneter App, Datensparmodus (Koordinaten auf ca. 100 m gerundet), Daten nur auf dem Handy, „Alle App-Daten löschen“.
- Rückweg zum Auto, Fundorte mit GPX-Export/-Import, Pilzwetter-Aussicht, Notfall-Seite mit Giftnotruf, Naturschutzgebiete.

## Version 2 und 1 (September 2026)
- Karte mit Boden-pH, Gesteinen, Feldkapazität, Baumarten und Niederschlag; Menü „Pilz-Chancen“ mit Scan des Kartenausschnitts; Pilzkalender und Gesteins-Übersicht.
