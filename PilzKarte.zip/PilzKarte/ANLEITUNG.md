# PilzKarte – so kommt die App auf dein Handy

Die APK (Installationsdatei) wird kostenlos von GitHub gebaut. Einmalig ca. 10 Minuten, am besten am PC.

## 1. GitHub-Konto und Projekt anlegen
1. Auf **github.com** kostenlos registrieren und anmelden.
2. Oben rechts **„+“ → „New repository“**.
3. Name: `PilzKarte`, Sichtbarkeit **Public** (oder Private – dann musst du auf dem Handy bei GitHub angemeldet sein, um die APK zu laden).
4. **„Create repository“** klicken.

## 2. Dateien hochladen
1. Die ZIP-Datei auf dem PC entpacken.
2. Im neuen Repository auf **„uploading an existing file“** klicken.
3. **Den gesamten Inhalt** des entpackten Ordners `PilzKarte` (die Ordner `app`, `gradle`, `.github` und alle Dateien) in das Browserfenster ziehen.
4. Unten **„Commit changes“** klicken.

> **Wichtig – der Ordner `.github`:** Auf dem Mac ist er im Finder unsichtbar (Cmd + Shift + . zeigt ihn an).
> Fehlt er nach dem Hochladen, so geht es auch ohne: **„Add file → Create new file“**, als Namen
> `.github/workflows/build.yml` eintippen, den Inhalt der Datei `build.yml` aus der ZIP hineinkopieren, **„Commit changes“**.

## 3. APK bauen lassen
1. Oben auf den Reiter **„Actions“** klicken. Falls gefragt: Workflows erlauben („I understand … enable them“).
2. Links **„APK bauen“** → rechts **„Run workflow“** (startet auch automatisch nach jedem Hochladen).
3. Nach ca. 3–5 Minuten erscheint ein grüner Haken ✅.

## 4. Auf dem Handy installieren
1. Auf dem Handy im Browser dein Repository öffnen: `github.com/DEIN-NAME/PilzKarte`
2. Rechts bzw. unten **„Releases“** → neueste Version → **`PilzKarte.apk`** herunterladen.
3. Die Datei antippen. Android fragt einmalig, ob der Browser „Apps aus unbekannten Quellen installieren“ darf → **erlauben**.
4. **Installieren** → fertig. Beim ersten GPS-Tipp fragt die App nach der Standort-Berechtigung.

**Updates:** Neue Dateien hochladen → GitHub baut automatisch eine neue Version → APK herunterladen und einfach über die alte installieren (gespeicherte Fundorte bleiben erhalten).

## Alternative: Android Studio (für Bastler)
Ordner in Android Studio öffnen → Handy per USB anschließen (USB-Debugging an) → ▶ Run.

---

## Update auf eine neue Version
1. Im GitHub-Projekt **„Add file“ → „Upload files“** und die neue **PilzKarte.zip** hochladen (ersetzt die alte).
2. **„Commit changes“** – GitHub baut automatisch (Reiter „Actions“, ca. 5 Minuten).
3. Unter **„Releases“** die neue `PilzKarte.apk` laden und einfach über die alte App installieren. Fundorte bleiben erhalten.

## Was die App kann
| Menü | Inhalt |
|---|---|
| **Karte** | Tippen = Standort-Analyse mit Pilz-Chance (0–100), lange drücken = Fundort merken, Ortssuche, GPS |
| **Ebenen** | Grundkarten (TopPlusOpen, OpenTopoMap mit Höhenlinien, OSM, Satellit). Fachdaten: Boden-pH Ober-/Unterboden (Thünen), Gesteine nach Boden-pH eingefärbt und BGR-Originalkarte, nutzbare Feldkapazität (BGR), Baumarten per Satellit (Thünen), Niederschlag 24 h / 30 Tage & Radar (DWD), gemeldete Pilzfunde (GBIF), Naturschutzgebiete & Nationalparke (BfN) |
| **Chancen** | Bewertung aus Wald/Baumart, pH, Wasserspeicher, Regen inkl. Verdunstung, Bodenfeuchte, Temperatur inkl. Frost, Hanglage und Funden in der Nähe; Scan des Kartenausschnitts; Pilzwetter-Aussicht für 1–2 Wochen |
| **Wissen** | Pilzkalender mit Verwechslungsgefahren (☠️ tödliche Doppelgänger), Gesteine & Boden-pH, Notfall mit Giftnotruf-Nummern |
| **Mehr** | Rückweg zum Auto, Fundorte (Export/Import als GPX), externe Karten (Waldmonitor, Kachelmannwetter, topographic-map.com, DGfM-Pilzberatung), Datenschutz-Einstellungen, Rechtliches, Quellen |

## Datenschutz
- Kein Konto, keine Werbung, kein Tracking. Datenabrufe nur bei geöffneter App – im Hintergrund werden alle Abfragen angehalten.
- Standort nur auf Knopfdruck; Hintergrund-Standort wird gar nicht angefragt.
- Datensparmodus (Standard): Koordinaten für Datenabfragen werden auf ca. 100 m gerundet, fürs Wetter auf ca. 10 km.
- Fundorte und Startpunkt liegen nur auf dem Handy (keine Cloud-Sicherung). Sichern per GPX-Export.
- Neutraler Browser-Kennung ohne Handymodell, keine Nutzungsstatistik der WebView, keine Cookies von Dritten; externe Seiten verlieren Cookies beim Schließen.

Datenquellen: Thünen-Institut (CC BY 4.0), BGR, Deutscher Wetterdienst, Open-Meteo (Wetter, Bodenfeuchte, Verdunstung, Höhenmodell), GBIF, BfN, BVL, BfS, BKG, OpenStreetMap/OpenTopoMap, Esri.
