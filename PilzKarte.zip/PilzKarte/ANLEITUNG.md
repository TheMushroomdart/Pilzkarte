# PilzKarte – Anleitung

- **Teil A:** Version 4 aufs Handy bringen (ca. 10 Minuten am PC)
- **Teil B:** Claude-Updates einrichten (einmalig, ca. 10 Minuten)
- **Teil C:** So läuft ein Update mit Claude
- **Teil D:** Ab 2027: Android-Entwicklerprüfung
- **Teil E:** Wenn etwas nicht klappt
- **Anhang:** Neu einrichten (falls du ganz von vorn beginnst)

---

## Teil A: Version 4 aufs Handy bringen

### A1. Bauanleitung auf GitHub erneuern (einmalig, empfohlen)
Die neue Datei nutzt aktuelle GitHub-Bausteine und baut nur bei echten Änderungen.
1. Am PC dein Projekt öffnen: **github.com/TheMushroomdart/Pilzkarte**
2. Auf den Ordner **`.github`** → **`workflows`** → Datei **`build.yml`** klicken.
3. Rechts oben auf den **Stift** (Edit) klicken, den gesamten Inhalt löschen (Strg+A, Entf).
4. Den Inhalt der neuen `build.yml` hineinkopieren (liegt in der ZIP unter `PilzKarte/.github/workflows/build.yml`
   und zusätzlich als eigene Datei im Chat).
5. **„Commit changes…“** → **„Commit changes“**. (Dadurch wird noch nichts gebaut.)

### A2. Neue Version hochladen
1. Im Projekt **„Add file“ → „Upload files“**.
2. Die neue **`PilzKarte.zip`** (nicht entpacken!) ins Fenster ziehen – sie ersetzt die alte.
3. **„Commit changes“** klicken.
4. Reiter **„Actions“**: Nach ca. 5 Minuten erscheint ein grüner Haken ✅.

### A3. Auf dem Handy installieren
1. Auf dem Handy im Browser **github.com/TheMushroomdart/Pilzkarte/releases** öffnen.
2. Bei der neuesten Version **`PilzKarte.apk`** herunterladen, antippen, **„Installieren“** (bzw. „Aktualisieren“).
3. Deine Fundorte und Einstellungen bleiben erhalten.

Ab Version 4 geht das künftig direkt in der App: **Mehr → Updates → „Nach neuer Version suchen“**.

---

## Teil B: Claude-Updates einrichten (einmalig)

Damit kann die App per Knopfdruck Claude bitten, nach Neuigkeiten zu suchen und Verbesserungen vorzuschlagen.
Du brauchst dein Claude-Konto (Pro). Am einfachsten machst du **alles am Handy im Browser** – dann kannst du
Adresse und Schlüssel direkt in die App kopieren. **Den Schlüssel nie per Mail oder Messenger verschicken.**

### B1. Routine anlegen
1. **claude.ai/code/routines** öffnen und anmelden → **„New routine“**.
2. **Name:** `PilzKarte-Update`
3. **Instructions:** den kompletten Text aus dem Kasten in **ROUTINE.md** einfügen.
4. **Repository:** `TheMushroomdart/Pilzkarte` hinzufügen. Falls GitHub noch nicht verbunden ist, führt
   claude.ai dich durch die Verbindung – Zugriff auf dieses Projekt erlauben.
5. **Environment (Umgebung):** Auf das Wolken-Symbol (z. B. „Default“) tippen → beim Eintrag auf das
   Zahnrad → **Network access: „Full“** → **„Save changes“**.
   *Warum?* Claude muss die Kartenserver (Thünen, BGR, DLR …) erreichen, um sie zu prüfen. Das betrifft nur
   Claudes Cloud-Rechner, nicht dein Handy.
6. **Select a trigger:** nur **„API“** wählen – **keinen Zeitplan** (Schedule).
7. **Connectors:** alle entfernen (werden nicht gebraucht).
8. **„Create“** klicken.

### B2. Adresse und Schlüssel holen
1. Die neue Routine antippen → Menü neben dem Namen → **„Edit“**.
2. Unter **„Select a trigger“** den **API-Trigger** öffnen. Dort steht die **Adresse** (endet auf `/fire`) → kopieren.
3. **„Generate token“** → den **Schlüssel** (beginnt mit `sk-ant-`) sofort kopieren – er wird nur einmal angezeigt.

### B3. In der App eintragen
1. PilzKarte → **Mehr** → **Updates** → **„Claude einrichten (einmalig)“** aufklappen.
2. Adresse und Schlüssel einfügen → **„Speichern“**. Es erscheint „✓ Eingerichtet“.
3. Der Schlüssel liegt nun verschlüsselt im Schlüsselspeicher des Handys. Die App kann ihn nur zum Starten der
   Routine verwenden, nicht anzeigen. Neuer Schlüssel nötig? Einfach in B2 „Regenerate“ und neu eintragen.

---

## Teil C: So läuft ein Update mit Claude

1. In der App: **Mehr → Updates → „🤖 Claude nach Neuigkeiten suchen lassen“**.
   Gesendet werden nur Versionsnummer und Datum – keine Standorte, keine Fundorte.
2. Die Claude-Sitzung öffnet sich (Claude-App oder Browser). Nach einigen Minuten steht dort eine
   **nummerierte Liste mit Vorschlägen** samt Quellen.
3. Du antwortest in der Sitzung, z. B. **„1 und 3 bitte“** oder **„keine“**. Vorher wird nichts verändert.
4. Claude baut die Punkte ein, testet sie und lädt sie in dein GitHub-Projekt. GitHub baut daraus in ca. 5 Minuten
   die neue App.
5. In der App: **„Nach neuer Version suchen“ → „Herunterladen“** → Datei antippen → **Installieren**.

Gut zu wissen: Jeder Start zählt zu deinem Claude-Pro-Kontingent (höchstens 30 Starts pro Stunde).
Die Routine läuft **nie von selbst** – nur, wenn du den Knopf drückst. In der Sitzung kannst du Claude
auch eigene Wünsche nennen („Bau bitte … ein“).

---

## Teil D: Ab 2027 – Android-Entwicklerprüfung

Google verlangt ab 2027 weltweit (also auch in Deutschland), dass Apps auf zertifizierten Android-Handys von
verifizierten Entwicklern stammen – auch außerhalb des Play Stores. Bis dahin ändert sich nichts.
Für selbst gebaute Apps wie die PilzKarte gibt es dann drei Wege:

1. **Erweiterter Installationsweg (am einfachsten):** Einstellungen → Entwickleroptionen →
   „Apps von nicht verifizierten Entwicklern“ → mit Displaysperre bestätigen → Handy neu starten →
   nach **24 Stunden Wartezeit** einschalten (für 7 Tage oder dauerhaft). Das ist einmalig pro Handy;
   danach lassen sich Installation und Updates mit Warnhinweis durchführen.
2. **Per USB-Kabel vom PC (ADB):** bleibt laut Google unverändert möglich.
3. **Kostenloses Konto für begrenzte Verteilung** (bis 20 Geräte, ohne Ausweisprüfung): Dann wird der
   Signatur-Schlüssel der App bei Google registriert – Claude hilft dabei, wenn es so weit ist.

Die genauen Menünamen stehen erst mit der Einführung fest. „Claude nach Neuigkeiten suchen lassen“ prüft auch das.

---

## Teil E: Wenn etwas nicht klappt

| Problem | Lösung |
|---|---|
| Actions zeigt ein rotes ✗ | Auf den Lauf klicken → roten Schritt öffnen. Oder in der Claude-Sitzung schreiben: „Der Bau ist fehlgeschlagen, bitte prüfen.“ |
| „Schlüssel passt nicht“ | In B2 einen neuen Schlüssel erzeugen und in der App neu eintragen. |
| „Routine nicht gefunden“ | Adresse in B2 erneut kopieren. |
| „Zu viele Starts“ | Eine Stunde warten. |
| Claude meldet „HTTP 403 bei allen Diensten“ | B1 Schritt 5: Network access „Full“ einstellen. |
| Installation wird blockiert | Play Protect: „Trotzdem installieren“; Samsung: „Auto Blocker“ vorübergehend aus; „Unbekannte Apps installieren“ für den Browser erlauben. |
| App-Sperre lässt sich nicht einschalten | Zuerst am Handy eine Displaysperre (PIN, Muster, Fingerabdruck) einrichten. |
| Karte offline leer | Nur angesehene Bereiche bzw. vorab geladene Ausschnitte (Mehr → Offline-Karten) sind ohne Netz verfügbar. |

---

## Was die App kann

| Menü | Inhalt |
|---|---|
| **Karte** | Tippen = Standort-Analyse mit Pilz-Chance (0–100), lange drücken = Fundort merken, Ortssuche, GPS |
| **Ebenen** | Grundkarten (TopPlusOpen, OpenTopoMap, OSM, amtliche Luftbilder, Satellit). Fachdaten: Boden-pH (Thünen), Gesteine nach pH und als BGR-Karte, Feldkapazität (BGR), Baumarten 2022 und Waldverlust (DLR), ältere Baumartenkarte (Thünen), Niederschlag 24 h / 30 Tage & Radar (DWD), Pilzfunde (GBIF), Naturschutzgebiete (BfN) – jeweils mit Datenstand |
| **Chancen** | Bewertung aus Wald, Baumart und Waldzustand, pH, Wasserspeicher, Regen, Wasserbilanz, Bodenfeuchte, Temperatur, Luftfeuchte, Wind, Gelände und Funden; Scan des Ausschnitts mit 🧡 für Stellen wie deine Fundorte; „Meine Stellen prüfen“; Pilzwetter-Aussicht |
| **Wissen** | 29 Pilzarten mit Saison und Verwechslungen, die gefährlichsten Giftpilze, Gesteine & Boden-pH, Notfall mit Giftnotruf |
| **Mehr** | Externe Karten (mit Tracker-Blocker), Rückweg mit Kompass, Fundorte (GPX), Offline-Karten, Updates & Claude, Datenschutz (Datensparmodus, App-Sperre, Bildschirmschutz), Rechtliches, Quellen |

## Datenschutz in Kürze
- Kein Konto, keine Werbung, kein Tracking. Abfragen nur bei geöffneter App; im Hintergrund wird alles angehalten.
- Standort nur auf Knopfdruck, nie im Hintergrund. Datensparmodus: Koordinaten auf ca. 100 m gerundet, Wetter auf ca. 10 km.
- Fundorte, Startpunkt und Offline-Karten nur auf dem Handy (kein Cloud-Backup). Sichern per GPX-Export.
- Updates nur auf Knopfdruck.

---

## Anhang: Neu einrichten (falls du ganz von vorn beginnst)
1. Auf **github.com** ein Konto anlegen → **„+“ → „New repository“** → Name `Pilzkarte`, **Public** → **„Create repository“**.
2. **„Add file“ → „Create new file“** → Name `.github/workflows/build.yml` → Inhalt der Datei `build.yml` einfügen → **„Commit changes“**.
3. **„Add file“ → „Upload files“** → `PilzKarte.zip` hochladen → **„Commit changes“**.
4. Reiter **„Actions“** → ggf. Workflows erlauben → nach ca. 5 Minuten unter **„Releases“** die `PilzKarte.apk` aufs Handy laden und installieren.
5. Für Claude-Updates Teil B befolgen (in ROUTINE.md und der App dein Projekt statt `TheMushroomdart/Pilzkarte` eintragen).
