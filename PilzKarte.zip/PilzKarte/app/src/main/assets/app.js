/* PilzKarte – Kartenlogik, Datenabfragen und Pilz-Chancen-Bewertung */
(function () {
  "use strict";

  // ------------------------------------------------------------------
  // Dienste
  // ------------------------------------------------------------------
  var THUENEN = "https://atlas.thuenen.de/geoserver/wms";
  var BGR_GEO_WMS = "https://services.bgr.de/wms/geologie/guek250/";
  var BGR_NFK_WMS = "https://services.bgr.de/wms/boden/nfkwe1000/";
  var BGR_REST = "https://services.bgr.de/arcgis/rest/services";
  var DWD = "https://maps.dwd.de/geoserver/dwd/wms";

  function dwdLegend(layer) {
    return DWD + "?service=WMS&version=1.1.0&request=GetLegendGraphic&format=image/png&layer=" + encodeURIComponent(layer);
  }

  // Farben der Thünen-Originaldarstellung (aus GetLegendGraphic)
  var PH_ORIGINAL = [
    ["≤4,5", "#7D0F32"], ["4,5–5", "#AF0825"], ["5–5,5", "#EC596A"], ["5,5–6", "#F9CCD1"],
    ["6–6,5", "#CCECF9"], ["6,5–7", "#59C1EC"], ["7–7,5", "#0078AD"], [">7,5", "#005078"]
  ];
  // Eigene Indikator-Skala (wie pH-Teststreifen)
  var PH_INDIKATOR = [
    [3.0, "#b2182b"], [4.0, "#e65100"], [4.5, "#f9a825"], [5.0, "#fdd835"], [5.5, "#c0ca33"],
    [6.0, "#7cb342"], [6.5, "#2e7d32"], [7.0, "#00897b"], [7.5, "#1e88e5"], [8.0, "#3949ab"], [8.5, "#5e35b1"]
  ];

  // Baumarten-Klassen der Thünen-Karte (Werte aus der Original-Legende)
  var BAUM = {
    2: { name: "Birke", farbe: "#D1EFE2", myk: true },
    3: { name: "Buche", farbe: "#49CA45", myk: true },
    4: { name: "Douglasie", farbe: "#E7EC47", myk: true },
    5: { name: "Eiche", farbe: "#1A761C", myk: true },
    6: { name: "Erle", farbe: "#67844D", myk: false, punkte: 16 },
    8: { name: "Fichte", farbe: "#CD8673", myk: true },
    9: { name: "Kiefer", farbe: "#DE1317", myk: true },
    10: { name: "Lärche", farbe: "#DF3FEA", myk: true },
    14: { name: "Tanne", farbe: "#FFD54D", myk: true },
    16: { name: "Sonst. Laubholz (langlebig)", farbe: "#25A0ED", myk: false, punkte: 15 },
    17: { name: "Sonst. Laubholz (kurzlebig)", farbe: "#8EBCD9", myk: false, punkte: 15 }
  };
  var BAUM_PILZE = {
    "Birke": "Birkenpilz, Rotkappe, Fliegenpilz (giftig)",
    "Buche": "Steinpilz, Pfifferling, Herbsttrompete, Semmel-Stoppelpilz",
    "Douglasie": "Maronen-Röhrling, Krause Glucke (selten)",
    "Eiche": "Sommer-Steinpilz, Pfifferling, Rotkappe (Eichen-), Schwefelporling (am Stamm)",
    "Erle": "Erlen-Grübling, Erlenkremplinge (giftig)",
    "Fichte": "Fichten-Steinpilz, Maronen-Röhrling, Pfifferling, Reizker",
    "Kiefer": "Kiefern-Steinpilz, Krause Glucke, Butterpilz, Sandröhrling, Edelreizker",
    "Lärche": "Goldröhrling (Lärchen-Röhrling)",
    "Tanne": "Pfifferling, Steinpilz, Semmel-Stoppelpilz"
  };

  var BASEMAPS = [
    { id: "topplus", name: "TopPlusOpen (amtliche Karte, BKG)",
      url: "https://sgx.geodatenzentrum.de/wmts_topplus_open/tile/1.0.0/web/default/WEBMERCATOR/{z}/{y}/{x}.png",
      opt: { maxZoom: 18, maxNativeZoom: 18, attribution: "© BKG (TopPlusOpen)" } },
    { id: "topo", name: "Topografisch mit Höhenlinien (OpenTopoMap)",
      url: "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
      opt: { maxZoom: 18, maxNativeZoom: 17, subdomains: "abc", attribution: "© OpenStreetMap, © OpenTopoMap (CC BY-SA)" } },
    { id: "osm", name: "OpenStreetMap",
      url: "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
      opt: { maxZoom: 19, attribution: "© OpenStreetMap-Mitwirkende" } },
    { id: "sat", name: "Satellit / Luftbild (Esri)",
      url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
      opt: { maxZoom: 19, maxNativeZoom: 18, attribution: "© Esri, Maxar, Earthstar Geographics" } }
  ];

  var OVERLAYS = [
    { id: "ph0", name: "Boden-pH Oberboden (0–30 cm)", src: "Thünen-Institut", url: THUENEN,
      layers: "geonode:pH_map_0_30", opacity: 0.7, legend: "ph", ph: true },
    { id: "ph1", name: "Boden-pH Unterboden (30–100 cm)", src: "Thünen-Institut", url: THUENEN,
      layers: "geonode:pH_map_30_100", opacity: 0.7, legend: "ph", ph: true },
    { id: "geoph", name: "Gesteine nach Boden-pH eingefärbt", src: "BGR GÜK250, von der App nach typischem pH eingefärbt (ab Zoom 10)",
      type: "geoph", opacity: 0.55, legend: "geoph" },
    { id: "geo", name: "Gesteine (Original-Karte GÜK250)", src: "BGR – Farben nach Gesteinsart", url: BGR_GEO_WMS,
      layers: "4", opacity: 0.6, legend: "geo" },
    { id: "nfk", name: "Nutzbare Feldkapazität (Wasserspeicher)", src: "BGR", url: BGR_NFK_WMS,
      layers: "0", opacity: 0.6, legend: "img",
      legendUrl: BGR_NFK_WMS + "?service=WMS&request=GetLegendGraphic&version=1.3.0&format=image/png&layer=0" },
    { id: "baum", name: "Baumarten (Satellit, 2017/18)", src: "Thünen-Institut", url: THUENEN,
      layers: "geonode:Dominant_Species_Class", opacity: 0.75, legend: "baum" },
    { id: "rain24", name: "Niederschlag letzte 24 h", src: "DWD RADOLAN", url: DWD,
      layers: "dwd:SF-Produkt", opacity: 0.7, legend: "img", legendUrl: dwdLegend("dwd:SF-Produkt") },
    { id: "rain30", name: "Niederschlag letzte 30 Tage", src: "DWD RADOLAN", url: DWD,
      layers: "dwd:RADOLAN-W4", opacity: 0.7, legend: "img", legendUrl: dwdLegend("dwd:RADOLAN-W4") },
    { id: "radar", name: "Regenradar aktuell", src: "DWD", url: DWD,
      layers: "dwd:Niederschlagsradar", opacity: 0.7, legend: "img", legendUrl: dwdLegend("dwd:Niederschlagsradar") },
    { id: "funde", name: "Gemeldete Pilzfunde (Speisepilze)", src: "GBIF – u. a. iNaturalist, Pilzkartierungen",
      type: "gbif", legend: "gbif" },
    { id: "schutz", name: "Naturschutzgebiete & Nationalparke", src: "Bundesamt für Naturschutz – dort Sammelverbot!",
      url: "https://geodienste.bfn.de/ogc/wms/schutzgebiet", layers: "Naturschutzgebiete,Nationalparke", opacity: 0.45, legend: "schutz" }
  ];

  // ------------------------------------------------------------------
  // Hilfsfunktionen
  // ------------------------------------------------------------------
  function $(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function num(v, d) {
    if (v == null || !isFinite(v)) return "–";
    return Number(v).toLocaleString("de-DE", { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 });
  }
  var toastTimer;
  function toast(msg, ms) {
    var t = $("toast");
    t.textContent = msg;
    t.classList.remove("hidden");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.add("hidden"); }, ms || 3000);
  }
  // Ablage nur auf diesem Gerät: in der App nativ (kein Cloud-Backup), im Browser localStorage
  var NATIV = !!(window.AndroidBridge && window.AndroidBridge.storeGet);
  var STORE_KEYS = ["pk_state", "pk_fundorte", "pk_seen", "pk_gbif_keys", "pk_auto", "pk_privat"];
  var store = {
    get: function (k, def) {
      try {
        var v = NATIV ? window.AndroidBridge.storeGet(k) : localStorage.getItem(k);
        return v ? JSON.parse(v) : def;
      } catch (e) { return def; }
    },
    set: function (k, v) {
      try {
        var t = v === undefined || v === null ? null : JSON.stringify(v);
        if (NATIV) window.AndroidBridge.storeSet(k, t);
        else if (t === null) localStorage.removeItem(k);
        else localStorage.setItem(k, t);
      } catch (e) { /* egal */ }
    },
    clearAll: function () {
      try { if (NATIV) window.AndroidBridge.storeClear(); } catch (e) { /* egal */ }
      try { localStorage.clear(); } catch (e) { /* egal */ }
    }
  };
  // Einmalige Übernahme alter Daten (Version 1/2 speicherte im WebView-Speicher)
  if (NATIV) {
    try {
      if (!window.AndroidBridge.storeGet("pk_migriert")) {
        STORE_KEYS.forEach(function (k) {
          var alt = localStorage.getItem(k);
          if (alt && !window.AndroidBridge.storeGet(k)) window.AndroidBridge.storeSet(k, alt);
        });
        window.AndroidBridge.storeSet("pk_migriert", "1");
        localStorage.clear();
      }
    } catch (e) { /* egal */ }
  }
  // Datensparmodus: Koordinaten für Datenabfragen auf ca. 100 m runden (Standard: an)
  var privat = store.get("pk_privat", true);
  function abfragePunkt(ll) {
    if (!privat) return ll;
    return L.latLng(Math.round(ll.lat * 1000) / 1000, Math.round(ll.lng * 1000) / 1000);
  }
  function scoreColor(s) {
    var h = Math.max(0, Math.min(120, s * 1.2));
    return "hsl(" + h + ",70%,38%)";
  }
  function scoreLabel(s) {
    if (s >= 70) return "Sehr gute Chancen";
    if (s >= 50) return "Gute Chancen";
    if (s >= 30) return "Mäßige Chancen";
    return "Geringe Chancen";
  }

  // ------------------------------------------------------------------
  // HTTP: in der App über die native Brücke (kein CORS), im Browser fetch()
  // ------------------------------------------------------------------
  var pending = {}, reqSeq = 0;
  window.__httpDone = function (id, status, body) {
    var p = pending[id];
    if (!p) return;
    delete pending[id];
    if (status >= 200 && status < 300) p.res(body); else p.rej(new Error("HTTP " + status));
  };
  function rawGet(url) {
    if (window.AndroidBridge && window.AndroidBridge.httpGet) {
      return new Promise(function (res, rej) {
        var id = ++reqSeq;
        pending[id] = { res: res, rej: rej };
        window.AndroidBridge.httpGet(id, url);
        setTimeout(function () { if (pending[id]) { delete pending[id]; rej(new Error("Zeitüberschreitung")); } }, 30000);
      });
    }
    return fetch(url).then(function (r) {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.text();
    });
  }
  // gleichzeitige Anfragen begrenzen
  var active = 0, queue = [], MAX_PARALLEL = 6;
  function httpGet(url) {
    return new Promise(function (res, rej) {
      queue.push({ url: url, res: res, rej: rej });
      pump();
    });
  }
  function pump() {
    while (active < MAX_PARALLEL && queue.length) {
      (function (job) {
        active++;
        rawGet(job.url).then(job.res, job.rej).then(function () { active--; pump(); });
      })(queue.shift());
    }
  }
  function getJson(url) { return httpGet(url).then(function (t) { return JSON.parse(t); }); }

  var cache = {};
  function cached(key, ttlMs, fn) {
    var c = cache[key];
    if (c && Date.now() - c.t < ttlMs) return c.p;
    var p = fn();
    cache[key] = { t: Date.now(), p: p };
    p.catch(function () { delete cache[key]; });
    return p;
  }
  function llKey(ll) { return ll.lat.toFixed(4) + "," + ll.lng.toFixed(4); }

  // ------------------------------------------------------------------
  // Karte
  // ------------------------------------------------------------------
  var state = store.get("pk_state", null) || {
    c: [51.1, 10.3], z: 6, base: "topplus", ov: {}, phstyle: "original"
  };
  var map = L.map("map", { zoomControl: false, attributionControl: true, tap: true })
    .setView(state.c, state.z);
  L.control.zoom({ position: "topright" }).addTo(map);
  L.control.scale({ imperial: false, position: "bottomright" }).addTo(map);

  function saveState() {
    var c = map.getCenter();
    state.c = [c.lat, c.lng];
    state.z = map.getZoom();
    store.set("pk_state", state);
  }
  map.on("moveend", saveState);

  var baseLayer = null;
  function setBase(id) {
    var def = BASEMAPS.filter(function (b) { return b.id === id; })[0] || BASEMAPS[0];
    if (baseLayer) map.removeLayer(baseLayer);
    baseLayer = L.tileLayer(def.url, def.opt).addTo(map);
    baseLayer.bringToBack();
    state.base = def.id;
    saveState();
  }

  // pH-Farbskala als SLD (GeoServer)
  function phSld(layerName) {
    var e = '<ColorMapEntry color="#000000" quantity="2.9" opacity="0"/>';
    PH_INDIKATOR.forEach(function (p) { e += '<ColorMapEntry color="' + p[1] + '" quantity="' + p[0] + '"/>'; });
    e += '<ColorMapEntry color="#5e35b1" quantity="8.6" opacity="0"/>';
    return '<?xml version="1.0" encoding="UTF-8"?><StyledLayerDescriptor version="1.0.0" ' +
      'xmlns="http://www.opengis.net/sld" xmlns:ogc="http://www.opengis.net/ogc">' +
      "<NamedLayer><Name>" + layerName + "</Name><UserStyle><FeatureTypeStyle><Rule><RasterSymbolizer>" +
      '<ColorMap type="ramp">' + e + "</ColorMap></RasterSymbolizer></Rule></FeatureTypeStyle></UserStyle></NamedLayer></StyledLayerDescriptor>";
  }

  var overlayLayers = {};
  function makeGbifLayer() {
    var g = L.layerGroup(), timer = null, hinweis = false;
    function laden() {
      if (!map.hasLayer(g)) return;
      if (map.getZoom() < 9) {
        g.clearLayers();
        if (!hinweis) { toast("Pilzfunde: bitte weiter hineinzoomen."); hinweis = true; }
        return;
      }
      var b = map.getBounds();
      fetchFunde(b.getSouth(), b.getWest(), b.getNorth(), b.getEast()).then(function (list) {
        g.clearLayers();
        list.forEach(function (f) {
          L.circleMarker([f.lat, f.lng], { radius: 6, color: "#fff", weight: 1.5, fillColor: "#ff6f00", fillOpacity: 0.9,
            bubblingMouseEvents: false })
            .bindPopup("<b>" + esc(f.art.de) + "</b><br><i>" + esc(f.art.sci) + "</i><br>" + esc(f.datum || "Datum unbekannt") +
              (f.unsicher ? "<br>Ortsgenauigkeit ± " + num(f.unsicher) + " m" : "") + "<br><small>" + esc(f.quelle) + "</small>")
            .addTo(g);
        });
        if (!list.length) toast("Keine gemeldeten Speisepilz-Funde in diesem Ausschnitt.");
        else if (list.length >= 300) toast("Sehr viele Funde – es werden 300 davon gezeigt.");
      }).catch(function () { toast("Funddaten (GBIF) gerade nicht erreichbar."); });
    }
    function spaeter() { clearTimeout(timer); timer = setTimeout(laden, 700); }
    g.on("add", function () { map.on("moveend", spaeter); laden(); });
    g.on("remove", function () { map.off("moveend", spaeter); });
    return g;
  }
  // Gesteinsflächen der BGR holen und nach typischem Boden-pH einfärben
  function makeGeoPhLayer(def) {
    var g = L.layerGroup(), timer = null, hinweis = false;
    var deck = state.ov[def.id] != null ? state.ov[def.id] : def.opacity;
    g.setOpacity = function (v) { deck = v; g.eachLayer(function (l) { l.setStyle({ fillOpacity: v }); }); };
    function laden() {
      if (!map.hasLayer(g)) return;
      if (map.getZoom() < 10) {
        g.clearLayers();
        if (!hinweis) { toast("Gesteins-pH-Karte: bitte bis Zoomstufe 10 hineinzoomen."); hinweis = true; }
        return;
      }
      var b = map.getBounds(), z = map.getZoom();
      var mProPixel = 156543.03 * Math.cos(b.getCenter().lat * Math.PI / 180) / Math.pow(2, z);
      var tol = (mProPixel / 111320).toFixed(6);
      var box = [b.getWest(), b.getSouth(), b.getEast(), b.getNorth()].map(function (x) { return x.toFixed(4); }).join(",");
      var url = BGR_REST + "/geologie/guek250/MapServer/8/query?geometry=" + box +
        "&geometryType=esriGeometryEnvelope&inSR=4326&outSR=4326&spatialRel=esriSpatialRelIntersects" +
        "&outFields=klartext_kurz,klartext,gkart_legtxt_stat&returnGeometry=true&maxAllowableOffset=" + tol +
        "&geometryPrecision=5&f=json";
      cached("geoph" + box + z, 36e5, function () { return getJson(url); }).then(function (j) {
        if (!map.hasLayer(g)) return;
        g.clearLayers();
        (j.features || []).forEach(function (f) {
          if (!f.geometry || !f.geometry.rings) return;
          var a = f.attributes || {};
          var arten = gesteineAusText([a.klartext_kurz, a.klartext, a.gkart_legtxt_stat].join(" "));
          var k = arten[0] ? arten[0].klasse : null;
          var rings = f.geometry.rings.map(function (r) { return r.map(function (p) { return [p[1], p[0]]; }); });
          L.polygon(rings, { stroke: true, weight: 0.6, color: "#444", opacity: 0.5,
            fillColor: k ? PH_KLASSEN[k].farbe : "#9e9e9e", fillOpacity: deck, fillRule: "evenodd" })
            .bindTooltip((a.klartext_kurz || "Gestein") + (k ? " – " + k + " (pH " + (arten[0].ph) + ")" : " – pH unbekannt"), { sticky: true })
            .addTo(g);
        });
        if (j.exceededTransferLimit) toast("Sehr viele Gesteinsflächen – für die vollständige Karte weiter hineinzoomen.");
      }).catch(function () { toast("Gesteinsdaten (BGR) gerade nicht erreichbar."); });
    }
    function spaeter() { clearTimeout(timer); timer = setTimeout(laden, 700); }
    g.on("add", function () { map.on("moveend", spaeter); laden(); });
    g.on("remove", function () { map.off("moveend", spaeter); });
    return g;
  }
  function makeOverlay(def) {
    if (def.type === "gbif") return makeGbifLayer();
    if (def.type === "geoph") return makeGeoPhLayer(def);
    var opt = {
      layers: def.layers, format: "image/png", transparent: true, version: "1.3.0",
      opacity: state.ov[def.id] != null ? state.ov[def.id] : def.opacity,
      attribution: def.src, zIndex: 10 + OVERLAYS.indexOf(def)
    };
    var useSld = def.ph && state.phstyle === "indikator";
    if (useSld) opt.SLD_BODY = phSld(def.layers);
    var lyr = L.tileLayer.wms(def.url, opt);
    // Fallback, falls der Server die eigene Farbskala nicht annimmt
    if (useSld) {
      var ok = 0, bad = 0;
      lyr.on("tileload", function () { ok++; });
      lyr.on("tileerror", function () {
        bad++;
        if (bad >= 4 && ok === 0) {
          state.phstyle = "original";
          store.set("pk_state", state);
          toast("Eigene pH-Farben nicht möglich – zeige Original-Farben.");
          document.querySelector('input[name=phstyle][value=original]').checked = true;
          refreshPhLayers();
        }
      });
    }
    return lyr;
  }
  function setOverlay(id, on) {
    var def = OVERLAYS.filter(function (o) { return o.id === id; })[0];
    if (!def) return;
    if (on && !overlayLayers[id]) {
      overlayLayers[id] = makeOverlay(def).addTo(map);
      if (state.ov[id] == null) state.ov[id] = def.opacity;
    } else if (!on && overlayLayers[id]) {
      map.removeLayer(overlayLayers[id]);
      delete overlayLayers[id];
      delete state.ov[id];
    }
    saveState();
    renderLegends();
  }
  function refreshPhLayers() {
    ["ph0", "ph1"].forEach(function (id) {
      if (overlayLayers[id]) {
        map.removeLayer(overlayLayers[id]);
        overlayLayers[id] = makeOverlay(OVERLAYS.filter(function (o) { return o.id === id; })[0]).addTo(map);
      }
    });
    renderLegends();
  }

  // ------------------------------------------------------------------
  // Legenden
  // ------------------------------------------------------------------
  function legendHtml(def) {
    var h = '<div class="legend"><div class="t">' + esc(def.name) + "</div>";
    if (def.legend === "ph") {
      var arr = state.phstyle === "indikator" ? PH_INDIKATOR : PH_ORIGINAL;
      h += '<div class="ramp">' + arr.map(function (a) { return '<span style="background:' + a[1] + '"></span>'; }).join("") + "</div>";
      h += state.phstyle === "indikator"
        ? '<div class="ticks"><span>3</span><span>4,5</span><span>6</span><span>7</span><span>8,5</span></div>'
        : '<div class="ticks"><span>≤4,5</span><span>5,5</span><span>6,5</span><span>&gt;7,5</span></div>';
      h += '<div class="ticks"><span>sauer</span><span>neutral</span><span>basisch</span></div>';
    } else if (def.legend === "baum") {
      h += '<div class="items">' + Object.keys(BAUM).map(function (k) {
        var b = BAUM[k];
        return '<div class="li"><span class="sw" style="background:' + b.farbe + '"></span>' + esc(b.name.replace(/Sonst\. Laubholz/, "Laubh.")) + "</div>";
      }).join("") + "</div>";
    } else if (def.legend === "geo") {
      h += '<div>Farben = Gesteinsart (BGR-Originallegende).<br>Auf die Karte tippen → Gestein &amp; pH.<br>Nach pH eingefärbt: Ebene „Gesteine nach Boden-pH“.</div>';
    } else if (def.legend === "geoph") {
      h += '<div class="items">' + Object.keys(PH_KLASSEN).map(function (k) {
        return '<div class="li"><span class="sw" style="background:' + PH_KLASSEN[k].farbe + '"></span>' + esc(k) + "</div>";
      }).join("") + '<div class="li"><span class="sw" style="background:#9e9e9e"></span>unbekannt</div></div>' +
        '<div>typischer Boden-pH des Ausgangsgesteins</div>';
    } else if (def.legend === "gbif") {
      h += '<div class="li"><span class="sw" style="background:#ff6f00;border-radius:50%"></span>Fund einer Speisepilz-Art (antippen)</div>' +
        '<div>Quelle GBIF; ab Zoomstufe 9</div>';
    } else if (def.legend === "schutz") {
      h += '<div>Farbige Flächen: Naturschutzgebiet oder Nationalpark.<br><b>Sammeln in NSG grundsätzlich verboten.</b></div>';
    } else if (def.legend === "img") {
      h += '<img src="' + esc(def.legendUrl) + '" alt="Legende" loading="lazy" onerror="this.style.display=\'none\'">';
    }
    return h + "</div>";
  }
  function renderLegends() {
    var ids = Object.keys(overlayLayers);
    // höchstens die zwei zuletzt eingeschalteten Legenden zeigen
    var defs = OVERLAYS.filter(function (o) { return ids.indexOf(o.id) >= 0; }).slice(-2);
    $("legendDock").innerHTML = defs.map(legendHtml).join("");
  }
  // Legende antippen = ein-/ausklappen
  $("legendDock").addEventListener("click", function (e) {
    var l = e.target.closest(".legend");
    if (l) l.classList.toggle("collapsed");
  });

  // ------------------------------------------------------------------
  // Ebenen-Menü
  // ------------------------------------------------------------------
  function renderLayerMenu() {
    $("baseList").innerHTML = BASEMAPS.map(function (b) {
      return '<label class="opt"><input type="radio" name="base" value="' + b.id + '"' +
        (state.base === b.id ? " checked" : "") + "> " + esc(b.name) + "</label>";
    }).join("");
    $("overlayList").innerHTML = OVERLAYS.map(function (o) {
      var on = !!overlayLayers[o.id];
      var op = Math.round((state.ov[o.id] != null ? state.ov[o.id] : o.opacity) * 100);
      return '<label class="opt"><input type="checkbox" data-ov="' + o.id + '"' + (on ? " checked" : "") + ">" +
        "<span>" + esc(o.name) + '<span class="sub">' + esc(o.src) + "</span></span></label>" +
        '<div class="opacity' + (on && o.type !== "gbif" ? "" : " hidden") + '" id="op-' + o.id + '">Deckkraft <input type="range" min="10" max="100" value="' +
        op + '" data-op="' + o.id + '"></div>';
    }).join("");
  }
  $("baseList").addEventListener("change", function (e) { if (e.target.name === "base") setBase(e.target.value); });
  $("overlayList").addEventListener("change", function (e) {
    var id = e.target.getAttribute("data-ov");
    if (id) {
      setOverlay(id, e.target.checked);
      $("op-" + id).classList.toggle("hidden", !e.target.checked || id === "funde");
    }
  });
  $("overlayList").addEventListener("input", function (e) {
    var id = e.target.getAttribute("data-op");
    if (id && overlayLayers[id] && overlayLayers[id].setOpacity) {
      var v = e.target.value / 100;
      overlayLayers[id].setOpacity(v);
      state.ov[id] = v;
      saveState();
    }
  });
  document.querySelectorAll("input[name=phstyle]").forEach(function (r) {
    r.checked = r.value === state.phstyle;
    r.addEventListener("change", function () { state.phstyle = r.value; saveState(); refreshPhLayers(); });
  });

  // ------------------------------------------------------------------
  // Datenabfragen für einen Punkt
  // ------------------------------------------------------------------
  function thuenenValue(ll, layer) {
    var d = 0.0005;
    var url = THUENEN + "?service=WMS&version=1.1.1&request=GetFeatureInfo&layers=" + encodeURIComponent(layer) +
      "&query_layers=" + encodeURIComponent(layer) + "&styles=&srs=EPSG:4326&bbox=" +
      (ll.lng - d) + "," + (ll.lat - d) + "," + (ll.lng + d) + "," + (ll.lat + d) +
      "&width=11&height=11&x=5&y=5&info_format=application/json&feature_count=1";
    return cached(layer + llKey(ll), 36e5, function () {
      return getJson(url).then(function (j) {
        var f = j && j.features && j.features[0];
        if (!f || !f.properties) return null;
        for (var k in f.properties) {
          var v = parseFloat(f.properties[k]);
          if (isFinite(v)) return v;
        }
        return null;
      });
    });
  }
  function fetchPh(ll, depth) {
    return thuenenValue(ll, depth === 1 ? "geonode:pH_map_30_100" : "geonode:pH_map_0_30").then(function (v) {
      return v != null && v > 2 && v < 11 ? v : null;
    });
  }
  function fetchBaum(ll) {
    return thuenenValue(ll, "geonode:Dominant_Species_Class").then(function (v) {
      if (v == null) return { wald: false };
      var b = BAUM[Math.round(v)];
      return b ? { wald: true, art: b.name, info: b } : { wald: false };
    });
  }
  function fetchGestein(ll) {
    function q(layerId) {
      var url = BGR_REST + "/geologie/guek250/MapServer/" + layerId + "/query?geometry=" + ll.lng + "," + ll.lat +
        "&geometryType=esriGeometryPoint&inSR=4326&spatialRel=esriSpatialRelIntersects" +
        "&outFields=klartext_kurz,klartext,gkart_legtxt_stat,p_zusatz&returnGeometry=false&f=json";
      return getJson(url).then(function (j) {
        var a = j && j.features && j.features[0] && j.features[0].attributes;
        if (!a) return null;
        var clean = function (s) { return s && String(s).trim() ? String(s).trim() : ""; };
        return {
          kurz: clean(a.klartext_kurz), text: clean(a.klartext),
          gruppe: clean(a.gkart_legtxt_stat), zusatz: clean(a.p_zusatz)
        };
      }).catch(function () { return null; });
    }
    return cached("geo" + llKey(ll), 36e5, function () {
      return Promise.all([q(8), q(7)]).then(function (r) {
        var basis = r[0], decke = r[1];
        if (!basis && !decke) return null;
        var basisG = basis ? gesteineAusText([basis.kurz, basis.text, basis.gruppe].join(" ")) : [];
        var deckeG = decke && decke.kurz ? gesteineAusText([decke.kurz, decke.text].join(" ")) : [];
        return { basis: basis, decke: decke && decke.kurz ? decke : null, basisG: basisG, deckeG: deckeG,
          // für die Bewertung zählt die oberste Schicht
          haupt: (deckeG[0] || basisG[0] || null) };
      });
    });
  }
  function fetchNfk(ll) {
    var d = 0.01;
    var url = BGR_REST + "/boden/nfkwe1000/MapServer/identify?geometry=" + ll.lng + "," + ll.lat +
      "&geometryType=esriGeometryPoint&sr=4326&layers=all&tolerance=1&mapExtent=" +
      (ll.lng - d) + "," + (ll.lat - d) + "," + (ll.lng + d) + "," + (ll.lat + d) +
      "&imageDisplay=400,400,96&returnGeometry=false&f=json";
    return cached("nfk" + llKey(ll), 36e5, function () {
      return getJson(url).then(function (j) {
        var a = j && j.results && j.results[0] && j.results[0].attributes;
        if (!a) return null;
        for (var k in a) {
          if (/pixel value/i.test(k)) {
            var v = parseFloat(String(a[k]).replace(/\./g, "").replace(",", "."));
            if (String(a[k]).indexOf(",") < 0) v = parseFloat(a[k]);
            return isFinite(v) && v >= 0 && v < 1000 ? v : null;
          }
        }
        return null;
      });
    });
  }
  function nfkKlasse(v) {
    if (v == null) return "";
    if (v < 50) return "sehr gering";
    if (v < 90) return "gering";
    if (v < 140) return "mittel";
    if (v < 200) return "hoch";
    if (v < 270) return "sehr hoch";
    return "äußerst hoch";
  }
  function fetchWetter(ll) {
    var lat = Math.round(ll.lat * 10) / 10, lng = Math.round(ll.lng * 10) / 10;
    var url = "https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lng +
      "&daily=precipitation_sum,temperature_2m_max,temperature_2m_min,et0_fao_evapotranspiration" +
      "&hourly=soil_moisture_3_to_9cm,soil_moisture_9_to_27cm" +
      "&past_days=30&forecast_days=8&timezone=Europe%2FBerlin";
    return cached("wx" + lat + "," + lng, 18e5, function () {
      return getJson(url).then(function (j) {
        var d = j.daily, n = d.time.length, pastN = 30;
        var rain = d.precipitation_sum.map(function (x) { return x || 0; });
        var tmean = d.temperature_2m_max.map(function (mx, i) {
          var mn = d.temperature_2m_min[i];
          return mx != null && mn != null ? (mx + mn) / 2 : null;
        });
        function sum(a, from, to) { var s = 0; for (var i = from; i < to; i++) s += a[i]; return s; }
        var r7 = sum(rain, pastN - 7, pastN), r14 = sum(rain, pastN - 14, pastN), r30 = sum(rain, 0, pastN);
        var t7 = tmean.slice(pastN - 7, pastN).filter(function (x) { return x != null; });
        var t7m = t7.length ? t7.reduce(function (a, b) { return a + b; }, 0) / t7.length : null;
        // ergiebiger Regen vor 4–21 Tagen?
        var guterRegen = null;
        for (var i = pastN - 1; i >= 0; i--) {
          var alter = pastN - i;
          if (alter >= 4 && alter <= 21 && rain[i] >= 10) { guterRegen = { alter: alter, mm: rain[i] }; break; }
        }
        var vorhersage = sum(rain, pastN + 1, Math.min(n, pastN + 4));
        // Verdunstung (FAO-Referenz) → Wasserbilanz der letzten 14 Tage
        var et0 = (d.et0_fao_evapotranspiration || []).map(function (x) { return x || 0; });
        var et14 = et0.length >= pastN ? sum(et0, pastN - 14, pastN) : null;
        var tmin = d.temperature_2m_min;
        var frost7 = 0, fcFrost = 0, fcT = [], fcRain = 0;
        for (var fi = pastN - 7; fi < pastN; fi++) if (tmin[fi] != null && tmin[fi] < 0) frost7++;
        for (var fj = pastN + 1; fj < n; fj++) {
          if (tmin[fj] != null && tmin[fj] < 0) fcFrost++;
          if (tmean[fj] != null) fcT.push(tmean[fj]);
          fcRain += rain[fj];
        }
        var fcTm = fcT.length ? fcT.reduce(function (a, b) { return a + b; }, 0) / fcT.length : null;
        var r5 = sum(rain, pastN - 5, pastN);
        // aktuelle Bodenfeuchte (Modell, m³/m³) – Mittel aus 3–9 cm und 9–27 cm
        var feuchte = null, feuchteVor7 = null;
        if (j.hourly && j.hourly.time) {
          var h = j.hourly, now = new Date();
          var pad = function (x) { return (x < 10 ? "0" : "") + x; };
          var key = now.getFullYear() + "-" + pad(now.getMonth() + 1) + "-" + pad(now.getDate()) + "T" + pad(now.getHours()) + ":00";
          var idx = h.time.indexOf(key);
          if (idx < 0) idx = pastN * 24 + now.getHours();
          var fv = function (k) {
            var a = h.soil_moisture_3_to_9cm && h.soil_moisture_3_to_9cm[k], b = h.soil_moisture_9_to_27cm && h.soil_moisture_9_to_27cm[k];
            if (a == null && b == null) return null;
            if (a == null) return b;
            if (b == null) return a;
            return (a + b) / 2;
          };
          feuchte = fv(idx);
          feuchteVor7 = idx - 168 >= 0 ? fv(idx - 168) : null;
        }
        return { r5: r5, r7: r7, r14: r14, r30: r30, t7: t7m, guterRegen: guterRegen, vorhersage3: vorhersage,
          letzte: rain.slice(pastN - 14, pastN), feuchte: feuchte, feuchteVor7: feuchteVor7,
          et14: et14, bilanz14: et14 != null ? r14 - et14 : null, frost7: frost7,
          fcFrost: fcFrost, fcT: fcTm, fcRain: fcRain };
      });
    });
  }

  /** Pilzwetter-Aussicht für die nächsten 1–2 Wochen (Faustregeln: ≥ 10 l/m², 10–25 °C, kein Frost) */
  function aussicht(w) {
    if (!w || w.fcT == null) return null;
    var mild = w.fcT >= 8 && w.fcT <= 22;
    var nass = w.r5 >= 10 || w.vorhersage3 >= 10;
    if (w.fcFrost >= 2 || w.fcT < 5) return { stufe: 0, text: "Frost bzw. Kälte in Sicht – das Pilzwachstum lässt nach. Am ehesten noch frostharte Arten wie Trompetenpfifferling oder Austernseitling." };
    if (w.feuchte != null && w.feuchte >= 0.24 && mild) return { stufe: 2, text: "Boden ist feucht und es bleibt mild – gute Bedingungen für die nächsten 1–2 Wochen." };
    if (nass && mild) return { stufe: 2, text: "Ergiebiger Regen (gefallen oder erwartet) bei milden Temperaturen – in etwa 1–2 Wochen steigen die Chancen deutlich." };
    if (w.fcT > 24) return { stufe: 1, text: "Sehr warm – eher früh morgens suchen, an Nordhängen und in feuchten Tälern." };
    if (!nass && w.r14 < 15 && w.fcRain < 10) return { stufe: 0, text: "Zu trocken und kein nennenswerter Regen in Sicht – eher schlechte Aussichten." };
    return { stufe: 1, text: "Durchschnittliche Aussichten – nach dem nächsten ergiebigen Regen (≥ 10 l/m²) wird es besser." };
  }
  function aussichtHtml(w) {
    var a = aussicht(w);
    if (!a) return "";
    var farbe = ["#c62828", "#f9a825", "#2e7d32"][a.stufe], sym = ["▼", "►", "▲"][a.stufe];
    return '<div class="aussicht" style="border-left-color:' + farbe + '"><b style="color:' + farbe + '">' + sym +
      " Pilzwetter-Aussicht</b><br>" + esc(a.text) + '<br><small>Vorhersage 7 Tage: Ø ' + num(w.fcT, 1) + " °C, " +
      num(w.fcRain) + " mm Regen" + (w.fcFrost ? ", " + w.fcFrost + " Frostnächte" : "") + "</small></div>";
  }

  // ------------------------------------------------------------------
  // Gelände: Höhe, Hangneigung, Exposition (Open-Meteo Elevation, 90-m-DGM)
  // ------------------------------------------------------------------
  function elevations(lls) {
    var chunks = [];
    for (var i = 0; i < lls.length; i += 100) chunks.push(lls.slice(i, i + 100));
    return Promise.all(chunks.map(function (c) {
      var url = "https://api.open-meteo.com/v1/elevation?latitude=" +
        c.map(function (p) { return p.lat.toFixed(5); }).join(",") + "&longitude=" +
        c.map(function (p) { return p.lng.toFixed(5); }).join(",");
      return getJson(url).then(function (j) { return j.elevation; });
    })).then(function (parts) { return [].concat.apply([], parts); });
  }
  function nachbarn(ll) {
    var dLat = 100 / 111320, dLng = 100 / (111320 * Math.cos(ll.lat * Math.PI / 180));
    return [ll, L.latLng(ll.lat + dLat, ll.lng), L.latLng(ll.lat - dLat, ll.lng),
      L.latLng(ll.lat, ll.lng + dLng), L.latLng(ll.lat, ll.lng - dLng)];
  }
  function geländeAus(z) { // z = [Mitte, N, S, O, W]
    if (!z || z.some(function (v) { return v == null || !isFinite(v); })) return null;
    var dzdx = (z[3] - z[4]) / 200, dzdy = (z[1] - z[2]) / 200;
    var neigung = Math.atan(Math.sqrt(dzdx * dzdx + dzdy * dzdy)) * 180 / Math.PI;
    var expo = (Math.atan2(-dzdx, -dzdy) * 180 / Math.PI + 360) % 360; // Richtung, in die der Hang abfällt
    var mittel = (z[1] + z[2] + z[3] + z[4]) / 4;
    var form = z[0] < mittel - 2 ? "Senke/Tal" : z[0] > mittel + 2 ? "Kuppe/Rücken" : "";
    return { hoehe: z[0], neigung: neigung, expo: expo, form: form };
  }
  function fetchGelaende(ll) {
    return cached("gel" + llKey(ll), 864e5, function () {
      return elevations(nachbarn(ll)).then(geländeAus);
    });
  }
  function himmelsrichtung(deg) {
    return ["N", "NO", "O", "SO", "S", "SW", "W", "NW"][Math.round(deg / 45) % 8];
  }

  // ------------------------------------------------------------------
  // Gemeldete Pilzfunde (GBIF – u. a. iNaturalist, Pilzkartierungen)
  // ------------------------------------------------------------------
  var gbifKeys = store.get("pk_gbif_keys", null);
  function gbifKeysLaden() {
    if (gbifKeys) return Promise.resolve(gbifKeys);
    return Promise.all(PILZARTEN.map(function (a) {
      return getJson("https://api.gbif.org/v1/species/match?kingdom=Fungi&name=" + encodeURIComponent(a.sci))
        .then(function (j) { return j && j.usageKey ? j.usageKey : null; }).catch(function () { return null; });
    })).then(function (keys) {
      var m = {};
      keys.forEach(function (k, i) { if (k) m[PILZARTEN[i].sci] = k; });
      if (Object.keys(m).length) { gbifKeys = m; store.set("pk_gbif_keys", m); }
      return m;
    });
  }
  function artZuFund(r) {
    var sp = (r.species || r.scientificName || "").toLowerCase();
    for (var i = 0; i < PILZARTEN.length; i++) {
      var a = PILZARTEN[i];
      if ((gbifKeys && (gbifKeys[a.sci] === r.speciesKey || gbifKeys[a.sci] === r.taxonKey)) || sp.indexOf(a.sci.toLowerCase()) === 0) return a;
    }
    return null;
  }
  /** Funde im Rechteck [süd, west, nord, ost] (max. 300) */
  function fetchFunde(s, w, n, e) {
    var k = [s, w, n, e].map(function (x) { return x.toFixed(3); }).join(",");
    return cached("gbif" + k, 36e5, function () {
      return gbifKeysLaden().then(function (keys) {
        var tk = Object.keys(keys).map(function (sci) { return "&taxonKey=" + keys[sci]; }).join("");
        if (!tk) return [];
        var url = "https://api.gbif.org/v1/occurrence/search?hasCoordinate=true&hasGeospatialIssue=false&limit=300" +
          "&decimalLatitude=" + s.toFixed(4) + "," + n.toFixed(4) + "&decimalLongitude=" + w.toFixed(4) + "," + e.toFixed(4) + tk;
        return getJson(url).then(function (j) {
          return (j.results || []).map(function (r) {
            return { lat: r.decimalLatitude, lng: r.decimalLongitude, art: artZuFund(r), datum: (r.eventDate || "").slice(0, 10),
              quelle: r.datasetName || r.publishingOrgKey || "GBIF", unsicher: r.coordinateUncertaintyInMeters };
          }).filter(function (f) { return f.art && isFinite(f.lat) && isFinite(f.lng); });
        });
      });
    });
  }
  function fundeUm(ll, radiusM) {
    var dLat = radiusM / 111320, dLng = radiusM / (111320 * Math.cos(ll.lat * Math.PI / 180));
    return fetchFunde(ll.lat - dLat, ll.lng - dLng, ll.lat + dLat, ll.lng + dLng);
  }

  // ------------------------------------------------------------------
  // Schutzgebiete (BfN)
  // ------------------------------------------------------------------
  var BFN = "https://geodienste.bfn.de/ogc/wms/schutzgebiet";
  function fetchSchutz(ll) {
    function q(layer) {
      var d = 0.0005;
      var url = BFN + "?SERVICE=WMS&VERSION=1.1.1&REQUEST=GetFeatureInfo&LAYERS=" + layer + "&QUERY_LAYERS=" + layer +
        "&STYLES=&SRS=EPSG:4326&BBOX=" + (ll.lng - d) + "," + (ll.lat - d) + "," + (ll.lng + d) + "," + (ll.lat + d) +
        "&WIDTH=11&HEIGHT=11&X=5&Y=5&INFO_FORMAT=application/geo%2Bjson&FEATURE_COUNT=1";
      return getJson(url).then(function (j) {
        var f = j && j.features && j.features[0];
        if (!f) return null;
        var p = f.properties || {}, name = "";
        for (var k in p) { if (/name/i.test(k) && p[k] && String(p[k]).trim()) { name = String(p[k]).trim(); break; } }
        return name || "ohne Namen";
      });
    }
    return cached("nsg" + llKey(ll), 864e5, function () {
      return Promise.all([q("Naturschutzgebiete").catch(function () { return undefined; }),
        q("Nationalparke").catch(function () { return undefined; })]).then(function (r) {
        return { nsg: r[0], np: r[1], fehler: r[0] === undefined && r[1] === undefined };
      });
    });
  }

  // ------------------------------------------------------------------
  // Bewertung
  // ------------------------------------------------------------------
  function bewerte(d) {
    var parts = [], total = 0;
    function add(name, p, max, why) { parts.push({ name: name, p: Math.round(p), max: max, why: why }); total += p; }
    var w = d.wetter;

    // 1 Wald & Baumart (25)
    var waldBekannt = d.baum !== undefined && d.baum !== "fehler";
    if (!waldBekannt) add("Wald & Baumart", 10, 25, "Walddaten nicht abrufbar – neutral bewertet.");
    else if (!d.baum.wald) add("Wald & Baumart", 0, 25, "Laut Satellitenkarte kein Wald an dieser Stelle.");
    else {
      var bp = d.baum.info.myk ? 25 : d.baum.info.punkte;
      add("Wald & Baumart", bp, 25, d.baum.art + (d.baum.info.myk ? " – wichtiger Mykorrhiza-Partner vieler Speisepilze." : " – weniger Mykorrhiza-Pilze."));
    }

    // 2 Boden-pH (15), Fallback Gestein
    var ph = d.ph0;
    if (ph != null) {
      var pp = ph < 3.5 ? 6 : ph < 4 ? 12 : ph <= 6 ? 15 : ph <= 7 ? 12 : 9;
      add("Boden-pH", pp, 15, "pH " + num(ph, 1) + " (" + phKlasse(ph) + ")" +
        (ph > 7 ? " – Kalkboden: andere, kalkliebende Arten." : ph >= 4 && ph <= 6 ? " – ideal für Steinpilz & Pfifferling." : ""));
    } else if (d.gestein && d.gestein.haupt) {
      var k = d.gestein.haupt.klasse;
      var gp = { "stark sauer": 9, "sauer": 13, "schwach sauer": 13, "neutral": 11, "basisch": 9 }[k];
      add("Boden-pH", gp, 15, "Keine pH-Messwerte – abgeleitet aus Gestein: " + d.gestein.haupt.name + " (" + k + ").");
    } else add("Boden-pH", 8, 15, "Keine Daten – neutral bewertet.");

    // 3 nFK (10)
    if (d.nfk != null) {
      var np = d.nfk < 50 ? 3 : d.nfk < 90 ? 5 : d.nfk < 140 ? 8 : d.nfk < 270 ? 10 : 8;
      add("Wasserspeicher (nFK)", np, 10, num(d.nfk) + " mm (" + nfkKlasse(d.nfk) + ")" + (d.nfk >= 270 ? " – evtl. staunass." : ""));
    } else add("Wasserspeicher (nFK)", 5, 10, "Keine Daten – neutral bewertet.");

    if (w) {
      // 4 Regen (15)
      var rp = w.r14 < 5 ? 0 : w.r14 < 15 ? 5 : w.r14 < 30 ? 9 : w.r14 < 60 ? 12 : 13;
      var why = num(w.r14) + " mm in 14 Tagen";
      if (w.guterRegen) { rp += 3; why += ", ergiebiger Regen vor " + w.guterRegen.alter + " Tagen (" + num(w.guterRegen.mm) + " mm)"; }
      if (w.r7 > 80) { rp -= 3; why += ", sehr viel Regen in 7 Tagen (> 80 mm hemmt eher)"; }
      if (w.bilanz14 != null) {
        why += "; Wasserbilanz (Regen − Verdunstung) " + (w.bilanz14 >= 0 ? "+" : "") + num(w.bilanz14) + " mm";
        if (w.bilanz14 < -25) rp -= 2;
      }
      add("Regen", Math.max(0, Math.min(15, rp)), 15, why + ".");
      // 5 Bodenfeuchte (10)
      if (w.feuchte != null) {
        var f = w.feuchte, fp = f < 0.12 ? 1 : f < 0.18 ? 4 : f < 0.24 ? 7 : f < 0.34 ? 10 : 8;
        var trend = w.feuchteVor7 != null ? (f - w.feuchteVor7 > 0.02 ? ", steigend" : f - w.feuchteVor7 < -0.02 ? ", fallend" : ", gleichbleibend") : "";
        add("Bodenfeuchte aktuell", fp, 10, num(f * 100) + " Vol.-% in 3–27 cm Tiefe (" +
          (f < 0.12 ? "sehr trocken" : f < 0.18 ? "trocken" : f < 0.24 ? "mäßig feucht" : f < 0.34 ? "feucht" : "sehr nass") + trend + ").");
      } else add("Bodenfeuchte aktuell", 5, 10, "Keine Daten – neutral bewertet.");
      // 6 Temperatur (10)
      var t = w.t7, tp = 0;
      if (t != null) tp = t >= 10 && t <= 18 ? 10 : (t >= 6 && t < 10) || (t > 18 && t <= 22) ? 6 : (t >= 3 && t < 6) || (t > 22 && t <= 25) ? 3 : 0;
      var frostTxt = "";
      if (w.frost7 >= 2) { tp = Math.max(0, tp - 4); frostTxt = ", " + w.frost7 + " Frostnächte"; }
      else if (w.frost7 === 1) { tp = Math.max(0, tp - 1); frostTxt = ", 1 Frostnacht"; }
      add("Temperatur", tp, 10, "Ø " + num(t, 1) + " °C in den letzten 7 Tagen" + frostTxt + (tp === 10 ? " – optimal." : "."));
    } else {
      add("Regen", 7, 15, "Wetterdaten nicht abrufbar – neutral bewertet.");
      add("Bodenfeuchte aktuell", 5, 10, "Wetterdaten nicht abrufbar.");
      add("Temperatur", 5, 10, "Wetterdaten nicht abrufbar.");
    }

    // 7 Gelände (7): Exposition je nach Witterung
    var g = d.gelaende;
    if (g) {
      var trocken = w && (w.r14 < 20 || (w.t7 != null && w.t7 > 17) || (w.feuchte != null && w.feuchte < 0.18));
      var kuehl = w && w.t7 != null && w.t7 < 9;
      var nord = g.expo >= 292.5 || g.expo < 112.5, sued = g.expo >= 135 && g.expo < 247.5;
      var gp2, gw;
      if (g.neigung < 3) { gp2 = 4; gw = "eben"; }
      else if (trocken) { gp2 = nord ? 7 : sued ? 1 : 4; gw = nord ? "schattiger Hang – hält bei Trockenheit die Feuchte" : sued ? "sonniger Hang – trocknet schnell aus" : "Hang"; }
      else if (kuehl) { gp2 = sued ? 7 : nord ? 3 : 4; gw = sued ? "sonniger Hang – wärmer in der kühlen Jahreszeit" : nord ? "Schattenhang – bei Kälte ungünstig" : "Hang"; }
      else { gp2 = 5; gw = "Hang"; }
      if (g.form === "Senke/Tal" && trocken) { gp2 += 2; gw += ", Senke (feuchter)"; }
      if (g.form === "Kuppe/Rücken" && trocken) { gp2 -= 1; gw += ", Kuppe (trockener)"; }
      gp2 = Math.max(0, Math.min(7, gp2));
      add("Gelände", gp2, 7, num(g.hoehe) + " m ü. NN, " + (g.neigung < 3 ? "" : num(g.neigung) + "° nach " + himmelsrichtung(g.expo) + " – ") + gw + ".");
    } else add("Gelände", 3, 7, "Keine Höhendaten – neutral bewertet.");

    // 8 Gemeldete Funde in der Nähe (8)
    if (d.funde != null) {
      var nf = d.funde.length, fu = nf === 0 ? 2 : nf === 1 ? 5 : nf < 5 ? 7 : 8;
      var arten = {};
      d.funde.forEach(function (x) { arten[x.art.de] = (arten[x.art.de] || 0) + 1; });
      add("Funde in der Nähe", fu, 8, nf === 0 ? "Keine gemeldeten Speisepilz-Funde im Umkreis von 1,5 km (heißt nicht, dass es keine gibt)."
        : nf + " gemeldete Funde im Umkreis 1,5 km: " + Object.keys(arten).slice(0, 4).map(function (a) { return a + " (" + arten[a] + ")"; }).join(", ") + ".");
    } else add("Funde in der Nähe", 3, 8, "Funddaten nicht abrufbar – neutral bewertet.");

    if (waldBekannt && !d.baum.wald) total = Math.min(total, 15);
    return { score: Math.round(Math.max(0, Math.min(100, total))), parts: parts };
  }

  function distM(a, b) {
    var dy = (a.lat - b.lat) * 111320, dx = (a.lng - b.lng) * 111320 * Math.cos(a.lat * Math.PI / 180);
    return Math.sqrt(dx * dx + dy * dy);
  }
  /** passende Arten, die gerade Saison haben */
  function saisonArten(klasse, baumArt) {
    var m = new Date().getMonth() + 1;
    return PILZARTEN.filter(function (a) {
      var inSaison = a.von <= a.bis ? m >= a.von && m <= a.bis : m >= a.von || m <= a.bis;
      var boden = !klasse || a.boden.indexOf(klasse) >= 0;
      var baum = !baumArt || !a.baum || a.baum.indexOf(baumArt) >= 0;
      return inSaison && boden && baum;
    });
  }

  function safe(p) { return p.catch(function () { return "fehler"; }); }

  function analysiere(ll, mitDetails, vorab) {
    vorab = vorab || {};
    var q = abfragePunkt(ll); // im Datensparmodus auf ~100 m gerundet
    var jobs = [safe(fetchBaum(q)), safe(fetchPh(q, 0)), safe(fetchNfk(q)),
      vorab.wetter !== undefined ? Promise.resolve(vorab.wetter) : safe(fetchWetter(q)),
      vorab.gelaende !== undefined ? Promise.resolve(vorab.gelaende) : safe(fetchGelaende(q)),
      vorab.funde !== undefined ? Promise.resolve(vorab.funde) : safe(fundeUm(q, 1500).then(function (list) {
        return list.filter(function (f) { return distM(ll, f) <= 1500; });
      }))];
    if (mitDetails) { jobs.push(safe(fetchPh(q, 1))); jobs.push(safe(fetchGestein(q))); jobs.push(safe(fetchSchutz(q))); }
    return Promise.all(jobs).then(function (r) {
      var nz = function (x) { return x === "fehler" || x === undefined ? null : x; };
      var d = { ll: ll, baum: r[0], ph0: nz(r[1]), nfk: nz(r[2]), wetter: nz(r[3]), gelaende: nz(r[4]), funde: nz(r[5]),
        ph1: mitDetails ? nz(r[6]) : null, gestein: mitDetails ? nz(r[7]) : null, schutz: mitDetails ? nz(r[8]) : null,
        fehler: r.filter(function (x) { return x === "fehler"; }).length };
      d.bew = bewerte(d);
      return d;
    });
  }

  // ------------------------------------------------------------------
  // Standort-Analyse (Detailansicht)
  // ------------------------------------------------------------------
  var clickMarker = null;
  function zeigeAnalyse(ll) {
    if (clickMarker) map.removeLayer(clickMarker);
    clickMarker = L.circleMarker(ll, { radius: 9, color: "#fff", weight: 3, fillColor: "#2f6b3a", fillOpacity: 1 }).addTo(map);
    $("detailBody").innerHTML = '<h2>Standort-Analyse</h2><p><span class="spinner"></span>Frage Karten- und Wetterdaten ab …</p>';
    openSheet("detail");
    analysiere(ll, true).then(function (d) { renderDetail(d); }).catch(function (e) {
      $("detailBody").innerHTML = "<h2>Standort-Analyse</h2><p>Fehler: " + esc(e.message) + "</p>";
    });
  }

  function renderDetail(d) {
    var b = d.bew, ll = d.ll;
    var h = '<div class="bigscore"><div class="scorebadge" style="background:' + scoreColor(b.score) + '">' + b.score + "</div>" +
      '<div><div class="lbl">' + scoreLabel(b.score) + '</div><div class="coords">' +
      ll.lat.toFixed(5) + ", " + ll.lng.toFixed(5) + "</div></div></div>";
    if (d.schutz && (d.schutz.nsg || d.schutz.np)) {
      h += '<div class="card warnbox">⚠️ ' + (d.schutz.nsg ? "<b>Naturschutzgebiet „" + esc(d.schutz.nsg) + "“</b> – Pilze sammeln ist hier grundsätzlich verboten." : "") +
        (d.schutz.np ? (d.schutz.nsg ? "<br>" : "") + "<b>Nationalpark „" + esc(d.schutz.np) + "“</b> – Wegegebot und Sammelverbote je nach Zone beachten." : "") + "</div>";
    }
    h += b.parts.map(function (p) {
      return '<div class="part"><div class="row"><span>' + esc(p.name) + "</span><b>" + p.p + " / " + p.max + "</b></div>" +
        '<div class="meter"><div style="width:' + Math.round(100 * p.p / p.max) + "%;background:" + scoreColor(100 * p.p / p.max) + '"></div></div>' +
        '<div class="why">' + esc(p.why) + "</div></div>";
    }).join("");

    // Pilz-Tendenz
    var klasse = d.ph0 != null ? phKlasse(d.ph0) : d.gestein && d.gestein.haupt ? d.gestein.haupt.klasse : null;
    var tend = [];
    if (klasse) tend.push("<b>Boden (" + esc(klasse) + "):</b> " + esc(PILZ_TENDENZ[klasse]));
    if (d.baum && d.baum.wald && BAUM_PILZE[d.baum.art]) tend.push("<b>Bei " + esc(d.baum.art) + ":</b> " + esc(BAUM_PILZE[d.baum.art]));
    var saison = saisonArten(klasse, d.baum && d.baum.wald ? d.baum.art : null);
    if (saison.length) tend.push("<b>Jetzt in Saison &amp; passend hier:</b> " + saison.map(function (a) {
      return esc(a.de) + (a.gefahr === "toedlich" ? " ☠️" : "");
    }).join(", ") + (saison.some(function (a) { return a.gefahr === "toedlich"; }) ? '<br><small>☠️ = tödlich giftiger Doppelgänger – siehe Wissen → Pilzarten</small>' : ""));
    if (tend.length) h += '<div class="tendenz">' + tend.join("<br>") + '<br><small>⚠️ Nur sicher bestimmte Pilze essen.</small></div>';
    h += aussichtHtml(d.wetter);

    // Datentabelle
    var rows = [];
    rows.push(["Baumart (Satellit)", d.baum === "fehler" ? "nicht abrufbar" : d.baum.wald ? d.baum.art : "kein Wald erkannt"]);
    rows.push(["Boden-pH 0–30 cm", d.ph0 != null ? num(d.ph0, 1) + " – " + phKlasse(d.ph0) : "keine Daten"]);
    rows.push(["Boden-pH 30–100 cm", d.ph1 != null ? num(d.ph1, 1) + " – " + phKlasse(d.ph1) : "keine Daten"]);
    if (d.gestein) {
      var g = d.gestein;
      var chips = function (arr) {
        return arr.map(function (x) {
          return '<span class="chip"><span class="dot" style="background:' + PH_KLASSEN[x.klasse].farbe + '"></span>' +
            esc(x.name) + " · pH " + esc(x.ph) + "</span>";
        }).join(" ");
      };
      if (g.decke) rows.push(["Deckschicht", esc(g.decke.kurz) + (g.deckeG.length ? '<div class="chips">' + chips(g.deckeG) + "</div>" : ""), true]);
      if (g.basis) rows.push(["Gestein", esc(g.basis.kurz || g.basis.gruppe) +
        (g.basis.text && g.basis.text !== g.basis.kurz ? '<br><small>' + esc(g.basis.text) + "</small>" : "") +
        (g.basisG.length ? '<div class="chips">' + chips(g.basisG) + "</div>" : ""), true]);
    } else rows.push(["Gestein", "keine Daten"]);
    rows.push(["Nutzbare Feldkapazität", d.nfk != null ? num(d.nfk) + " mm (" + nfkKlasse(d.nfk) + ")" : "keine Daten"]);
    if (d.wetter) {
      var w = d.wetter;
      rows.push(["Regen 7 / 14 / 30 Tage", num(w.r7) + " / " + num(w.r14) + " / " + num(w.r30) + " mm"]);
      rows.push(["Regen nächste 3 Tage", num(w.vorhersage3) + " mm (Vorhersage)"]);
      rows.push(["Temperatur Ø 7 Tage", num(w.t7, 1) + " °C" + (w.frost7 ? " (" + w.frost7 + " Frostnächte)" : "")]);
      if (w.bilanz14 != null) rows.push(["Wasserbilanz 14 Tage", num(w.r14) + " mm Regen − " + num(w.et14) + " mm Verdunstung = " +
        (w.bilanz14 >= 0 ? "+" : "") + num(w.bilanz14) + " mm"]);
      if (w.feuchte != null) rows.push(["Bodenfeuchte (Modell)", num(w.feuchte * 100) + " Vol.-%" +
        (w.feuchteVor7 != null ? " (vor 7 Tagen " + num(w.feuchteVor7 * 100) + " %)" : "")]);
    }
    if (d.gelaende) {
      var g2 = d.gelaende;
      rows.push(["Höhe / Hang", num(g2.hoehe) + " m ü. NN" + (g2.neigung >= 3 ? ", " + num(g2.neigung) + "° Neigung nach " + himmelsrichtung(g2.expo) : ", eben") +
        (g2.form ? ", " + g2.form : "")]);
    }
    if (d.funde && d.funde.length) {
      var fl = d.funde.slice().sort(function (a, c) { return (c.datum || "").localeCompare(a.datum || ""); }).slice(0, 6);
      rows.push(["Gemeldete Funde (1,5 km)", fl.map(function (f) {
        return esc(f.art.de) + " · " + esc(f.datum || "?") + " · " + num(distM(ll, f) / 1000, 1) + " km";
      }).join("<br>"), true]);
    }
    if (d.schutz && !d.schutz.fehler && !d.schutz.nsg && !d.schutz.np) rows.push(["Schutzgebiet", "kein Naturschutzgebiet / Nationalpark"]);
    h += '<table class="kv">' + rows.map(function (r) {
      return "<tr><td>" + esc(r[0]) + "</td><td>" + (r[2] ? r[1] : esc(r[1])) + "</td></tr>";
    }).join("") + "</table>";
    if (d.fehler) h += '<p class="hint">Einige Dienste haben nicht geantwortet – Werte dort neutral bewertet.</p>';

    h += '<div class="btnrow">' +
      '<button class="btn primary" data-act="merken">⭐ Fundort merken</button>' +
      '<button class="btn" data-act="nav">🧭 Navigieren</button>' +
      '<button class="btn" data-act="topo">⛰️ topographic-map</button></div>';
    $("detailBody").innerHTML = h;
    $("detailBody").onclick = function (e) {
      var a = e.target.getAttribute("data-act");
      if (a === "merken") fundortMerken(ll, b.score);
      if (a === "nav") navigiere(ll);
      if (a === "topo") openWeb(topoUrl(ll, 15), "topographic-map.com");
    };
  }

  map.on("click", function (e) { zeigeAnalyse(e.latlng); });

  // ------------------------------------------------------------------
  // Pilz-Chancen: Kartenausschnitt scannen
  // ------------------------------------------------------------------
  var scanLayer = L.layerGroup().addTo(map);
  var scanning = false;

  function renderWetterBox(w, ort) {
    if (!w) { $("weatherBox").innerHTML = ""; return; }
    var bars = w.letzte.map(function (mm) {
      var hgt = Math.min(40, Math.round(mm * 2));
      return '<span title="' + num(mm, 1) + ' mm" style="display:inline-block;width:6%;margin-right:1%;height:' + Math.max(2, hgt) +
        'px;background:#1e88e5;border-radius:2px 2px 0 0;vertical-align:bottom"></span>';
    }).join("");
    $("weatherBox").innerHTML = '<div class="card"><b>Wetter ' + esc(ort) + "</b><br>" +
      "Regen 7 / 14 / 30 Tage: <b>" + num(w.r7) + " / " + num(w.r14) + " / " + num(w.r30) + " mm</b><br>" +
      "Ø Temperatur 7 Tage: <b>" + num(w.t7, 1) + " °C</b> · Vorhersage 3 Tage: <b>" + num(w.vorhersage3) + " mm</b>" +
      (w.bilanz14 != null ? "<br>Wasserbilanz 14 Tage (Regen − Verdunstung): <b>" + (w.bilanz14 >= 0 ? "+" : "") + num(w.bilanz14) + " mm</b>" : "") +
      (w.feuchte != null ? "<br>Bodenfeuchte: <b>" + num(w.feuchte * 100) + " Vol.-%</b>" : "") +
      '<div style="height:44px;display:flex;align-items:flex-end;margin-top:6px">' + bars + "</div>" +
      '<div class="hint" style="margin:2px 0 0">Tagesregen der letzten 14 Tage (rechts = gestern)</div></div>' + aussichtHtml(w);
  }

  function scan() {
    if (scanning) return;
    if (map.getZoom() < 11) {
      toast("Bitte weiter hineinzoomen (mind. Zoomstufe 11), damit der Scan aussagekräftig ist.", 4000);
      closeSheets();
      return;
    }
    scanning = true;
    $("btnScan").disabled = true;
    scanLayer.clearLayers();
    $("scanResults").innerHTML = "";
    var b = map.getBounds();
    var size = map.getSize();
    var cols = 6, rows = Math.max(5, Math.min(9, Math.round(cols * size.y / size.x)));
    var pts = [];
    for (var r = 0; r < rows; r++) {
      for (var c = 0; c < cols; c++) {
        pts.push(L.latLng(
          b.getNorth() - (r + 0.5) * (b.getNorth() - b.getSouth()) / rows,
          b.getWest() + (c + 0.5) * (b.getEast() - b.getWest()) / cols));
      }
    }
    var radius = Math.max(8, Math.min(size.x / cols, size.y / rows) / 2.8);
    var done = 0, results = [];
    var prog = $("scanProgress");
    prog.classList.remove("hidden");
    function upd() {
      prog.querySelector(".bar").style.width = Math.round(100 * done / pts.length) + "%";
      prog.querySelector(".ptext").textContent = "Analysiere " + done + " / " + pts.length + " Punkte …";
    }
    upd();
    var wetterP = fetchWetter(map.getCenter()).then(function (w) { renderWetterBox(w, "im Ausschnitt"); return w; }).catch(function () { return null; });
    var alleNachbarn = [];
    pts.forEach(function (p) { alleNachbarn = alleNachbarn.concat(nachbarn(p)); });
    var hoehenP = elevations(alleNachbarn).catch(function () { return null; });
    var dLat = 1500 / 111320, dLng = 1500 / (111320 * Math.cos(b.getCenter().lat * Math.PI / 180));
    var fundeP = fetchFunde(b.getSouth() - dLat, b.getWest() - dLng, b.getNorth() + dLat, b.getEast() + dLng).catch(function () { return null; });

    Promise.all([wetterP, hoehenP, fundeP]).then(function (pre) {
     return Promise.all(pts.map(function (ll, pi) {
      var vorab = {
        wetter: pre[0],
        gelaende: pre[1] ? geländeAus(pre[1].slice(pi * 5, pi * 5 + 5)) : null,
        funde: pre[2] ? pre[2].filter(function (f) { return distM(ll, f) <= 1500; }) : null
      };
      return analysiere(ll, false, vorab).then(function (d) {
        results.push(d);
        var wald = d.baum && d.baum !== "fehler" && d.baum.wald;
        var m = L.circleMarker(ll, {
          radius: wald ? radius : radius * 0.4, weight: 1, color: "#fff",
          fillColor: wald ? scoreColor(d.bew.score) : "#777", fillOpacity: wald ? 0.8 : 0.6, bubblingMouseEvents: false
        }).bindTooltip(wald ? String(d.bew.score) : "kein Wald", { permanent: wald, direction: "center", className: wald ? "scoretip" : "" });
        m.on("click", function (e) { L.DomEvent.stopPropagation(e); zeigeAnalyse(ll); });
        scanLayer.addLayer(m);
      }).catch(function () {}).then(function () { done++; upd(); });
     }));
    }).then(function () {
      scanning = false;
      $("btnScan").disabled = false;
      prog.classList.add("hidden");
      var top = results.filter(function (d) { return d.baum && d.baum !== "fehler" && d.baum.wald; })
        .sort(function (a, b2) { return b2.bew.score - a.bew.score; }).slice(0, 5);
      if (!top.length) {
        $("scanResults").innerHTML = '<div class="card">Im Ausschnitt wurde kein Wald gefunden – Karte verschieben und erneut scannen.</div>';
        return;
      }
      top.forEach(function (d, i) {
        scanLayer.addLayer(L.marker(d.ll, {
          icon: L.divIcon({ className: "pilz-marker", html: "🍄", iconSize: [24, 24], iconAnchor: [12, 28] }),
          zIndexOffset: 1000 - i
        }).on("click", function () { zeigeAnalyse(d.ll); }));
      });
      top.forEach(function (d, i) {
        fetchSchutz(d.ll).then(function (sg) {
          if (sg && (sg.nsg || sg.np)) {
            var el = document.getElementById("nsg-" + i);
            if (el) el.innerHTML = "⚠️ " + (sg.nsg ? "Naturschutzgebiet – Sammeln verboten" : "Nationalpark – Regeln beachten");
          }
        }).catch(function () {});
      });
      $("scanResults").innerHTML = "<h3>Beste Stellen im Ausschnitt</h3>" + top.map(function (d, i) {
        var info = [d.baum.art, d.ph0 != null ? "pH " + num(d.ph0, 1) : null, d.nfk != null ? "nFK " + num(d.nfk) + " mm" : null,
          d.gelaende && d.gelaende.neigung >= 3 ? "Hang " + himmelsrichtung(d.gelaende.expo) : null,
          d.funde && d.funde.length ? d.funde.length + " Funde" : null]
          .filter(Boolean).join(" · ");
        return '<div class="card spot"><div class="scorebadge" style="background:' + scoreColor(d.bew.score) + '">' + d.bew.score +
          '</div><div class="txt"><b>#' + (i + 1) + " " + scoreLabel(d.bew.score) + "</b><br>" + esc(info) +
          '<div class="nsg" id="nsg-' + i + '"></div></div>' +
          '<div class="acts"><button class="btn small" data-i="' + i + '" data-a="show">Details</button>' +
          '<button class="btn small" data-i="' + i + '" data-a="nav">Hin</button></div></div>';
      }).join("") + '<button class="btn small" id="btnClearScan">Scan-Punkte ausblenden</button>';
      $("scanResults").onclick = function (e) {
        var i = e.target.getAttribute("data-i"), a = e.target.getAttribute("data-a");
        if (e.target.id === "btnClearScan") { scanLayer.clearLayers(); $("scanResults").innerHTML = ""; return; }
        if (i == null) return;
        if (a === "show") { map.setView(top[i].ll, Math.max(map.getZoom(), 14)); zeigeAnalyse(top[i].ll); }
        if (a === "nav") navigiere(top[i].ll);
      };
      toast("Scan fertig – grüne Punkte = gute Chancen. Tippe einen Punkt für Details.", 4000);
    });
  }
  $("btnScan").addEventListener("click", scan);
  $("btnRateCenter").addEventListener("click", function () { zeigeAnalyse(map.getCenter()); });
  $("btnRateGps").addEventListener("click", function () {
    locate(function (ll) { zeigeAnalyse(ll); });
  });

  // ------------------------------------------------------------------
  // Wissen: Pilzarten, Gesteine, Notfall
  // ------------------------------------------------------------------
  $("phKlassenLegende").innerHTML = Object.keys(PH_KLASSEN).map(function (k) {
    return '<span class="chip"><span class="dot" style="background:' + PH_KLASSEN[k].farbe + '"></span>' +
      esc(k) + " (pH " + esc(PH_KLASSEN[k].bereich) + ")</span>";
  }).join("");
  function renderGesteine(filter) {
    var f = (filter || "").toLowerCase();
    var order = ["basisch", "neutral", "schwach sauer", "sauer", "stark sauer"];
    var list = GESTEINE.slice().sort(function (a, b) { return order.indexOf(a.klasse) - order.indexOf(b.klasse); })
      .filter(function (g) { return !f || (g.name + " " + g.gruppe + " " + g.info).toLowerCase().indexOf(f) >= 0; });
    $("gesteinListe").innerHTML = list.map(function (g) {
      var k = PH_KLASSEN[g.klasse];
      return '<div class="gestein" style="border-left-color:' + k.farbe + '"><div class="head"><span>' + esc(g.name) +
        '</span><span class="ph">pH ' + esc(g.ph) + '</span></div><div class="meta">' + esc(g.gruppe) + " · " + esc(g.klasse) +
        "</div><p>" + esc(g.info) + '</p><p class="meta">🍄 ' + esc(PILZ_TENDENZ[g.klasse]) + "</p></div>";
    }).join("") || '<p class="hint">Kein Gestein gefunden.</p>';
  }
  $("gesteinFilter").addEventListener("input", function (e) { renderGesteine(e.target.value); });
  renderGesteine("");

  function inSaison(a, m) { return a.von <= a.bis ? m >= a.von && m <= a.bis : m >= a.von || m <= a.bis; }
  function renderArten() {
    var m = new Date().getMonth() + 1, nurJetzt = $("nurSaison").checked;
    var list = PILZARTEN.filter(function (a) { return !nurJetzt || inSaison(a, m); });
    $("artenListe").innerHTML = list.map(function (a) {
      var monate = MONATE.map(function (mn, i) {
        var on = inSaison(a, i + 1);
        return '<span class="mo' + (on ? " on" : "") + (i + 1 === m ? " now" : "") + '" title="' + mn + '">' + mn.charAt(0) + "</span>";
      }).join("");
      var gef = a.gefahr === "toedlich" ? '<div class="gefahr t">☠️ Verwechslung mit tödlich giftigem Pilz möglich</div>'
        : a.gefahr === "giftig" ? '<div class="gefahr g">⚠️ giftige oder ungenießbare Doppelgänger</div>' : "";
      return '<div class="art"><div class="head"><span>' + esc(a.de) + '</span><i>' + esc(a.sci) + "</i></div>" +
        '<div class="monate">' + monate + "</div>" +
        '<div class="meta">Boden: ' + esc(a.boden.join(", ")) + (a.baum ? " · Bäume: " + esc(a.baum.join(", ")) : " · verschiedene Standorte") + "</div>" +
        gef + '<p class="vorsicht">' + esc(a.vorsicht) + "</p>" +
        (a.cs ? '<p class="meta">☢️ Reichert Cäsium-137 an – in Teilen Süddeutschlands noch deutlich belastet (BfS). Maßvoll essen.</p>' : "") + "</div>";
    }).join("") || '<p class="hint">Aktuell keine der aufgeführten Arten in Saison.</p>';
  }
  $("nurSaison").addEventListener("change", renderArten);
  renderArten();

  $("giftnotruf").innerHTML = GIFTNOTRUF.map(function (g) {
    return '<div class="card spot"><div class="txt"><b>' + esc(g.ort) + "</b><br><small>" + esc(g.laender) + "</small></div>" +
      '<div class="acts"><button class="btn small primary" data-tel="' + esc(g.tel.replace(/\s/g, "")) + '">📞 ' + esc(g.tel) + "</button></div></div>";
  }).join("");
  $("sheet-wissen").addEventListener("click", function (e) {
    var tel = e.target.getAttribute("data-tel");
    if (tel) oeffneExtern("tel:" + tel);
    var tab = e.target.getAttribute("data-tab");
    if (tab) {
      document.querySelectorAll("#sheet-wissen .seg button").forEach(function (b) { b.classList.toggle("active", b === e.target); });
      document.querySelectorAll("#sheet-wissen .tabpane").forEach(function (d) { d.classList.toggle("hidden", d.id !== "tab-" + tab); });
    }
    var link = e.target.getAttribute("data-link");
    if (link) openWeb(link, e.target.textContent);
  });

  // ------------------------------------------------------------------
  // Externe Seiten, Navigation
  // ------------------------------------------------------------------
  function openWeb(url, title) {
    if (window.AndroidBridge && window.AndroidBridge.openWeb) window.AndroidBridge.openWeb(url, title || "");
    else window.open(url, "_blank");
  }
  function oeffneExtern(url) {
    if (window.AndroidBridge && window.AndroidBridge.openExternal) window.AndroidBridge.openExternal(url);
    else window.open(url, "_blank");
  }
  /** Übergibt das Ziel an die Navigations-App des Handys (die App selbst sendet dabei nichts). */
  function navigiere(ll) {
    var geo = "geo:" + ll.lat.toFixed(6) + "," + ll.lng.toFixed(6) + "?q=" + ll.lat.toFixed(6) + "," + ll.lng.toFixed(6) + "(Pilzstelle)";
    if (window.AndroidBridge && window.AndroidBridge.openExternal) window.AndroidBridge.openExternal(geo);
    else window.open("https://www.openstreetmap.org/?mlat=" + ll.lat + "&mlon=" + ll.lng + "#map=16/" + ll.lat + "/" + ll.lng, "_blank");
  }
  function topoUrl(ll, z) {
    return "https://de-de.topographic-map.com/map-95z57/Deutschland/?center=" + ll.lat.toFixed(5) + "%2C" +
      ll.lng.toFixed(5) + "&zoom=" + (z || Math.max(10, Math.min(16, map.getZoom())));
  }
  var EXTERN = [
    { t: "Waldmonitor", s: "Baumarten & Waldzustand per Satellit", u: "https://map3d.remote-sensing-solutions.de/waldmonitor-deutschland/" },
    { t: "Topografische Karte", s: "topographic-map.com – Höhen an dieser Stelle", u: function () { return topoUrl(map.getCenter()); } },
    { t: "Regensumme 24 h", s: "Kachelmannwetter (Radar)", u: "https://kachelmannwetter.com/de/regensummen/niederschlagssumme-24std.html" },
    { t: "Regensummen", s: "Kachelmannwetter – Zeitraum wählbar", u: "https://kachelmannwetter.com/de/regensummen" },
    { t: "Akkumulierter Niederschlag", s: "Kachelmannwetter – Vorhersage", u: "https://kachelmannwetter.com/de/modellkarten/euro/deutschland/akkumulierter-niederschlag.html" },
    { t: "Niederschlag Messwerte", s: "Kachelmannwetter – Stationen 24 h", u: "https://kachelmannwetter.com/de/messwerte/niederschlagssumme.html" },
    { t: "Thünen-Atlas Boden-pH", s: "Originalkarte des Thünen-Instituts", u: "https://atlas.thuenen.de/catalogue/#/map/212" },
    { t: "BGR Geoviewer", s: "Geologie & Boden der BGR", u: "https://geoviewer.bgr.de/" },
    { t: "Pilzsachverständige", s: "DGfM – Pilzberatung in deiner Nähe", u: "https://www.dgfm-ev.de/service/pilzsachverstaendige" },
    { t: "Cäsium in Pilzen", s: "Bundesamt für Strahlenschutz", u: "https://www.bfs.de/DE/themen/ion/umwelt/lebensmittel/pilze-wildbret/pilze-wildbret.html" }
  ];
  $("externLinks").innerHTML = EXTERN.map(function (e, i) {
    return '<button data-i="' + i + '"><b>' + esc(e.t) + "</b><small>" + esc(e.s) + "</small></button>";
  }).join("");
  $("externLinks").addEventListener("click", function (ev) {
    var btn = ev.target.closest("button");
    if (!btn) return;
    var e = EXTERN[+btn.getAttribute("data-i")];
    openWeb(typeof e.u === "function" ? e.u() : e.u, e.t);
  });

  // ------------------------------------------------------------------
  // Fundorte (nur auf dem Handy gespeichert)
  // ------------------------------------------------------------------
  var fundLayer = L.layerGroup().addTo(map);
  function ladeFundorte() { return store.get("pk_fundorte", []); }
  function speichereFundorte(list) { store.set("pk_fundorte", list); renderFundorte(); }
  function renderFundorte() {
    var list = ladeFundorte();
    fundLayer.clearLayers();
    list.forEach(function (f) {
      L.marker([f.lat, f.lng], { icon: L.divIcon({ className: "pilz-marker", html: "⭐", iconSize: [24, 24], iconAnchor: [12, 12] }) })
        .bindPopup("<b>" + esc(f.name) + "</b>" + (f.art ? "<br>" + esc(f.art) : "") + "<br>" + esc(f.datum) + (f.notiz ? "<br>" + esc(f.notiz) : ""))
        .addTo(fundLayer);
    });
    // Statistik: welche Arten wann gefunden
    var arten = {};
    list.forEach(function (f) { if (f.art) arten[f.art] = (arten[f.art] || 0) + 1; });
    var stat = Object.keys(arten).sort(function (a, b) { return arten[b] - arten[a]; }).map(function (a) { return esc(a) + " (" + arten[a] + ")"; }).join(", ");
    $("fundortListe").innerHTML = (stat ? '<p class="hint">Deine Funde: ' + stat + "</p>" : "") + (list.length ? list.map(function (f, i) {
      return '<div class="card spot"><div class="txt"><b>' + esc(f.name) + "</b>" + (f.art ? " · " + esc(f.art) : "") + "<br>" + esc(f.datum) +
        (f.score != null ? " · Chance " + f.score : "") + (f.notiz ? "<br>" + esc(f.notiz) : "") + "</div>" +
        '<div class="acts"><button class="btn small" data-f="' + i + '" data-a="zeigen">Zeigen</button>' +
        '<button class="btn small" data-f="' + i + '" data-a="nav">Hin</button>' +
        '<button class="btn small" data-f="' + i + '" data-a="del">Löschen</button></div></div>';
    }).join("") : '<p class="hint">Noch keine Fundorte gespeichert.</p>');
  }
  $("fundortListe").addEventListener("click", function (e) {
    var i = e.target.getAttribute("data-f"), a = e.target.getAttribute("data-a");
    if (i == null) return;
    var list = ladeFundorte(), f = list[+i];
    if (!f) return;
    if (a === "zeigen") { closeSheets(); map.setView([f.lat, f.lng], 15); }
    if (a === "nav") navigiere(L.latLng(f.lat, f.lng));
    if (a === "del" && confirm("Fundort „" + f.name + "“ löschen?")) {
      list.splice(+i, 1);
      speichereFundorte(list);
    }
  });

  // Eingabedialog statt Browser-Abfragen
  $("dlgArt").innerHTML = '<option value="">– Art (optional) –</option>' + PILZARTEN.map(function (a) {
    return '<option>' + esc(a.de) + "</option>";
  }).join("") + "<option>andere Art</option>";
  var dlgPunkt = null, dlgScore = null;
  function fundortMerken(ll, score) {
    dlgPunkt = ll; dlgScore = score;
    $("dlgName").value = "";
    $("dlgNotiz").value = "";
    $("dlgArt").value = "";
    $("dlg").classList.remove("hidden");
  }
  $("dlgAbbrechen").addEventListener("click", function () { $("dlg").classList.add("hidden"); });
  $("dlgSpeichern").addEventListener("click", function () {
    if (!dlgPunkt) return;
    var art = $("dlgArt").value;
    var jetzt = new Date();
    var list = ladeFundorte();
    list.unshift({ name: $("dlgName").value.trim() || art || "Fundort", art: art, notiz: $("dlgNotiz").value.trim(),
      lat: +dlgPunkt.lat.toFixed(6), lng: +dlgPunkt.lng.toFixed(6), score: dlgScore,
      datum: jetzt.toLocaleDateString("de-DE"), zeit: jetzt.toISOString() });
    speichereFundorte(list);
    $("dlg").classList.add("hidden");
    toast("Fundort gespeichert ⭐ (nur auf diesem Handy)");
  });
  map.on("contextmenu", function (e) { fundortMerken(e.latlng, null); });

  // Export als GPX (für GPS-Geräte, Karten-Apps) – du bestimmst, wohin die Datei geht
  function xmlEsc(t) { return esc(t); }
  function fundorteGpx() {
    var list = ladeFundorte();
    return '<?xml version="1.0" encoding="UTF-8"?>\n<gpx version="1.1" creator="PilzKarte" xmlns="http://www.topografix.com/GPX/1/1">\n' +
      list.map(function (f) {
        return '  <wpt lat="' + f.lat + '" lon="' + f.lng + '">' + (f.zeit ? "<time>" + xmlEsc(f.zeit) + "</time>" : "") +
          "<name>" + xmlEsc(f.name) + "</name><desc>" + xmlEsc([f.art, f.datum, f.notiz].filter(Boolean).join(" | ")) + "</desc>" +
          (f.art ? "<type>" + xmlEsc(f.art) + "</type>" : "") + "</wpt>";
      }).join("\n") + "\n</gpx>\n";
  }
  function dateiSpeichern(name, mime, inhalt) {
    if (window.AndroidBridge && window.AndroidBridge.saveFile) { window.AndroidBridge.saveFile(name, mime, inhalt); return; }
    var a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([inhalt], { type: mime }));
    a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
  }
  $("btnExport").addEventListener("click", function () {
    if (!ladeFundorte().length) { toast("Noch keine Fundorte zum Exportieren."); return; }
    dateiSpeichern("pilzkarte-fundorte-" + new Date().toISOString().slice(0, 10) + ".gpx", "application/gpx+xml", fundorteGpx());
  });
  $("btnImport").addEventListener("click", function () { $("importFile").click(); });
  $("importFile").addEventListener("change", function (e) {
    var file = e.target.files && e.target.files[0];
    if (!file) return;
    var r = new FileReader();
    r.onload = function () {
      var neu = [];
      try {
        var doc = new DOMParser().parseFromString(String(r.result), "application/xml");
        Array.prototype.forEach.call(doc.getElementsByTagName("wpt"), function (w) {
          var get = function (tag) { var el = w.getElementsByTagName(tag)[0]; return el ? el.textContent : ""; };
          var lat = parseFloat(w.getAttribute("lat")), lng = parseFloat(w.getAttribute("lon"));
          if (!isFinite(lat) || !isFinite(lng)) return;
          var zeit = get("time");
          neu.push({ name: get("name") || "Fundort", art: get("type"), notiz: "", lat: lat, lng: lng, score: null, zeit: zeit || undefined,
            datum: zeit ? new Date(zeit).toLocaleDateString("de-DE") : "importiert" });
        });
      } catch (err) { neu = []; }
      if (!neu.length) { toast("Keine Wegpunkte in der Datei gefunden."); return; }
      var list = ladeFundorte();
      var key = function (f) { return f.lat.toFixed(5) + "," + f.lng.toFixed(5) + "," + f.name; };
      var vorhanden = {};
      list.forEach(function (f) { vorhanden[key(f)] = true; });
      var dazu = neu.filter(function (f) { return !vorhanden[key(f)]; });
      speichereFundorte(dazu.concat(list));
      toast(dazu.length + " Fundorte importiert.");
      e.target.value = "";
    };
    r.readAsText(file);
  });
  renderFundorte();

  // ------------------------------------------------------------------
  // Rückweg zum Auto / Startpunkt (GPS nur solange aktiv und App geöffnet)
  // ------------------------------------------------------------------
  var auto = store.get("pk_auto", null);
  var autoLayer = L.layerGroup().addTo(map), rueckWatch = null, rueckAktiv = false, rueckLinie = null, ichMarker = null;
  function zeichneAuto() {
    autoLayer.clearLayers();
    if (auto) {
      L.marker([auto.lat, auto.lng], { icon: L.divIcon({ className: "pilz-marker", html: "🚗", iconSize: [24, 24], iconAnchor: [12, 12] }) })
        .bindPopup("Startpunkt / Auto<br>" + esc(auto.datum)).addTo(autoLayer);
    }
    $("rueckInfo").textContent = auto ? "Gespeichert: " + auto.datum : "Noch kein Startpunkt gespeichert.";
    $("btnRueck").disabled = !auto;
  }
  function peilung(a, b) {
    var y = Math.sin((b.lng - a.lng) * Math.PI / 180) * Math.cos(b.lat * Math.PI / 180);
    var x = Math.cos(a.lat * Math.PI / 180) * Math.sin(b.lat * Math.PI / 180) -
      Math.sin(a.lat * Math.PI / 180) * Math.cos(b.lat * Math.PI / 180) * Math.cos((b.lng - a.lng) * Math.PI / 180);
    return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
  }
  function rueckUpdate(pos) {
    var ich = L.latLng(pos.coords.latitude, pos.coords.longitude), ziel = L.latLng(auto.lat, auto.lng);
    var dist = distM(ich, ziel), richt = peilung(ich, ziel);
    if (!ichMarker) ichMarker = L.marker(ich, { icon: L.divIcon({ className: "", html: '<div class="gps-dot"></div>', iconSize: [16, 16] }) }).addTo(autoLayer);
    else ichMarker.setLatLng(ich);
    if (!rueckLinie) rueckLinie = L.polyline([ich, ziel], { color: "#1e88e5", weight: 4, dashArray: "8 8" }).addTo(autoLayer);
    else rueckLinie.setLatLngs([ich, ziel]);
    $("rueckPill").innerHTML = '<span class="pfeil" style="transform:rotate(' + Math.round(richt) + 'deg)">⬆</span> 🚗 ' +
      (dist >= 1000 ? num(dist / 1000, 1) + " km" : num(dist) + " m") + " · Richtung " + himmelsrichtung(richt) + " (" + Math.round(richt) + "°)" +
      ' <button id="rueckStop" class="btn small">Beenden</button>';
    if (dist < 25) toast("Du bist am Startpunkt angekommen 🚗", 4000);
  }
  function rueckStartWatch() {
    if (!navigator.geolocation || rueckWatch !== null) return;
    rueckWatch = navigator.geolocation.watchPosition(rueckUpdate, function (err) {
      toast("Standort nicht ermittelbar: " + (err.code === 1 ? "Berechtigung fehlt" : err.message), 4000);
    }, { enableHighAccuracy: true, maximumAge: 5000, timeout: 30000 });
  }
  function rueckStopWatch() {
    if (rueckWatch !== null && navigator.geolocation) navigator.geolocation.clearWatch(rueckWatch);
    rueckWatch = null;
  }
  function rueckwegStarten() {
    if (!auto) return;
    rueckAktiv = true;
    $("rueckPill").classList.remove("hidden");
    $("rueckPill").innerHTML = "Suche Standort … <button id=\"rueckStop\" class=\"btn small\">Beenden</button>";
    closeSheets();
    rueckStartWatch();
  }
  function rueckwegBeenden() {
    rueckAktiv = false;
    rueckStopWatch();
    $("rueckPill").classList.add("hidden");
    if (rueckLinie) { autoLayer.removeLayer(rueckLinie); rueckLinie = null; }
    if (ichMarker) { autoLayer.removeLayer(ichMarker); ichMarker = null; }
  }
  $("rueckPill").addEventListener("click", function (e) {
    if (e.target.id === "rueckStop") rueckwegBeenden();
    else if (auto) map.setView([auto.lat, auto.lng], Math.max(map.getZoom(), 15));
  });
  $("btnAutoMerken").addEventListener("click", function () {
    locate(function (ll) {
      auto = { lat: +ll.lat.toFixed(6), lng: +ll.lng.toFixed(6), datum: new Date().toLocaleString("de-DE") };
      store.set("pk_auto", auto);
      zeichneAuto();
      toast("Startpunkt gespeichert 🚗 (nur auf diesem Handy)");
    });
  });
  $("btnRueck").addEventListener("click", rueckwegStarten);
  $("btnAutoLoeschen").addEventListener("click", function () {
    rueckwegBeenden();
    auto = null;
    store.set("pk_auto", null);
    zeichneAuto();
  });
  zeichneAuto();

  // ------------------------------------------------------------------
  // GPS & Suche
  // ------------------------------------------------------------------
  var gpsMarker = null, gpsCircle = null;
  function locate(cb) {
    if (!navigator.geolocation) { toast("Standort nicht verfügbar."); return; }
    toast("Suche Standort …", 8000);
    navigator.geolocation.getCurrentPosition(function (pos) {
      var ll = L.latLng(pos.coords.latitude, pos.coords.longitude);
      if (gpsMarker) { map.removeLayer(gpsMarker); map.removeLayer(gpsCircle); }
      gpsCircle = L.circle(ll, { radius: pos.coords.accuracy, weight: 1, color: "#1e88e5", fillOpacity: 0.1 }).addTo(map);
      gpsMarker = L.marker(ll, { icon: L.divIcon({ className: "", html: '<div class="gps-dot"></div>', iconSize: [16, 16] }) }).addTo(map);
      map.setView(ll, Math.max(map.getZoom(), 14));
      $("toast").classList.add("hidden");
      if (cb) cb(ll);
    }, function (err) {
      toast("Standort nicht ermittelbar: " + (err.code === 1 ? "Berechtigung fehlt" : err.message), 4000);
    }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 60000 });
  }
  $("btnLocate").addEventListener("click", function () { locate(); });

  $("searchForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var q = $("searchInput").value.trim();
    if (!q) return;
    $("searchInput").blur();
    var url = "https://nominatim.openstreetmap.org/search?format=json&limit=6&countrycodes=de&accept-language=de&q=" + encodeURIComponent(q);
    getJson(url).then(function (list) {
      var box = $("searchResults");
      if (!list.length) { toast("Nichts gefunden."); box.classList.add("hidden"); return; }
      box.innerHTML = list.map(function (r, i) {
        return '<button data-i="' + i + '">' + esc(r.display_name) + "</button>";
      }).join("");
      box.classList.remove("hidden");
      box.onclick = function (ev) {
        var i = ev.target.getAttribute("data-i");
        if (i == null) return;
        var r = list[+i];
        box.classList.add("hidden");
        closeSheets();
        if (r.boundingbox) {
          map.fitBounds([[+r.boundingbox[0], +r.boundingbox[2]], [+r.boundingbox[1], +r.boundingbox[3]]], { maxZoom: 14 });
        } else map.setView([+r.lat, +r.lon], 13);
      };
    }).catch(function (err) { toast("Suche fehlgeschlagen: " + err.message); });
  });

  // ------------------------------------------------------------------
  // Datenschutz-Einstellungen
  // ------------------------------------------------------------------
  $("optPrivat").checked = privat;
  $("optPrivat").addEventListener("change", function (e) {
    privat = e.target.checked;
    store.set("pk_privat", privat);
    toast(privat ? "Datensparmodus an: Koordinaten werden auf ca. 100 m gerundet." : "Datensparmodus aus: genaue Koordinaten.");
  });
  $("btnAllesLoeschen").addEventListener("click", function () {
    if (!confirm("Wirklich ALLE App-Daten löschen? (Fundorte, Startpunkt, Einstellungen)\nTipp: vorher Fundorte exportieren.")) return;
    rueckwegBeenden();
    store.clearAll();
    location.reload();
  });

  // App im Hintergrund: GPS aus, nichts abrufen (Android hält zusätzlich alle Anfragen an)
  window.onAppPause = function () { rueckStopWatch(); };
  window.onAppResume = function () { if (rueckAktiv) rueckStartWatch(); };
  document.addEventListener("visibilitychange", function () {
    if (document.hidden) window.onAppPause(); else window.onAppResume();
  });

  // ------------------------------------------------------------------
  // Menü / Sheets
  // ------------------------------------------------------------------
  var openName = "";
  function openSheet(name) {
    document.querySelectorAll(".sheet").forEach(function (s) { s.classList.toggle("open", s.id === "sheet-" + name); });
    document.querySelectorAll("#bottomnav button").forEach(function (b) {
      b.classList.toggle("active", b.getAttribute("data-sheet") === (name === "detail" ? "" : name));
    });
    openName = name;
    $("searchResults").classList.add("hidden");
    if (name === "ebenen") renderLayerMenu();
    if (name === "chancen" && !$("weatherBox").innerHTML) {
      fetchWetter(map.getCenter()).then(function (w) { renderWetterBox(w, "in Kartenmitte"); }).catch(function () {});
    }
  }
  function closeSheets() { openSheet(""); }
  document.querySelectorAll("#bottomnav button").forEach(function (b) {
    b.addEventListener("click", function () {
      var n = b.getAttribute("data-sheet");
      openSheet(openName === n ? "" : n);
    });
  });
  // Wischen nach unten auf dem Griff schließt
  document.querySelectorAll(".sheet-handle").forEach(function (h) { h.addEventListener("click", closeSheets); });

  // Zurück-Taste von Android
  window.handleBack = function () {
    if (!$("dlg").classList.contains("hidden")) { $("dlg").classList.add("hidden"); return true; }
    if (!$("searchResults").classList.contains("hidden")) { $("searchResults").classList.add("hidden"); return true; }
    if (openName) { closeSheets(); return true; }
    return false;
  };

  // Start
  setBase(state.base);
  Object.keys(state.ov || {}).forEach(function (id) {
    var def = OVERLAYS.filter(function (o) { return o.id === id; })[0];
    if (def) overlayLayers[id] = makeOverlay(def).addTo(map);
  });
  renderLegends();
  if (!store.get("pk_seen", false)) {
    store.set("pk_seen", true);
    setTimeout(function () { toast("Tipp: Auf die Karte tippen = Standort-Analyse. Lange drücken = Fundort merken. Wissen → Notfall: Giftnotruf.", 7000); }, 800);
  }

  // für Tests
  window.PK = { bewerte: bewerte, map: map, analysiere: analysiere, setOverlay: setOverlay, openSheet: openSheet };
})();
