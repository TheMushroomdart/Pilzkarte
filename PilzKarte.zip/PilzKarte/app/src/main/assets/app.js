/* PilzKarte – Kartenlogik, Datenabfragen und Pilz-Chancen-Bewertung
 *
 * Aufbau (Details zur Pflege in CLAUDE.md):
 *   1 Dienste & Tabellen   2 Hilfsfunktionen   3 HTTP          4 Karte & Ebenen
 *   5 Legenden & Menü      6 Datenabfragen     7 Wetter        8 Bewertung
 *   9 Analyse & Detail    10 Scan             11 Wissen       12 Externe Seiten
 *  13 Fundorte            14 Rückweg          15 GPS & Suche  16 Offline-Karten
 *  17 Updates             18 Datenschutz      19 Menü & Start
 *
 * Datenschutz-Grundsätze: Abfragen nur auf Nutzeraktion bzw. bei geöffneter App,
 * Koordinaten im Datensparmodus gerundet, gespeicherte Daten nur auf dem Gerät.
 */
(function () {
  "use strict";

  // =====================================================================
  // 1 DIENSTE & TABELLEN
  // =====================================================================
  var THUENEN = "https://atlas.thuenen.de/geoserver/wms";
  var BGR_GEO_WMS = "https://services.bgr.de/wms/geologie/guek250/";
  var BGR_NFK_WMS = "https://services.bgr.de/wms/boden/nfkwe1000/";
  var BGR_REST = "https://services.bgr.de/arcgis/rest/services";
  var DWD = "https://maps.dwd.de/geoserver/dwd/wms";
  var DLR = "https://geoservice.dlr.de/eoc/land/wms";
  var BFN = "https://geodienste.bfn.de/ogc/wms/schutzgebiet";
  var OPEN_METEO = "https://api.open-meteo.com/v1";
  var GBIF = "https://api.gbif.org/v1";
  var TOPPLUS_URL = "https://sgx.geodatenzentrum.de/wmts_topplus_open/tile/1.0.0/web/default/WEBMERCATOR/{z}/{y}/{x}.png";
  var STANDARD_REPO = "TheMushroomdart/Pilzkarte";

  // Nur von diesen Servern holt die App Daten (die Android-App prüft das zusätzlich)
  var ERLAUBTE_HOSTS = ["atlas.thuenen.de", "services.bgr.de", "maps.dwd.de", "geoservice.dlr.de", "geodienste.bfn.de",
    "api.open-meteo.com", "api.gbif.org", "nominatim.openstreetmap.org", "api.github.com"];

  // Waldverlust-Karte des DLR: Wert 1 = 09/2017 … Wert 98 = 10/2025 (letzter Monat, siehe WISSEN.md)
  var FCCL_LETZTER_MONAT = 98;

  function dwdLegend(layer) {
    return DWD + "?service=WMS&version=1.1.0&request=GetLegendGraphic&format=image/png&layer=" + encodeURIComponent(layer);
  }
  function dlrLegend(layer) {
    return DLR + "?service=WMS&version=1.1.0&request=GetLegendGraphic&format=image/png&layer=" + encodeURIComponent(layer);
  }

  // Farben der Thünen-Originaldarstellung (aus GetLegendGraphic)
  var PH_ORIGINAL = [
    ["≤4,5", "#7D0F32"], ["4,5–5", "#AF0825"], ["5–5,5", "#EC596A"], ["5,5–6", "#F9CCD1"],
    ["6–6,5", "#CCECF9"], ["6,5–7", "#59C1EC"], ["7–7,5", "#0078AD"], [">7,5", "#005078"]
  ];
  // Eigene Indikator-Skala (wie pH-Teststreifen)
  var PH_INDIKATOR = [
    [3.0, "#b2182b"], [4.0, "#e65100"], [4.5, "#f9a825"], [5.0, "#fdd835"], [5.5, "#c0ca33"],
    [6.0, "#7cb342"], [6.5, "#2e7d32"], [7.0, "#00897b"], [7.5, "#1e88e5"], [8.0, "#3949ab"], [8.5, "#5e35b1"]
  ];

  // Baumarten 2022 (DLR, Sentinel-1/2, 10 m) – Pixelwerte laut README des DLR
  var BAUM_DLR = {
    0: { name: "Kiefer", farbe: "#DE1317", myk: true },
    1: { name: "Fichte", farbe: "#CD8673", myk: true },
    2: { name: "Douglasie", farbe: "#E7EC47", myk: true },
    3: { name: "Lärche", farbe: "#DF3FEA", myk: true },
    4: { name: "Tanne", farbe: "#FFD54D", myk: true },
    5: { name: "Buche", farbe: "#49CA45", myk: true },
    6: { name: "Eiche", farbe: "#1A761C", myk: true },
    7: { name: "Birke", farbe: "#D1EFE2", myk: true },
    8: { name: "Erle", farbe: "#67844D", myk: false, punkte: 16 },
    9: { name: "Sonstige Baumarten", farbe: "#25A0ED", myk: false, punkte: 15 }
  };
  var DLR_VERLUST_WERT = 666, VERLUST_FARBE = "#3a3a3a";

  // Ältere Baumartenkarte 2017/18 (Thünen) – Werte aus der Original-Legende; dient als Rückfall
  var BAUM_THUENEN = {
    2: { name: "Birke", farbe: "#D1EFE2", myk: true },
    3: { name: "Buche", farbe: "#49CA45", myk: true },
    4: { name: "Douglasie", farbe: "#E7EC47", myk: true },
    5: { name: "Eiche", farbe: "#1A761C", myk: true },
    6: { name: "Erle", farbe: "#67844D", myk: false, punkte: 16 },
    8: { name: "Fichte", farbe: "#CD8673", myk: true },
    9: { name: "Kiefer", farbe: "#DE1317", myk: true },
    10: { name: "Lärche", farbe: "#DF3FEA", myk: true },
    14: { name: "Tanne", farbe: "#FFD54D", myk: true },
    16: { name: "Sonstige Baumarten", farbe: "#25A0ED", myk: false, punkte: 15 },
    17: { name: "Sonstige Baumarten", farbe: "#8EBCD9", myk: false, punkte: 15 }
  };

  // Waldverlust nach Jahr: [letzter Monatswert des Jahres, Farbe, Jahr]
  var VERLUST_JAHRE = [
    [4, "#fff7bc", "2017"], [16, "#fee391", "2018"], [28, "#fec44f", "2019"], [40, "#fe9929", "2020"],
    [52, "#ec7014", "2021"], [64, "#cc4c02", "2022"], [76, "#993404", "2023"], [88, "#7a0177", "2024"],
    [100, "#49006a", "2025"], [112, "#2d004b", "2026"]
  ];

  var BAUM_PILZE = {
    "Birke": "Birkenpilz, Birken-Rotkappe, Fliegenpilz (giftig)",
    "Buche": "Steinpilz, Pfifferling, Herbsttrompete, Semmel-Stoppelpilz, Frauentäubling",
    "Douglasie": "Maronen-Röhrling, Krause Glucke (selten)",
    "Eiche": "Sommer-Steinpilz, Pfifferling, Frauentäubling, Schwefelporling (am Stamm)",
    "Erle": "Erlen-Grübling, Erlenkremplinge (giftig)",
    "Fichte": "Fichten-Steinpilz, Maronen-Röhrling, Pfifferling, Flockenstieliger Hexen-Röhrling",
    "Kiefer": "Kiefern-Steinpilz, Krause Glucke, Butterpilz, Sandröhrling, Edelreizker",
    "Lärche": "Goldröhrling (Lärchen-Röhrling)",
    "Tanne": "Pfifferling, Steinpilz, Semmel-Stoppelpilz"
  };

  // ---- Farbskalen als SLD (GeoServer); scheitert das, zeigt die App die Original-Darstellung ----
  function sld(layerName, colorMap) {
    return '<?xml version="1.0" encoding="UTF-8"?><StyledLayerDescriptor version="1.0.0" ' +
      'xmlns="http://www.opengis.net/sld" xmlns:ogc="http://www.opengis.net/ogc">' +
      "<NamedLayer><Name>" + layerName + "</Name><UserStyle><FeatureTypeStyle><Rule><RasterSymbolizer>" +
      colorMap + "</RasterSymbolizer></Rule></FeatureTypeStyle></UserStyle></NamedLayer></StyledLayerDescriptor>";
  }
  function phSld(layerName) {
    var e = '<ColorMapEntry color="#000000" quantity="2.9" opacity="0"/>';
    PH_INDIKATOR.forEach(function (p) { e += '<ColorMapEntry color="' + p[1] + '" quantity="' + p[0] + '"/>'; });
    e += '<ColorMapEntry color="#5e35b1" quantity="8.6" opacity="0"/>';
    return sld(layerName, '<ColorMap type="ramp">' + e + "</ColorMap>");
  }
  function baum22Sld(layerName) {
    var e = Object.keys(BAUM_DLR).map(function (k) {
      return '<ColorMapEntry color="' + BAUM_DLR[k].farbe + '" quantity="' + k + '"/>';
    }).join("") + '<ColorMapEntry color="' + VERLUST_FARBE + '" quantity="' + DLR_VERLUST_WERT + '"/>';
    return sld(layerName, '<ColorMap type="values">' + e + "</ColorMap>");
  }
  function verlustSld(layerName) {
    var e = '<ColorMapEntry color="#000000" quantity="0.5" opacity="0"/>' + VERLUST_JAHRE.map(function (j) {
      return '<ColorMapEntry color="' + j[1] + '" quantity="' + j[0] + '"/>';
    }).join("");
    return sld(layerName, '<ColorMap type="intervals">' + e + "</ColorMap>");
  }

  // ---- Amtliche Luftbilder (DOP) der Bundesländer, frei unter dl-de/by-2-0 ----
  var DOP_LAENDER = [
    { land: "Baden-Württemberg", url: "https://owsproxy.lgl-bw.de/owsproxy/ows/WMS_INSP_BW_Orthofoto_DOP20", layers: "OI.OrthoimageCoverage", b: [[47.5, 7.5], [49.8, 10.5]] },
    { land: "Bayern", url: "https://geoservices.bayern.de/od/wms/dop/v1/dop20", layers: "by_dop20c", b: [[47.27, 8.97], [50.57, 13.84]] },
    { land: "Berlin", url: "https://gdi.berlin.de/services/wms/truedop_2024", layers: "truedop_2024", b: [[52.33, 13.08], [52.68, 13.77]] },
    { land: "Brandenburg", url: "https://isk.geobasis-bb.de/mapproxy/dop20c/service/wms", layers: "bebb_dop20c", b: [[51.36, 11.26], [53.56, 14.77]] },
    { land: "Bremen", url: "https://geodienste.bremen.de/wms_dop10_2023", layers: "DOP10_2023_HB", b: [[53.01, 8.48], [53.23, 8.99]] },
    { land: "Bremerhaven", url: "https://geodienste.bremen.de/wms_dop10_2023", layers: "DOP10_2023_BHV", b: [[53.46, 8.48], [53.61, 8.65]] },
    { land: "Hamburg", url: "https://geodienste.hamburg.de/wms_dop_zeitreihe_unbelaubt", layers: "wms_dop_zeitreihe_unbelaubt", b: [[53.39, 9.73], [53.75, 10.33]] },
    { land: "Hessen", url: "https://www.gds-srv.hessen.de/cgi-bin/lika-services/ogc-free-images.ows", layers: "he_dop_rgb", b: [[49.39, 7.77], [51.66, 10.24]] },
    { land: "Mecklenburg-Vorpommern", url: "https://www.geodaten-mv.de/dienste/adv_dop", layers: "mv_dop", b: [[53.11, 10.59], [54.69, 14.41]] },
    { land: "Niedersachsen", url: "https://opendata.lgln.niedersachsen.de/doorman/noauth/dop_wms", layers: "ni_dop20", b: [[51.29, 6.65], [53.89, 11.6]] },
    { land: "Nordrhein-Westfalen", url: "https://www.wms.nrw.de/geobasis/wms_nw_dop", layers: "nw_dop_rgb", b: [[50.32, 5.86], [52.53, 9.46]] },
    { land: "Rheinland-Pfalz", url: "https://www.geoportal.rlp.de/mapbender/php/wms.php?inspire=1&layer_id=61676&withChilds=1", layers: "rp_dop20", b: [[48.97, 6.11], [50.94, 8.51]] },
    { land: "Saarland", url: "https://geoportal.saarland.de/mapbender/php/wms.php?inspire=1&layer_id=46747&withChilds=1", layers: "sl_dop20_rgb", b: [[49.11, 6.36], [49.64, 7.4]] },
    { land: "Sachsen", url: "https://geodienste.sachsen.de/wms_geosn_dop-rgb/guest", layers: "sn_dop_020", b: [[50.17, 11.87], [51.69, 15.04]] },
    { land: "Sachsen-Anhalt", url: "https://www.geodatenportal.sachsen-anhalt.de/wss/service/ST_LVermGeo_DOP_WMS_OpenData/guest", layers: "lsa_lvermgeo_dop20_2", b: [[50.94, 10.56], [53.04, 13.19]] },
    { land: "Schleswig-Holstein", url: "https://dienste.gdi-sh.de/WMS_SH_DOP20col_OpenGBD", layers: "sh_dop20_rgb", b: [[53.36, 7.87], [55.06, 11.31]] },
    { land: "Thüringen", url: "https://www.geoproxy.geoportal-th.de/geoproxy/services/DOP20", layers: "th_dop", b: [[50.2, 9.88], [51.65, 12.65]] }
  ];

  var BASEMAPS = [
    { id: "topplus", name: "TopPlusOpen (amtliche Karte, BKG)", url: TOPPLUS_URL, stand: "laufend aktualisiert · offline speicherbar",
      opt: { maxZoom: 19, maxNativeZoom: 18, attribution: "Kartendarstellung: © BKG (" + new Date().getFullYear() + ") dl-de/by-2-0" } },
    { id: "topo", name: "Topografisch mit Höhenlinien (OpenTopoMap)", url: "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
      stand: "OpenStreetMap-Daten, laufend",
      opt: { maxZoom: 18, maxNativeZoom: 17, subdomains: "abc", attribution: "© OpenStreetMap, © OpenTopoMap (CC BY-SA)" } },
    { id: "osm", name: "OpenStreetMap", url: "https://tile.openstreetmap.org/{z}/{x}/{y}.png", stand: "laufend",
      opt: { maxZoom: 19, attribution: "© OpenStreetMap-Mitwirkende" } },
    { id: "dop", name: "Luftbild amtlich (Bundesländer, bis 10–20 cm)", type: "dop", stand: "je Land, meist 1–3 Jahre alt" },
    { id: "sat", name: "Satellit / Luftbild (Esri, USA)", url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
      stand: "unterschiedlich", opt: { maxZoom: 19, maxNativeZoom: 18, attribution: "© Esri, Maxar, Earthstar Geographics" } }
  ];

  var OVERLAYS = [
    { id: "ph0", name: "Boden-pH Oberboden (0–30 cm)", src: "Thünen-Institut", url: THUENEN, layers: "geonode:pH_map_0_30",
      opacity: 0.7, legend: "ph", ph: true, stand: "Karte 2021 · Messungen 2006–2018",
      sld: function (d) { return state.phstyle === "indikator" ? phSld(d.layers) : null; } },
    { id: "ph1", name: "Boden-pH Unterboden (30–100 cm)", src: "Thünen-Institut", url: THUENEN, layers: "geonode:pH_map_30_100",
      opacity: 0.7, legend: "ph", ph: true, stand: "Karte 2021 · Messungen 2006–2018",
      sld: function (d) { return state.phstyle === "indikator" ? phSld(d.layers) : null; } },
    { id: "geoph", name: "Gesteine nach Boden-pH eingefärbt", src: "BGR GÜK250, von der App nach typischem pH eingefärbt (ab Zoom 10)",
      type: "geoph", opacity: 0.55, legend: "geoph", stand: "GÜK250 (2019)" },
    { id: "geo", name: "Gesteine (Original-Karte GÜK250)", src: "BGR – Farben nach Gesteinsart", url: BGR_GEO_WMS,
      layers: "4", opacity: 0.6, legend: "geo", stand: "GÜK250 (2019)" },
    { id: "nfk", name: "Nutzbare Feldkapazität (Wasserspeicher)", src: "BGR", url: BGR_NFK_WMS, layers: "0", opacity: 0.6,
      legend: "img", stand: "BGR (2014)",
      legendUrl: BGR_NFK_WMS + "?service=WMS&request=GetLegendGraphic&version=1.3.0&format=image/png&layer=0" },
    { id: "baum22", name: "Baumarten 2022 (Satellit, 10 m)", src: "DLR", url: DLR, layers: "TREE_SPECIES_DE_2022",
      opacity: 0.75, legend: "baum22", stand: "Satellit 2022 (veröffentlicht 2025)",
      sld: function (d) { return baum22Sld(d.layers); }, legendFallback: dlrLegend("TREE_SPECIES_DE_2022") },
    { id: "verlust", name: "Waldverlust seit 2017 (Kahlflächen, Schäden)", src: "DLR", url: DLR, layers: "FCCL_DE_P1M",
      opacity: 0.8, legend: "verlust", stand: "09/2017 – 10/2025 (letzte 2–3 Monate vorläufig)",
      sld: function (d) { return verlustSld(d.layers); }, legendFallback: dlrLegend("FCCL_DE_P1M") },
    { id: "baum", name: "Baumarten 2017/18 (ältere Karte)", src: "Thünen-Institut", url: THUENEN,
      layers: "geonode:Dominant_Species_Class", opacity: 0.75, legend: "baum", stand: "Satellit 2017/18" },
    { id: "rain24", name: "Niederschlag letzte 24 h", src: "DWD RADOLAN", url: DWD, layers: "dwd:SF-Produkt",
      opacity: 0.7, legend: "img", legendUrl: dwdLegend("dwd:SF-Produkt"), stand: "aktuell", live: true },
    { id: "rain30", name: "Niederschlag letzte 30 Tage", src: "DWD RADOLAN", url: DWD, layers: "dwd:RADOLAN-W4",
      opacity: 0.7, legend: "img", legendUrl: dwdLegend("dwd:RADOLAN-W4"), stand: "aktuell", live: true },
    { id: "radar", name: "Regenradar aktuell", src: "DWD", url: DWD, layers: "dwd:Niederschlagsradar",
      opacity: 0.7, legend: "img", legendUrl: dwdLegend("dwd:Niederschlagsradar"), stand: "aktuell", live: true },
    { id: "funde", name: "Gemeldete Pilzfunde (Speisepilze)", src: "GBIF – u. a. iNaturalist, observation.org",
      type: "gbif", legend: "gbif", stand: "Meldungen der letzten 20 Jahre, Ortsangabe ≤ 1 km genau" },
    { id: "schutz", name: "Naturschutzgebiete & Nationalparke", src: "Bundesamt für Naturschutz – dort Sammelverbot!",
      url: BFN, layers: "Naturschutzgebiete,Nationalparke", opacity: 0.45, legend: "schutz", stand: "laufend aktualisiert" }
  ];

  // =====================================================================
  // 2 HILFSFUNKTIONEN
  // =====================================================================
  function $(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function num(v, d) {
    if (v == null || !isFinite(v)) return "–";
    return Number(v).toLocaleString("de-DE", { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 });
  }
  var toastTimer;
  function toast(msg, ms) {
    var t = $("toast");
    t.textContent = msg;
    t.classList.remove("hidden");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.add("hidden"); }, ms || 3000);
  }
  function scoreColor(s) {
    var h = Math.max(0, Math.min(120, s * 1.2));
    return "hsl(" + h + ",70%,38%)";
  }
  function scoreLabel(s) {
    if (s >= 70) return "Sehr gute Chancen";
    if (s >= 50) return "Gute Chancen";
    if (s >= 30) return "Mäßige Chancen";
    return "Geringe Chancen";
  }
  function distM(a, b) {
    var dy = (a.lat - b.lat) * 111320, dx = (a.lng - b.lng) * 111320 * Math.cos(a.lat * Math.PI / 180);
    return Math.sqrt(dx * dx + dy * dy);
  }
  function heute() { return new Date(); }

  // ---- native Brücke (in der Android-App vorhanden, im Browser nicht) ----
  var NB = window.AndroidBridge || null;
  function nativ(fn) { return !!(NB && typeof NB[fn] === "function"); }
  function appInfo() {
    try { if (nativ("appInfo")) return JSON.parse(NB.appInfo()); } catch (e) { /* egal */ }
    return { versionCode: 0, versionName: "Browser-Test" };
  }

  // ---- Ablage nur auf diesem Gerät: in der App nativ (kein Cloud-Backup), im Browser localStorage ----
  var NATIV_STORE = nativ("storeGet");
  var STORE_KEYS = ["pk_state", "pk_fundorte", "pk_seen", "pk_gbif_keys", "pk_auto", "pk_privat", "pk_repo", "pk_routine_url", "pk_wach"];
  var store = {
    get: function (k, def) {
      try {
        var v = NATIV_STORE ? NB.storeGet(k) : localStorage.getItem(k);
        return v ? JSON.parse(v) : def;
      } catch (e) { return def; }
    },
    set: function (k, v) {
      try {
        var t = v === undefined || v === null ? null : JSON.stringify(v);
        if (NATIV_STORE) NB.storeSet(k, t);
        else if (t === null) localStorage.removeItem(k);
        else localStorage.setItem(k, t);
      } catch (e) { /* egal */ }
    },
    clearAll: function () {
      try { if (NATIV_STORE) NB.storeClear(); } catch (e) { /* egal */ }
      try { localStorage.clear(); } catch (e) { /* egal */ }
    }
  };
  // Einmalige Übernahme alter Daten (Version 1/2 speicherte im WebView-Speicher)
  if (NATIV_STORE) {
    try {
      if (!NB.storeGet("pk_migriert")) {
        STORE_KEYS.forEach(function (k) {
          var alt = localStorage.getItem(k);
          if (alt && !NB.storeGet(k)) NB.storeSet(k, alt);
        });
        NB.storeSet("pk_migriert", "1");
        localStorage.clear();
      }
    } catch (e) { /* egal */ }
  }
  // Datensparmodus: Koordinaten für Datenabfragen auf ca. 100 m runden (Standard: an)
  var privat = store.get("pk_privat", true);
  function abfragePunkt(ll) {
    if (!privat) return ll;
    return L.latLng(Math.round(ll.lat * 1000) / 1000, Math.round(ll.lng * 1000) / 1000);
  }

  // =====================================================================
  // 3 HTTP – in der App über die native Brücke (kein CORS), im Browser fetch()
  // =====================================================================
  function hostErlaubt(url) {
    var m = /^https:\/\/([^\/?#:]+)/i.exec(url || "");
    return !!m && ERLAUBTE_HOSTS.indexOf(m[1].toLowerCase()) >= 0;
  }
  var pending = {}, reqSeq = 0;
  window.__httpDone = function (id, status, body) {
    var p = pending[id];
    if (!p) return;
    delete pending[id];
    if (status >= 200 && status < 300) p.res(body); else p.rej(new Error(status ? "HTTP " + status : (body || "Netzwerkfehler")));
  };
  /** Ruft eine native Methode mit Rückmeldung über __httpDone auf. */
  function nativeAufruf(fn, args, timeoutMs) {
    return new Promise(function (res, rej) {
      var id = ++reqSeq;
      pending[id] = { res: res, rej: rej };
      NB[fn].apply(NB, [id].concat(args));
      setTimeout(function () {
        if (!pending[id]) return;
        delete pending[id];
        // eine noch zurückgehaltene Anfrage (App war im Hintergrund) gar nicht mehr senden
        if (nativ("cancelRequest")) NB.cancelRequest(id);
        rej(new Error("Zeitüberschreitung"));
      }, timeoutMs || 30000);
    });
  }
  function rawGet(url) {
    if (!hostErlaubt(url)) return Promise.reject(new Error("Server nicht freigegeben"));
    if (nativ("httpGet")) return nativeAufruf("httpGet", [url], 30000);
    return fetch(url).then(function (r) {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.text();
    });
  }
  // gleichzeitige Anfragen begrenzen
  var aktiv = 0, warteschlange = [], MAX_PARALLEL = 6;
  function httpGet(url) {
    return new Promise(function (res, rej) {
      warteschlange.push({ url: url, res: res, rej: rej });
      pump();
    });
  }
  function pump() {
    while (aktiv < MAX_PARALLEL && warteschlange.length) {
      (function (job) {
        aktiv++;
        rawGet(job.url).then(job.res, job.rej).then(function () { aktiv--; pump(); });
      })(warteschlange.shift());
    }
  }
  function getJson(url) { return httpGet(url).then(function (t) { return JSON.parse(t); }); }
  /** Wie getJson, toleriert aber NaN-Werte, die manche Kartenserver ausgeben. */
  function getJsonLax(url) {
    return httpGet(url).then(function (t) { return JSON.parse(String(t).replace(/\b-?NaN\b/g, "null")); });
  }

  var cache = {};
  function cached(key, ttlMs, fn) {
    var c = cache[key];
    if (c && Date.now() - c.t < ttlMs) return c.p;
    var p = fn();
    cache[key] = { t: Date.now(), p: p };
    p.catch(function () { delete cache[key]; });
    return p;
  }
  function llKey(ll) { return ll.lat.toFixed(4) + "," + ll.lng.toFixed(4); }
  function safe(p) { return p.catch(function () { return "fehler"; }); }

  // =====================================================================
  // 4 KARTE & EBENEN
  // =====================================================================
  var state = store.get("pk_state", null) || {
    c: [51.1, 10.3], z: 6, base: "topplus", ov: {}, phstyle: "original"
  };
  if (!state.ov) state.ov = {};
  var map = L.map("map", { zoomControl: false, attributionControl: true })
    .setView(state.c, state.z);
  L.control.zoom({ position: "topright" }).addTo(map);
  L.control.scale({ imperial: false, position: "bottomright" }).addTo(map);

  function saveState() {
    var c = map.getCenter();
    state.c = [c.lat, c.lng];
    state.z = map.getZoom();
    store.set("pk_state", state);
  }
  map.on("moveend", saveState);

  // Kartenbilder, die wegen Hintergrund/Sperre nicht geladen wurden, nach der Rückkehr neu laden
  var appPausiert = false, rueckkehrZeit = 0, neuZeichnen = [];
  function planeNeuzeichnen(lyr) {
    if (lyr._pkTimer) return;
    lyr._pkTimer = setTimeout(function () {
      lyr._pkTimer = null;
      if (map.hasLayer(lyr) && navigator.onLine !== false) lyr.redraw();
    }, 800);
  }
  function kachelnUeberwachen(lyr) {
    if (!(lyr instanceof L.GridLayer)) { if (lyr.eachLayer) lyr.eachLayer(kachelnUeberwachen); return lyr; }
    lyr.on("tileerror", function () {
      if (appPausiert) { if (neuZeichnen.indexOf(lyr) < 0) neuZeichnen.push(lyr); }
      else if (Date.now() - rueckkehrZeit < 4000) planeNeuzeichnen(lyr);
    });
    return lyr;
  }

  var baseLayer = null;
  function makeBase(def) {
    if (def.type === "dop") {
      var g = L.layerGroup();
      DOP_LAENDER.forEach(function (d) {
        g.addLayer(L.tileLayer.wms(d.url, {
          layers: d.layers, format: "image/png", transparent: true, version: "1.1.1",
          bounds: L.latLngBounds(d.b), maxZoom: 19, zIndex: 1,
          attribution: "Luftbilder © GeoBasis-DE / Länder (dl-de/by-2-0)"
        }));
      });
      return g;
    }
    return L.tileLayer(def.url, L.extend({ zIndex: 1 }, def.opt));
  }
  function setBase(id) {
    var def = BASEMAPS.filter(function (b) { return b.id === id; })[0] || BASEMAPS[0];
    if (baseLayer) map.removeLayer(baseLayer);
    baseLayer = kachelnUeberwachen(makeBase(def)).addTo(map);
    state.base = def.id;
    saveState();
  }

  var overlayLayers = {};
  var sldGescheitert = {}; // Ebenen, deren Server die eigene Farbskala nicht annimmt

  function makeGbifLayer() {
    var g = L.layerGroup(), timer = null, hinweis = false;
    function laden() {
      if (!map.hasLayer(g)) return;
      if (map.getZoom() < 9) {
        g.clearLayers();
        if (!hinweis) { toast("Pilzfunde: bitte weiter hineinzoomen."); hinweis = true; }
        return;
      }
      var b = map.getBounds();
      fetchFunde(b.getSouth(), b.getWest(), b.getNorth(), b.getEast()).then(function (list) {
        g.clearLayers();
        list.forEach(function (f) {
          L.circleMarker([f.lat, f.lng], { radius: 6, color: "#fff", weight: 1.5, fillColor: "#ff6f00", fillOpacity: 0.9,
            bubblingMouseEvents: false })
            .bindPopup("<b>" + esc(f.art.de) + "</b><br><i>" + esc(f.art.sci) + "</i><br>" + esc(f.datum || "Datum unbekannt") +
              (f.unsicher ? "<br>Ortsgenauigkeit ± " + num(f.unsicher) + " m" : "") + "<br><small>" + esc(f.quelle) + "</small>")
            .addTo(g);
        });
        if (!list.length) toast("Keine gemeldeten Speisepilz-Funde in diesem Ausschnitt.");
        else if (list.length >= 300) toast("Sehr viele Funde – es werden 300 davon gezeigt.");
      }).catch(function () { toast("Funddaten (GBIF) gerade nicht erreichbar."); });
    }
    function spaeter() { clearTimeout(timer); timer = setTimeout(laden, 700); }
    g.on("add", function () { map.on("moveend", spaeter); laden(); });
    g.on("remove", function () { map.off("moveend", spaeter); });
    return g;
  }

  // Gesteinsflächen der BGR holen und nach typischem Boden-pH einfärben
  function makeGeoPhLayer(def) {
    var g = L.layerGroup(), timer = null, hinweis = false;
    var deck = state.ov[def.id] != null ? state.ov[def.id] : def.opacity;
    g.setOpacity = function (v) { deck = v; g.eachLayer(function (l) { l.setStyle({ fillOpacity: v }); }); };
    function laden() {
      if (!map.hasLayer(g)) return;
      if (map.getZoom() < 10) {
        g.clearLayers();
        if (!hinweis) { toast("Gesteins-pH-Karte: bitte bis Zoomstufe 10 hineinzoomen."); hinweis = true; }
        return;
      }
      var b = map.getBounds(), z = map.getZoom();
      var mProPixel = 156543.03 * Math.cos(b.getCenter().lat * Math.PI / 180) / Math.pow(2, z);
      var tol = (mProPixel / 111320).toFixed(6);
      var box = [b.getWest(), b.getSouth(), b.getEast(), b.getNorth()].map(function (x) { return x.toFixed(4); }).join(",");
      var url = BGR_REST + "/geologie/guek250/MapServer/8/query?geometry=" + box +
        "&geometryType=esriGeometryEnvelope&inSR=4326&outSR=4326&spatialRel=esriSpatialRelIntersects" +
        "&outFields=klartext_kurz,klartext,gkart_legtxt_stat&returnGeometry=true&maxAllowableOffset=" + tol +
        "&geometryPrecision=5&f=json";
      cached("geoph" + box + z, 36e5, function () { return getJson(url); }).then(function (j) {
        if (!map.hasLayer(g)) return;
        g.clearLayers();
        (j.features || []).forEach(function (f) {
          if (!f.geometry || !f.geometry.rings) return;
          var a = f.attributes || {};
          var arten = gesteineAusText([a.klartext_kurz, a.klartext, a.gkart_legtxt_stat].join(" "));
          var k = arten[0] ? arten[0].klasse : null;
          var rings = f.geometry.rings.map(function (r) { return r.map(function (p) { return [p[1], p[0]]; }); });
          L.polygon(rings, { stroke: true, weight: 0.6, color: "#444", opacity: 0.5,
            fillColor: k ? PH_KLASSEN[k].farbe : "#9e9e9e", fillOpacity: deck, fillRule: "evenodd" })
            .bindTooltip(esc(a.klartext_kurz || "Gestein") + (k ? " – " + esc(k) + " (pH " + esc(arten[0].ph) + ")" : " – pH unbekannt"), { sticky: true })
            .addTo(g);
        });
        if (j.exceededTransferLimit) toast("Sehr viele Gesteinsflächen – für die vollständige Karte weiter hineinzoomen.");
      }).catch(function () { toast("Gesteinsdaten (BGR) gerade nicht erreichbar."); });
    }
    function spaeter() { clearTimeout(timer); timer = setTimeout(laden, 700); }
    g.on("add", function () { map.on("moveend", spaeter); laden(); });
    g.on("remove", function () { map.off("moveend", spaeter); });
    return g;
  }

  function overlayDef(id) { return OVERLAYS.filter(function (o) { return o.id === id; })[0]; }

  function makeOverlay(def) {
    if (def.type === "gbif") return makeGbifLayer();
    if (def.type === "geoph") return makeGeoPhLayer(def);
    var opt = {
      layers: def.layers, format: "image/png", transparent: true, version: "1.3.0",
      opacity: state.ov[def.id] != null ? state.ov[def.id] : def.opacity,
      attribution: def.src, zIndex: 10 + OVERLAYS.indexOf(def)
    };
    var sldText = def.sld && !sldGescheitert[def.id] ? def.sld(def) : null;
    if (sldText) opt.SLD_BODY = sldText;
    var lyr = kachelnUeberwachen(L.tileLayer.wms(def.url, opt));
    // Rückfall, falls der Server die eigene Farbskala nicht annimmt – erst nach Gegenprobe,
    // damit Funklöcher oder die Pause im Hintergrund nicht fälschlich umschalten
    if (sldText) {
      var ok = 0, bad = 0, umgestellt = false, pruefe = false;
      lyr.on("tileload", function () { ok++; });
      lyr.on("tileerror", function (ev) {
        if (appPausiert || umgestellt || pruefe) return;
        bad++;
        if (bad < 4 || ok > 0 || navigator.onLine === false) return;
        pruefe = true;
        sldAbgelehnt(ev && ev.tile && ev.tile.src).then(function (abgelehnt) {
          pruefe = false;
          if (!abgelehnt) { bad = 0; return; }
          umgestellt = true;
          if (def.ph) {
            state.phstyle = "original";
            store.set("pk_state", state);
            var r = document.querySelector('input[name=phstyle][value=original]');
            if (r) r.checked = true;
            toast("Eigene pH-Farben nicht möglich – zeige Original-Farben.");
          } else {
            sldGescheitert[def.id] = true;
            toast(def.name + ": zeige die Original-Darstellung des Anbieters.");
          }
          neuLaden(def.id);
        });
      });
    }
    return lyr;
  }
  /** Gegenprobe: lehnt der Kartenserver die eigene Farbskala ab (Fehlermeldung statt Bild)? */
  function sldAbgelehnt(url) {
    if (!url || !hostErlaubt(url)) return Promise.resolve(false);
    return rawGet(url).then(function (t) {
      return /ServiceException|ExceptionReport|ows:Exception/i.test(String(t).slice(0, 3000));
    }, function (e) {
      return /HTTP 4\d\d/.test(e.message || ""); // 4xx = Anfrage abgelehnt; Netzfehler zählen nicht
    });
  }
  function neuLaden(id) {
    if (!overlayLayers[id]) return;
    map.removeLayer(overlayLayers[id]);
    overlayLayers[id] = makeOverlay(overlayDef(id)).addTo(map);
    renderLegends();
  }
  function setOverlay(id, on) {
    var def = overlayDef(id);
    if (!def) return;
    if (on && !overlayLayers[id]) {
      overlayLayers[id] = makeOverlay(def).addTo(map);
      if (state.ov[id] == null) state.ov[id] = def.opacity != null ? def.opacity : 1;
    } else if (!on && overlayLayers[id]) {
      map.removeLayer(overlayLayers[id]);
      delete overlayLayers[id];
      delete state.ov[id];
    }
    saveState();
    renderLegends();
  }

  // =====================================================================
  // 5 LEGENDEN & EBENEN-MENÜ
  // =====================================================================
  function legendHtml(def) {
    var h = '<div class="legend"><div class="t">' + esc(def.name) + "</div>";
    if (def.stand) h += '<div class="stand">Stand: ' + esc(def.stand) + "</div>";
    if (def.legendFallback && sldGescheitert[def.id]) {
      h += '<img src="' + esc(def.legendFallback) + '" alt="Legende" loading="lazy">';
    } else if (def.legend === "ph") {
      var arr = state.phstyle === "indikator" ? PH_INDIKATOR : PH_ORIGINAL;
      h += '<div class="ramp">' + arr.map(function (a) { return '<span style="background:' + a[1] + '"></span>'; }).join("") + "</div>";
      h += state.phstyle === "indikator"
        ? '<div class="ticks"><span>3</span><span>4,5</span><span>6</span><span>7</span><span>8,5</span></div>'
        : '<div class="ticks"><span>≤4,5</span><span>5,5</span><span>6,5</span><span>&gt;7,5</span></div>';
      h += '<div class="ticks"><span>sauer</span><span>neutral</span><span>basisch</span></div>';
    } else if (def.legend === "baum" || def.legend === "baum22") {
      var tab = def.legend === "baum22" ? BAUM_DLR : BAUM_THUENEN, gesehen = {};
      h += '<div class="items">' + Object.keys(tab).filter(function (k) {
        if (gesehen[tab[k].name]) return false;
        gesehen[tab[k].name] = true;
        return true;
      }).map(function (k) {
        var b = tab[k];
        return '<div class="li"><span class="sw" style="background:' + b.farbe + '"></span>' + esc(b.name.replace("Sonstige Baumarten", "Sonstige")) + "</div>";
      }).join("") + (def.legend === "baum22" ? '<div class="li"><span class="sw" style="background:' + VERLUST_FARBE + '"></span>Verlust</div>' : "") + "</div>";
    } else if (def.legend === "verlust") {
      h += '<div class="items">' + VERLUST_JAHRE.slice(0, 9).map(function (j) {
        return '<div class="li"><span class="sw" style="background:' + j[1] + '"></span>' + esc(j[2]) + "</div>";
      }).join("") + "</div><div>Jahr des Kronendachverlusts</div>";
    } else if (def.legend === "geo") {
      h += '<div>Farben = Gesteinsart (BGR-Originallegende).<br>Auf die Karte tippen → Gestein &amp; pH.<br>Nach pH eingefärbt: Ebene „Gesteine nach Boden-pH“.</div>';
    } else if (def.legend === "geoph") {
      h += '<div class="items">' + Object.keys(PH_KLASSEN).map(function (k) {
        return '<div class="li"><span class="sw" style="background:' + PH_KLASSEN[k].farbe + '"></span>' + esc(k) + "</div>";
      }).join("") + '<div class="li"><span class="sw" style="background:#9e9e9e"></span>unbekannt</div></div>' +
        "<div>typischer Boden-pH des Ausgangsgesteins</div>";
    } else if (def.legend === "gbif") {
      h += '<div class="li"><span class="sw" style="background:#ff6f00;border-radius:50%"></span>Fund einer Speisepilz-Art (antippen)</div>' +
        "<div>Quelle GBIF; ab Zoomstufe 9</div>";
    } else if (def.legend === "schutz") {
      h += "<div>Farbige Flächen: Naturschutzgebiet oder Nationalpark.<br><b>Sammeln in NSG grundsätzlich verboten.</b></div>";
    } else if (def.legend === "img") {
      h += '<img src="' + esc(def.legendUrl) + '" alt="Legende" loading="lazy">';
    }
    return h + "</div>";
  }
  function renderLegends() {
    var ids = Object.keys(overlayLayers);
    // höchstens die zwei zuletzt eingeschalteten Legenden zeigen
    var defs = OVERLAYS.filter(function (o) { return ids.indexOf(o.id) >= 0; }).slice(-2);
    $("legendDock").innerHTML = defs.map(legendHtml).join("");
    // Bilder, die nicht laden, ausblenden (ohne Inline-Skript wegen Sicherheitsrichtlinie)
    Array.prototype.forEach.call($("legendDock").querySelectorAll("img"), function (img) {
      img.addEventListener("error", function () { img.style.display = "none"; });
    });
  }
  // Legende antippen = ein-/ausklappen
  $("legendDock").addEventListener("click", function (e) {
    var l = e.target.closest(".legend");
    if (l) l.classList.toggle("collapsed");
  });

  function renderLayerMenu() {
    $("baseList").innerHTML = BASEMAPS.map(function (b) {
      return '<label class="opt"><input type="radio" name="base" value="' + b.id + '"' +
        (state.base === b.id ? " checked" : "") + "> <span>" + esc(b.name) + '<span class="sub">Stand: ' + esc(b.stand) + "</span></span></label>";
    }).join("");
    $("overlayList").innerHTML = OVERLAYS.map(function (o) {
      var on = !!overlayLayers[o.id];
      var op = Math.round((state.ov[o.id] != null ? state.ov[o.id] : (o.opacity || 1)) * 100);
      return '<label class="opt"><input type="checkbox" data-ov="' + o.id + '"' + (on ? " checked" : "") + ">" +
        "<span>" + esc(o.name) + '<span class="sub">' + esc(o.src) + (o.stand ? " · Stand: " + esc(o.stand) : "") + "</span></span></label>" +
        '<div class="opacity' + (on && o.type !== "gbif" ? "" : " hidden") + '" id="op-' + o.id + '">Deckkraft <input type="range" min="10" max="100" value="' +
        op + '" data-op="' + o.id + '"></div>';
    }).join("");
  }
  $("baseList").addEventListener("change", function (e) { if (e.target.name === "base") setBase(e.target.value); });
  $("overlayList").addEventListener("change", function (e) {
    var id = e.target.getAttribute("data-ov");
    if (id) {
      setOverlay(id, e.target.checked);
      $("op-" + id).classList.toggle("hidden", !e.target.checked || id === "funde");
    }
  });
  $("overlayList").addEventListener("input", function (e) {
    var id = e.target.getAttribute("data-op");
    if (id && overlayLayers[id] && overlayLayers[id].setOpacity) {
      var v = e.target.value / 100;
      overlayLayers[id].setOpacity(v);
      state.ov[id] = v;
      saveState();
    }
  });
  Array.prototype.forEach.call(document.querySelectorAll("input[name=phstyle]"), function (r) {
    r.checked = r.value === state.phstyle;
    r.addEventListener("change", function () {
      state.phstyle = r.value;
      saveState();
      ["ph0", "ph1"].forEach(neuLaden);
      renderLegends();
    });
  });

  // =====================================================================
  // 6 DATENABFRAGEN FÜR EINEN PUNKT
  // =====================================================================
  /** Wert eines Rasters an einem Punkt (WMS GetFeatureInfo, JSON). null = kein Wert. */
  function wmsWert(base, layer, ll) {
    var d = 0.0005;
    var url = base + "?service=WMS&version=1.1.1&request=GetFeatureInfo&layers=" + encodeURIComponent(layer) +
      "&query_layers=" + encodeURIComponent(layer) + "&styles=&srs=EPSG:4326&bbox=" +
      (ll.lng - d) + "," + (ll.lat - d) + "," + (ll.lng + d) + "," + (ll.lat + d) +
      "&width=11&height=11&x=5&y=5&info_format=application/json&feature_count=1";
    return cached(layer + llKey(ll), 36e5, function () {
      return getJsonLax(url).then(function (j) {
        var f = j && j.features && j.features[0];
        if (!f || !f.properties) return null;
        for (var k in f.properties) {
          var raw = f.properties[k];
          if (raw === null || raw === "" || typeof raw === "boolean") continue;
          var v = parseFloat(raw);
          if (isFinite(v)) return v;
        }
        return null;
      });
    });
  }
  function fetchPh(ll, depth) {
    return wmsWert(THUENEN, depth === 1 ? "geonode:pH_map_30_100" : "geonode:pH_map_0_30", ll).then(function (v) {
      return v != null && v > 2 && v < 11 ? v : null;
    });
  }
  /** Baumart: DLR-Karte 2022, bei Ausfall die ältere Thünen-Karte 2017/18 */
  function fetchBaum(ll) {
    return wmsWert(DLR, "TREE_SPECIES_DE_2022", ll).then(function (v) {
      if (v == null) return { wald: false, quelle: "DLR 2022" };
      v = Math.round(v);
      if (v === DLR_VERLUST_WERT) return { wald: false, verlust: true, quelle: "DLR 2022" };
      var b = BAUM_DLR[v];
      return b ? { wald: true, art: b.name, info: b, quelle: "DLR 2022" } : { wald: false, quelle: "DLR 2022" };
    }).catch(function () {
      return wmsWert(THUENEN, "geonode:Dominant_Species_Class", ll).then(function (v) {
        if (v == null) return { wald: false, quelle: "Thünen 2017/18" };
        var b = BAUM_THUENEN[Math.round(v)];
        return b ? { wald: true, art: b.name, info: b, quelle: "Thünen 2017/18" } : { wald: false, quelle: "Thünen 2017/18" };
      });
    });
  }
  function monatAusIndex(m) {
    var gesamt = 2017 * 12 + 8 + (m - 1); // Monat 1 = September 2017
    var jahr = Math.floor(gesamt / 12), monat = gesamt % 12 + 1;
    return (monat < 10 ? "0" : "") + monat + "/" + jahr;
  }
  /** Waldverlust (DLR): {status: "intakt"|"verlust"|"kein", datum, vorlaeufig} */
  function fetchVerlust(ll) {
    return wmsWert(DLR, "FCCL_DE_P1M", ll).then(function (v) {
      if (v == null) return { status: "kein" };
      v = Math.round(v);
      if (v === 0) return { status: "intakt" };
      if (v >= 1 && v <= 400) {
        return { status: "verlust", monat: v, datum: monatAusIndex(v), vorlaeufig: v > FCCL_LETZTER_MONAT - 3 };
      }
      return { status: "kein" };
    });
  }
  /** Art des Verlusts (DLR-Maske): 1 = dauerhaft, 2–4 = vorübergehende Störung */
  function fetchVerlustMaske(ll) {
    return wmsWert(DLR, "FCCL_DE_P1M_MASK", ll).then(function (v) { return v == null ? null : Math.round(v); });
  }
  function fetchGestein(ll) {
    function q(layerId) {
      var url = BGR_REST + "/geologie/guek250/MapServer/" + layerId + "/query?geometry=" + ll.lng + "," + ll.lat +
        "&geometryType=esriGeometryPoint&inSR=4326&spatialRel=esriSpatialRelIntersects" +
        "&outFields=klartext_kurz,klartext,gkart_legtxt_stat,p_zusatz&returnGeometry=false&f=json";
      return getJson(url).then(function (j) {
        var a = j && j.features && j.features[0] && j.features[0].attributes;
        if (!a) return null;
        var clean = function (s) { return s && String(s).trim() ? String(s).trim() : ""; };
        return {
          kurz: clean(a.klartext_kurz), text: clean(a.klartext),
          gruppe: clean(a.gkart_legtxt_stat), zusatz: clean(a.p_zusatz)
        };
      }).catch(function () { return null; });
    }
    return cached("geo" + llKey(ll), 36e5, function () {
      return Promise.all([q(8), q(7)]).then(function (r) {
        var basis = r[0], decke = r[1];
        if (!basis && !decke) return null;
        var basisG = basis ? gesteineAusText([basis.kurz, basis.text, basis.gruppe].join(" ")) : [];
        var deckeG = decke && decke.kurz ? gesteineAusText([decke.kurz, decke.text].join(" ")) : [];
        return { basis: basis, decke: decke && decke.kurz ? decke : null, basisG: basisG, deckeG: deckeG,
          // für die Bewertung zählt die oberste Schicht
          haupt: (deckeG[0] || basisG[0] || null) };
      });
    });
  }
  function fetchNfk(ll) {
    var d = 0.01;
    var url = BGR_REST + "/boden/nfkwe1000/MapServer/identify?geometry=" + ll.lng + "," + ll.lat +
      "&geometryType=esriGeometryPoint&sr=4326&layers=all&tolerance=1&mapExtent=" +
      (ll.lng - d) + "," + (ll.lat - d) + "," + (ll.lng + d) + "," + (ll.lat + d) +
      "&imageDisplay=400,400,96&returnGeometry=false&f=json";
    return cached("nfk" + llKey(ll), 36e5, function () {
      return getJson(url).then(function (j) {
        var a = j && j.results && j.results[0] && j.results[0].attributes;
        if (!a) return null;
        for (var k in a) {
          if (/pixel value/i.test(k)) {
            var s = String(a[k]);
            var v = s.indexOf(",") >= 0 ? parseFloat(s.replace(/\./g, "").replace(",", ".")) : parseFloat(s);
            return isFinite(v) && v >= 0 && v < 1000 ? v : null;
          }
        }
        return null;
      });
    });
  }
  function nfkKlasse(v) {
    if (v == null) return "";
    if (v < 50) return "sehr gering";
    if (v < 90) return "gering";
    if (v < 140) return "mittel";
    if (v < 200) return "hoch";
    if (v < 270) return "sehr hoch";
    return "äußerst hoch";
  }

  // ---- Gelände: Höhe, Hangneigung, Exposition (Open-Meteo Elevation, 90-m-DGM) ----
  function elevations(lls) {
    var chunks = [];
    for (var i = 0; i < lls.length; i += 100) chunks.push(lls.slice(i, i + 100));
    return Promise.all(chunks.map(function (c) {
      var url = OPEN_METEO + "/elevation?latitude=" +
        c.map(function (p) { return p.lat.toFixed(5); }).join(",") + "&longitude=" +
        c.map(function (p) { return p.lng.toFixed(5); }).join(",");
      return getJson(url).then(function (j) { return j.elevation; });
    })).then(function (parts) { return [].concat.apply([], parts); });
  }
  function nachbarn(ll) {
    var dLat = 100 / 111320, dLng = 100 / (111320 * Math.cos(ll.lat * Math.PI / 180));
    return [ll, L.latLng(ll.lat + dLat, ll.lng), L.latLng(ll.lat - dLat, ll.lng),
      L.latLng(ll.lat, ll.lng + dLng), L.latLng(ll.lat, ll.lng - dLng)];
  }
  function gelaendeAus(z) { // z = [Mitte, N, S, O, W]
    if (!z || z.length < 5 || z.some(function (v) { return v == null || !isFinite(v); })) return null;
    var dzdx = (z[3] - z[4]) / 200, dzdy = (z[1] - z[2]) / 200;
    var neigung = Math.atan(Math.sqrt(dzdx * dzdx + dzdy * dzdy)) * 180 / Math.PI;
    var expo = (Math.atan2(-dzdx, -dzdy) * 180 / Math.PI + 360) % 360; // Richtung, in die der Hang abfällt
    var mittel = (z[1] + z[2] + z[3] + z[4]) / 4;
    var form = z[0] < mittel - 2 ? "Senke/Tal" : z[0] > mittel + 2 ? "Kuppe/Rücken" : "";
    return { hoehe: z[0], neigung: neigung, expo: expo, form: form };
  }
  function fetchGelaende(ll) {
    return cached("gel" + llKey(ll), 864e5, function () {
      return elevations(nachbarn(ll)).then(gelaendeAus);
    });
  }
  function himmelsrichtung(deg) {
    return ["N", "NO", "O", "SO", "S", "SW", "W", "NW"][Math.round(deg / 45) % 8];
  }

  // ---- Gemeldete Pilzfunde (GBIF – u. a. iNaturalist, observation.org, Pilzkartierungen) ----
  function gbifFilter() {
    var j = heute().getFullYear();
    return "&hasCoordinate=true&hasGeospatialIssue=false&year=" + (j - 20) + "," + j + "&coordinateUncertaintyInMeters=0,1000";
  }
  function bboxParam(s, w, n, e) {
    return "&decimalLatitude=" + s.toFixed(4) + "," + n.toFixed(4) + "&decimalLongitude=" + w.toFixed(4) + "," + e.toFixed(4);
  }
  function artZuFund(r) {
    var sp = String(r.species || r.scientificName || "").toLowerCase();
    for (var i = 0; i < PILZARTEN.length; i++) {
      if (sp.indexOf(PILZARTEN[i].sci.toLowerCase()) === 0) return PILZARTEN[i];
    }
    return null;
  }
  /** Speisepilz-Meldungen im Rechteck [süd, west, nord, ost] (max. 300) */
  function fetchFunde(s, w, n, e) {
    var k = [s, w, n, e].map(function (x) { return x.toFixed(3); }).join(",");
    return cached("gbif" + k, 36e5, function () {
      var namen = PILZARTEN.map(function (a) { return "&scientificName=" + encodeURIComponent(a.sci); }).join("");
      var url = GBIF + "/occurrence/search?limit=300" + gbifFilter() + bboxParam(s, w, n, e) + namen;
      return getJson(url).then(function (j) {
        return (j.results || []).map(function (r) {
          return { lat: r.decimalLatitude, lng: r.decimalLongitude, art: artZuFund(r), datum: (r.eventDate || "").slice(0, 10),
            quelle: r.datasetName || "GBIF", unsicher: r.coordinateUncertaintyInMeters };
        }).filter(function (f) { return f.art && isFinite(f.lat) && isFinite(f.lng); });
      });
    });
  }
  /** Anzahl aller Pilzmeldungen im Rechteck – Maß dafür, wie gut eine Gegend beobachtet ist */
  function fetchPilzDichte(s, w, n, e) {
    var k = [s, w, n, e].map(function (x) { return x.toFixed(3); }).join(",");
    return cached("gbifn" + k, 36e5, function () {
      var url = GBIF + "/occurrence/search?limit=0&kingdomKey=5" + gbifFilter() + bboxParam(s, w, n, e);
      return getJson(url).then(function (j) { return typeof j.count === "number" ? j.count : null; });
    });
  }
  /** Funde im Umkreis von 1,5 km samt Beobachtungsdichte */
  function fundeUmkreis(q, ll) {
    var r = 1500, dLat = r / 111320, dLng = r / (111320 * Math.cos(q.lat * Math.PI / 180));
    var s = q.lat - dLat, n = q.lat + dLat, w = q.lng - dLng, e = q.lng + dLng;
    return Promise.all([fetchFunde(s, w, n, e), fetchPilzDichte(s, w, n, e).catch(function () { return null; })]).then(function (x) {
      return {
        liste: x[0].filter(function (f) { return distM(ll, f) <= r; }),
        // Rechteck → Kreis
        gesamt: x[1] != null ? Math.round(x[1] * Math.PI / 4) : null
      };
    });
  }

  // ---- Schutzgebiete (BfN) ----
  function fetchSchutz(ll) {
    function q(layer) {
      var d = 0.0005;
      var url = BFN + "?SERVICE=WMS&VERSION=1.1.1&REQUEST=GetFeatureInfo&LAYERS=" + layer + "&QUERY_LAYERS=" + layer +
        "&STYLES=&SRS=EPSG:4326&BBOX=" + (ll.lng - d) + "," + (ll.lat - d) + "," + (ll.lng + d) + "," + (ll.lat + d) +
        "&WIDTH=11&HEIGHT=11&X=5&Y=5&INFO_FORMAT=application/geo%2Bjson&FEATURE_COUNT=1";
      return getJson(url).then(function (j) {
        var f = j && j.features && j.features[0];
        if (!f) return null;
        var p = f.properties || {}, name = "";
        for (var k in p) { if (/name/i.test(k) && p[k] && String(p[k]).trim()) { name = String(p[k]).trim(); break; } }
        return name || "ohne Namen";
      });
    }
    return cached("nsg" + llKey(ll), 864e5, function () {
      return Promise.all([q("Naturschutzgebiete").catch(function () { return undefined; }),
        q("Nationalparke").catch(function () { return undefined; })]).then(function (r) {
        return { nsg: r[0], np: r[1], fehler: r[0] === undefined && r[1] === undefined };
      });
    });
  }

  // =====================================================================
  // 7 WETTER (Open-Meteo): Regen, Verdunstung, Bodenfeuchte, Luft, Vorhersage
  // =====================================================================
  var letztesWetter = null;
  function fetchWetter(ll) {
    var lat = Math.round(ll.lat * 10) / 10, lng = Math.round(ll.lng * 10) / 10; // immer ca. 10 km gerundet
    var url = OPEN_METEO + "/forecast?latitude=" + lat + "&longitude=" + lng +
      "&daily=precipitation_sum,temperature_2m_max,temperature_2m_min,et0_fao_evapotranspiration,wind_speed_10m_max" +
      "&hourly=soil_moisture_3_to_9cm,soil_moisture_9_to_27cm,relative_humidity_2m" +
      "&past_days=92&forecast_days=8&timezone=Europe%2FBerlin";
    return cached("wx" + lat + "," + lng, 18e5, function () {
      return getJson(url).then(function (j) {
        var w = wetterAuswerten(j);
        letztesWetter = w;
        return w;
      });
    });
  }
  function pad2(x) { return (x < 10 ? "0" : "") + x; }
  function wetterAuswerten(j) {
    var d = j.daily, n = d.time.length;
    var jetzt = heute();
    var heuteIso = jetzt.getFullYear() + "-" + pad2(jetzt.getMonth() + 1) + "-" + pad2(jetzt.getDate());
    var ti = d.time.indexOf(heuteIso);
    if (ti < 0) ti = Math.max(0, n - 8);
    var arr = function (a) { return (a || []).map(function (x) { return x == null ? null : x; }); };
    var rain = arr(d.precipitation_sum).map(function (x) { return x || 0; });
    var tmax = arr(d.temperature_2m_max), tmin = arr(d.temperature_2m_min);
    var et0 = arr(d.et0_fao_evapotranspiration).map(function (x) { return x || 0; });
    var wind = arr(d.wind_speed_10m_max);
    var tmean = tmax.map(function (mx, i) { return mx != null && tmin[i] != null ? (mx + tmin[i]) / 2 : null; });
    function sum(a, from, to) { var s = 0; for (var i = Math.max(0, from); i < Math.min(a.length, to); i++) s += a[i] || 0; return s; }
    function mittel(a, from, to) {
      var s = 0, c = 0;
      for (var i = Math.max(0, from); i < Math.min(a.length, to); i++) { if (a[i] != null) { s += a[i]; c++; } }
      return c ? s / c : null;
    }
    var r5 = sum(rain, ti - 5, ti), r7 = sum(rain, ti - 7, ti), r14 = sum(rain, ti - 14, ti), r30 = sum(rain, ti - 30, ti);
    var r90 = sum(rain, ti - 90, ti);
    var et14 = et0.length ? sum(et0, ti - 14, ti) : null, et90 = et0.length ? sum(et0, ti - 90, ti) : null;
    var t7 = mittel(tmean, ti - 7, ti);
    var amp = tmax.map(function (mx, i) { return mx != null && tmin[i] != null ? mx - tmin[i] : null; });
    var amp7 = mittel(amp, ti - 7, ti);
    var wind7 = mittel(wind, ti - 7, ti);
    var frost7 = 0;
    for (var fi = ti - 7; fi < ti; fi++) if (fi >= 0 && tmin[fi] != null && tmin[fi] < 0) frost7++;
    // ergiebiger Regen vor 4–21 Tagen?
    var guterRegen = null;
    for (var i = ti - 1; i >= 0; i--) {
      var alter = ti - i;
      if (alter >= 4 && alter <= 21 && rain[i] >= 10) { guterRegen = { alter: alter, mm: rain[i] }; break; }
    }
    // Auslöser: warme Phase (3 Tage ≥ 25 °C) vor 8–21 Tagen, danach Abkühlung um ≥ 4 K mit Regen
    var warm = null;
    for (var wi = ti - 21; wi <= ti - 10; wi++) {
      var m3 = mittel(tmax, wi, wi + 3);
      if (m3 != null && (warm == null || m3 > warm)) warm = m3;
    }
    var kuehl = mittel(tmax, ti - 7, ti);
    var ausloeser = warm != null && kuehl != null && warm >= 25 && warm - kuehl >= 4 && r7 >= 10;
    // Vorhersage
    var fcFrost = 0, fcRain = 0;
    for (var fj = ti + 1; fj < Math.min(n, ti + 8); fj++) {
      if (tmin[fj] != null && tmin[fj] < 0) fcFrost++;
      fcRain += rain[fj] || 0;
    }
    var fcT = mittel(tmean, ti + 1, ti + 8);
    var vorhersage3 = sum(rain, ti + 1, ti + 4);
    // stündliche Werte: Bodenfeuchte (Mittel 3–27 cm) und Luftfeuchte
    var feuchte = null, feuchteVor7 = null, luft7 = null;
    if (j.hourly && j.hourly.time) {
      var h = j.hourly;
      var key = heuteIso + "T" + pad2(jetzt.getHours()) + ":00";
      var idx = h.time.indexOf(key);
      if (idx < 0) idx = ti * 24 + jetzt.getHours();
      var fv = function (k) {
        var a = h.soil_moisture_3_to_9cm && h.soil_moisture_3_to_9cm[k], b = h.soil_moisture_9_to_27cm && h.soil_moisture_9_to_27cm[k];
        if (a == null && b == null) return null;
        if (a == null) return b;
        if (b == null) return a;
        return (a + b) / 2;
      };
      feuchte = fv(idx);
      feuchteVor7 = idx - 168 >= 0 ? fv(idx - 168) : null;
      if (h.relative_humidity_2m) luft7 = mittel(h.relative_humidity_2m, idx - 168, idx);
    }
    return {
      r5: r5, r7: r7, r14: r14, r30: r30, r90: r90, t7: t7, amp7: amp7, wind7: wind7, luft7: luft7,
      guterRegen: guterRegen, ausloeser: ausloeser, vorhersage3: vorhersage3,
      letzte: rain.slice(Math.max(0, ti - 14), ti), feuchte: feuchte, feuchteVor7: feuchteVor7,
      et14: et14, bilanz14: et14 != null ? r14 - et14 : null, bilanz90: et90 != null ? r90 - et90 : null,
      frost7: frost7, fcFrost: fcFrost, fcT: fcT, fcRain: fcRain
    };
  }

  /** Pilzwetter-Aussicht für die nächsten 1–2 Wochen */
  function aussicht(w) {
    if (!w || w.fcT == null) return null;
    var mild = w.fcT >= 8 && w.fcT <= 22;
    var nass = w.r5 >= 10 || w.vorhersage3 >= 10;
    if (w.fcFrost >= 2 || w.fcT < 5) return { stufe: 0, text: "Frost bzw. Kälte in Sicht – das Pilzwachstum lässt nach. Am ehesten noch frostharte Arten wie Trompetenpfifferling, Austernseitling oder Samtfußrübling." };
    if (w.bilanz90 != null && w.bilanz90 < -120 && w.r14 + w.fcRain < 30) return { stufe: 0, text: "Nach langer Trockenheit reicht der wenige Regen nicht – erst mehrere Regentage mit zusammen deutlich über 30 l/m² bringen die Pilze zurück." };
    if (w.ausloeser && mild) return { stufe: 2, text: "Auslöser erkannt: Abkühlung nach einer warmen Phase mit Regen – in etwa einer Woche gute Chancen, besonders für Steinpilze." };
    if (w.feuchte != null && w.feuchte >= 0.24 && mild) return { stufe: 2, text: "Boden ist feucht und es bleibt mild – gute Bedingungen für die nächsten 1–2 Wochen." };
    if (nass && mild) return { stufe: 2, text: "Ergiebiger Regen (gefallen oder erwartet) bei milden Temperaturen – in etwa 1–2 Wochen steigen die Chancen deutlich." };
    if (w.fcT > 24) return { stufe: 1, text: "Sehr warm – eher früh morgens suchen, an Nordhängen und in feuchten Tälern." };
    if (!nass && w.r14 < 15 && w.fcRain < 10) return { stufe: 0, text: "Zu trocken und kein nennenswerter Regen in Sicht – eher schlechte Aussichten." };
    return { stufe: 1, text: "Durchschnittliche Aussichten – nach dem nächsten ergiebigen Regen (≥ 10 l/m²) wird es besser." };
  }
  function aussichtHtml(w) {
    var a = aussicht(w);
    if (!a) return "";
    var farbe = ["#c62828", "#f9a825", "#2e7d32"][a.stufe], sym = ["▼", "►", "▲"][a.stufe];
    return '<div class="aussicht" style="border-left-color:' + farbe + '"><b style="color:' + farbe + '">' + sym +
      " Pilzwetter-Aussicht</b><br>" + esc(a.text) + "<br><small>Vorhersage 7 Tage: Ø " + num(w.fcT, 1) + " °C, " +
      num(w.fcRain) + " mm Regen" + (w.fcFrost ? ", " + w.fcFrost + " Frostnächte" : "") + "</small></div>";
  }

  // =====================================================================
  // 8 BEWERTUNG (0–100 Punkte)
  // =====================================================================
  /** Wetterteil der Bewertung: Regen (15), Bodenfeuchte (10), Temperatur & Luft (10) */
  function wetterTeile(w) {
    var teile = [];
    if (!w) {
      teile.push({ name: "Regen", p: 7, max: 15, why: "Wetterdaten nicht abrufbar – neutral bewertet." });
      teile.push({ name: "Bodenfeuchte aktuell", p: 5, max: 10, why: "Wetterdaten nicht abrufbar." });
      teile.push({ name: "Temperatur & Luft", p: 5, max: 10, why: "Wetterdaten nicht abrufbar." });
      return teile;
    }
    // Regen
    var rp = w.r14 < 5 ? 0 : w.r14 < 15 ? 5 : w.r14 < 30 ? 9 : w.r14 < 60 ? 12 : 13;
    var why = num(w.r14) + " mm in 14 Tagen";
    if (w.guterRegen) { rp += 3; why += ", ergiebiger Regen vor " + w.guterRegen.alter + " Tagen (" + num(w.guterRegen.mm) + " mm)"; }
    if (w.r7 > 80) { rp -= 3; why += ", sehr viel Regen in 7 Tagen (> 80 mm hemmt eher)"; }
    if (w.bilanz14 != null) {
      why += "; Wasserbilanz 14 Tage " + (w.bilanz14 >= 0 ? "+" : "") + num(w.bilanz14) + " mm";
      if (w.bilanz14 < -25) rp -= 2;
    }
    if (w.bilanz90 != null && w.bilanz90 < -120 && w.r14 < 40) {
      rp -= 3; why += "; langes Defizit (90 Tage: " + num(w.bilanz90) + " mm) – der Boden braucht mehr Regen";
    } else if (w.bilanz90 != null && w.bilanz90 < -60 && w.r14 < 25) {
      rp -= 1; why += "; trockener Sommer (90 Tage: " + num(w.bilanz90) + " mm)";
    }
    teile.push({ name: "Regen", p: Math.max(0, Math.min(15, rp)), max: 15, why: why + "." });
    // Bodenfeuchte
    if (w.feuchte != null) {
      var f = w.feuchte, fp = f < 0.12 ? 1 : f < 0.18 ? 4 : f < 0.24 ? 7 : f < 0.34 ? 10 : 8;
      var trend = w.feuchteVor7 != null ? (f - w.feuchteVor7 > 0.02 ? ", steigend" : f - w.feuchteVor7 < -0.02 ? ", fallend" : ", gleichbleibend") : "";
      teile.push({ name: "Bodenfeuchte aktuell", p: fp, max: 10, why: num(f * 100) + " Vol.-% in 3–27 cm Tiefe (" +
        (f < 0.12 ? "sehr trocken" : f < 0.18 ? "trocken" : f < 0.24 ? "mäßig feucht" : f < 0.34 ? "feucht" : "sehr nass") + trend + ")." });
    } else teile.push({ name: "Bodenfeuchte aktuell", p: 5, max: 10, why: "Keine Daten – neutral bewertet." });
    // Temperatur & Luft
    var t = w.t7, tp = 0, txt = [];
    if (t != null) {
      tp = t >= 10 && t <= 18 ? 6 : (t >= 6 && t < 10) || (t > 18 && t <= 22) ? 4 : (t >= 3 && t < 6) || (t > 22 && t <= 25) ? 2 : 0;
      txt.push("Ø " + num(t, 1) + " °C");
    }
    if (w.luft7 != null) {
      tp += w.luft7 >= 80 ? 2 : w.luft7 >= 65 ? 1 : 0;
      txt.push("Luftfeuchte " + num(w.luft7) + " %");
    }
    if (w.wind7 != null) {
      if (w.wind7 < 20) tp += 1;
      txt.push("Wind bis " + num(w.wind7) + " km/h");
    }
    if (w.amp7 != null && w.amp7 > 14) { tp -= 1; txt.push("große Tag-Nacht-Schwankung (" + num(w.amp7) + " K)"); }
    if (w.frost7 >= 2) { tp -= 3; txt.push(w.frost7 + " Frostnächte"); }
    else if (w.frost7 === 1) { tp -= 1; txt.push("1 Frostnacht"); }
    if (w.ausloeser) { tp += 2; txt.push("Auslöser: Abkühlung nach Wärme mit Regen"); }
    teile.push({ name: "Temperatur & Luft", p: Math.max(0, Math.min(10, tp)), max: 10, why: txt.join(", ") + " (letzte 7 Tage)." });
    return teile;
  }

  function bewerte(d) {
    var parts = [], total = 0, deckel = 100, deckelGrund = "";
    function add(name, p, max, why) { p = Math.round(p); parts.push({ name: name, p: p, max: max, why: why }); total += p; }
    function begrenze(wert, grund) { if (wert < deckel) { deckel = wert; deckelGrund = grund; } }
    var w = d.wetter, V = d.verlust;

    // 1 Wald & Baumart (25) – inkl. Waldverlust seit 2017
    var waldBekannt = d.baum !== undefined && d.baum !== null && d.baum !== "fehler";
    var kahl = (V && V.status === "verlust" && !V.temporaer) || (waldBekannt && d.baum.verlust);
    if (kahl) {
      add("Wald & Baumart", 3, 25, (V && V.status === "verlust" ? "Kronendachverlust seit " + V.datum + (V.vorlaeufig ? " (vorläufige Meldung)" : "") :
        "Kronendachverlust laut Baumartenkarte") + " – Kahlfläche oder abgestorbener Wald. Mykorrhiza-Pilze brauchen lebende Bäume; Ränder zum gesunden Wald können noch lohnen.");
      begrenze(35, "Kahlfläche");
    } else if (!waldBekannt) {
      add("Wald & Baumart", 10, 25, "Walddaten nicht abrufbar – neutral bewertet.");
    } else if (!d.baum.wald) {
      if (V && V.status === "intakt") add("Wald & Baumart", 15, 25, "Wald laut Waldverlust-Karte, Baumart nicht bestimmt.");
      else { add("Wald & Baumart", 0, 25, "Laut Satellitenkarte kein Wald an dieser Stelle."); begrenze(15, "kein Wald"); }
    } else {
      var bp = d.baum.info.myk ? 25 : d.baum.info.punkte;
      var bwhy = d.baum.art + (d.baum.info.myk ? " – wichtiger Mykorrhiza-Partner vieler Speisepilze" : " – weniger Mykorrhiza-Pilze");
      if (V && V.status === "verlust" && V.temporaer) { bp = Math.max(5, bp - 8); bwhy += "; vorübergehende Störung seit " + V.datum + " (z. B. Durchforstung, Sturm)"; }
      add("Wald & Baumart", bp, 25, bwhy + ".");
    }

    // 2 Boden-pH (15), Rückfall Gestein
    var ph = d.ph0;
    if (ph != null) {
      var pp = ph < 3.5 ? 6 : ph < 4 ? 12 : ph <= 6 ? 15 : ph <= 7 ? 12 : 9;
      add("Boden-pH", pp, 15, "pH " + num(ph, 1) + " (" + phKlasse(ph) + ")" +
        (ph > 7 ? " – Kalkboden: andere, kalkliebende Arten." : ph >= 4 && ph <= 6 ? " – ideal für Steinpilz & Pfifferling." : "."));
    } else if (d.gestein && d.gestein.haupt) {
      var k = d.gestein.haupt.klasse;
      var gp = { "stark sauer": 9, "sauer": 13, "schwach sauer": 13, "neutral": 11, "basisch": 9 }[k];
      add("Boden-pH", gp, 15, "Keine pH-Messwerte – abgeleitet aus Gestein: " + d.gestein.haupt.name + " (" + k + ").");
    } else add("Boden-pH", 8, 15, "Keine Daten – neutral bewertet.");

    // 3 nFK (10)
    if (d.nfk != null) {
      var np = d.nfk < 50 ? 3 : d.nfk < 90 ? 5 : d.nfk < 140 ? 8 : d.nfk < 270 ? 10 : 8;
      add("Wasserspeicher (nFK)", np, 10, num(d.nfk) + " mm (" + nfkKlasse(d.nfk) + ")" + (d.nfk >= 270 ? " – evtl. staunass." : "."));
    } else add("Wasserspeicher (nFK)", 5, 10, "Keine Daten – neutral bewertet.");

    // 4–6 Wetter (35)
    wetterTeile(w).forEach(function (t) { add(t.name, t.p, t.max, t.why); });

    // 7 Gelände (7): Exposition je nach Witterung
    var g = d.gelaende;
    if (g) {
      var trocken = w && (w.r14 < 20 || (w.t7 != null && w.t7 > 17) || (w.feuchte != null && w.feuchte < 0.18));
      var kuehl = w && w.t7 != null && w.t7 < 9;
      var nord = g.expo >= 292.5 || g.expo < 112.5, sued = g.expo >= 135 && g.expo < 247.5;
      var gp2, gw;
      if (g.neigung < 3) { gp2 = 4; gw = "eben"; }
      else if (trocken) { gp2 = nord ? 7 : sued ? 1 : 4; gw = nord ? "schattiger Hang – hält bei Trockenheit die Feuchte" : sued ? "sonniger Hang – trocknet schnell aus" : "Hang"; }
      else if (kuehl) { gp2 = sued ? 7 : nord ? 3 : 4; gw = sued ? "sonniger Hang – wärmer in der kühlen Jahreszeit" : nord ? "Schattenhang – bei Kälte ungünstig" : "Hang"; }
      else { gp2 = 5; gw = "Hang"; }
      if (g.form === "Senke/Tal" && trocken) { gp2 += 2; gw += ", Senke (feuchter)"; }
      if (g.form === "Kuppe/Rücken" && trocken) { gp2 -= 1; gw += ", Kuppe (trockener)"; }
      gp2 = Math.max(0, Math.min(7, gp2));
      add("Gelände", gp2, 7, num(g.hoehe) + " m ü. NN, " + (g.neigung < 3 ? "" : num(g.neigung) + "° nach " + himmelsrichtung(g.expo) + " – ") + gw + ".");
    } else add("Gelände", 3, 7, "Keine Höhendaten – neutral bewertet.");

    // 8 Gemeldete Funde in der Nähe (8), bezogen auf die Beobachtungsdichte
    var F = d.funde;
    if (F && F.liste) {
      var ne = F.liste.length, nf = F.gesamt, fu, fw;
      var arten = {};
      F.liste.forEach(function (x) { arten[x.art.de] = (arten[x.art.de] || 0) + 1; });
      var artText = Object.keys(arten).slice(0, 4).map(function (a) { return a + " (" + arten[a] + ")"; }).join(", ");
      if (nf == null) {
        fu = ne === 0 ? 2 : ne === 1 ? 5 : ne < 5 ? 7 : 8;
        fw = ne ? ne + " Speisepilz-Meldungen im Umkreis 1,5 km: " + artText + "." : "Keine gemeldeten Speisepilz-Funde im Umkreis von 1,5 km.";
      } else if (nf < 5) {
        fu = ne > 0 ? 5 : 3;
        fw = "Wenig beobachtete Gegend (" + nf + " Pilzmeldungen im Umkreis)" + (ne ? ": " + artText : "") + ".";
      } else {
        var anteil = ne / nf;
        fu = anteil >= 0.25 ? 8 : anteil >= 0.12 ? 7 : anteil >= 0.06 ? 5 : anteil > 0 ? 4 : 2;
        fw = ne + " Speisepilz- unter rund " + nf + " Pilzmeldungen im Umkreis (" + num(anteil * 100) + " %)" + (ne ? ": " + artText : "") + ".";
      }
      add("Funde in der Nähe", fu, 8, fw);
    } else add("Funde in der Nähe", 3, 8, "Funddaten nicht abrufbar – neutral bewertet.");

    var score = Math.round(Math.max(0, Math.min(100, total)));
    var gedeckelt = score > deckel;
    if (gedeckelt) score = deckel;
    return { score: score, parts: parts, deckelGrund: gedeckelt ? deckelGrund : "" };
  }

  // ---- persönliche Hotspots: Ähnlichkeit zu eigenen Fundstellen (nur auf dem Gerät) ----
  function fingerabdruck(d) {
    if (!d) return null;
    var g = d.gelaende || {};
    var klasse = d.ph0 != null ? phKlasse(d.ph0) : d.gestein && d.gestein.haupt ? d.gestein.haupt.klasse : null;
    return {
      baum: d.baum && d.baum !== "fehler" && d.baum.wald ? d.baum.art : null,
      ph: d.ph0 != null ? Math.round(d.ph0 * 10) / 10 : null, klasse: klasse,
      gestein: d.gestein && d.gestein.haupt ? d.gestein.haupt.name : null,
      nfk: d.nfk != null ? Math.round(d.nfk) : null,
      hoehe: g.hoehe != null ? Math.round(g.hoehe) : null,
      expo: g.expo != null ? Math.round(g.expo) : null, neigung: g.neigung != null ? Math.round(g.neigung) : null
    };
  }
  function aehnlich(d, fp) {
    if (!fp) return null;
    var p = 0, max = 0;
    if (fp.baum) { max += 35; if (d.baum && d.baum !== "fehler" && d.baum.wald && d.baum.art === fp.baum) p += 35; }
    if (fp.ph != null && d.ph0 != null) {
      max += 25; var dph = Math.abs(fp.ph - d.ph0); p += dph <= 0.4 ? 25 : dph <= 0.8 ? 15 : dph <= 1.2 ? 6 : 0;
    } else if (fp.klasse) {
      var k = d.ph0 != null ? phKlasse(d.ph0) : d.gestein && d.gestein.haupt ? d.gestein.haupt.klasse : null;
      if (k) { max += 20; if (k === fp.klasse) p += 20; }
    }
    if (fp.nfk != null && d.nfk != null) { max += 10; var dn = Math.abs(fp.nfk - d.nfk); p += dn <= 30 ? 10 : dn <= 60 ? 5 : 0; }
    if (fp.hoehe != null && d.gelaende) { max += 15; var dh = Math.abs(fp.hoehe - d.gelaende.hoehe); p += dh <= 100 ? 15 : dh <= 250 ? 8 : 0; }
    if (fp.expo != null && fp.neigung >= 3 && d.gelaende && d.gelaende.neigung >= 3) {
      max += 15; var de = Math.abs(((fp.expo - d.gelaende.expo + 540) % 360) - 180); p += de <= 45 ? 15 : de <= 90 ? 7 : 0;
    }
    if (max < 40) return null;
    return Math.round(100 * p / max);
  }
  function besteAehnlichkeit(d) {
    var best = null;
    ladeFundorte().forEach(function (f) {
      if (!f.fp) return;
      if (distM(d.ll, f) < 50) return; // die Fundstelle selbst nicht mitzählen
      var a = aehnlich(d, f.fp);
      if (a != null && (!best || a > best.wert)) best = { wert: a, name: f.name, art: f.art };
    });
    return best;
  }

  // ---- Saison: Kalender, bei passendem Wetter etwas früher oder länger ----
  function inSaison(a, m) { return a.von <= a.bis ? m >= a.von && m <= a.bis : m >= a.von || m <= a.bis; }
  function saisonStatus(a, m, w) {
    if (inSaison(a, m)) return "jetzt";
    if (w) {
      var nach = a.bis % 12 + 1, vor = (a.von + 10) % 12 + 1;
      // Mildes Wetter verlängert nur eine Saison, die im Spätsommer/Herbst endet;
      // Wärme und Regen holen nur Arten nach vorn, deren Saison im Frühjahr bis Herbst beginnt
      // (Winterpilze wie der Samtfußrübling brauchen dagegen Kälte).
      if (m === nach && a.bis >= 8 && a.bis <= 12 && w.t7 != null && w.t7 >= 7 && !w.frost7 && (w.fcFrost || 0) < 2) return "verlaengert";
      if (m === vor && a.von >= 3 && a.von <= 10 && w.t7 != null && w.t7 >= 12 && w.r14 >= 20) return "frueh";
    }
    return null;
  }
  function saisonArten(klasse, baumArt, w, wald) {
    var m = heute().getMonth() + 1;
    return PILZARTEN.map(function (a) { return { a: a, s: saisonStatus(a, m, w) }; }).filter(function (x) {
      var a = x.a;
      if (!x.s) return false;
      if (wald && a.lebensraum === "wiese") return false;
      if (!wald && a.lebensraum !== "wiese") return false;
      var boden = !klasse || a.boden.indexOf(klasse) >= 0;
      var baum = a.lebensraum === "holz" || !baumArt || !a.baum || a.baum.indexOf(baumArt) >= 0;
      return boden && baum;
    });
  }

  // =====================================================================
  // 9 ANALYSE & DETAILANSICHT
  // =====================================================================
  function analysiere(ll, mitDetails, vorab) {
    vorab = vorab || {};
    var q = abfragePunkt(ll); // im Datensparmodus auf ~100 m gerundet
    var jobs = {
      baum: safe(fetchBaum(q)),
      ph0: safe(fetchPh(q, 0)),
      nfk: safe(fetchNfk(q)),
      verlust: safe(fetchVerlust(q)),
      wetter: vorab.wetter !== undefined ? Promise.resolve(vorab.wetter) : safe(fetchWetter(q)),
      gelaende: vorab.gelaende !== undefined ? Promise.resolve(vorab.gelaende) : safe(fetchGelaende(q)),
      funde: vorab.funde !== undefined ? Promise.resolve(vorab.funde) : safe(fundeUmkreis(q, ll))
    };
    if (mitDetails) {
      jobs.ph1 = safe(fetchPh(q, 1));
      jobs.gestein = safe(fetchGestein(q));
      jobs.schutz = safe(fetchSchutz(q));
      jobs.maske = safe(fetchVerlustMaske(q));
    }
    var keys = Object.keys(jobs);
    return Promise.all(keys.map(function (k) { return jobs[k]; })).then(function (r) {
      var d = { ll: ll, fehler: 0 };
      keys.forEach(function (k, i) {
        var v = r[i];
        if (v === "fehler") { d.fehler++; d[k] = k === "baum" ? "fehler" : null; }
        else d[k] = v === undefined ? null : v;
      });
      // Art des Waldverlusts (dauerhaft oder vorübergehend) – beim Scan nur für betroffene Punkte nachladen
      var maskeP = d.verlust && d.verlust.status === "verlust" && !("maske" in d) ? safe(fetchVerlustMaske(q)) : Promise.resolve(d.maske);
      return maskeP.then(function (m) {
        d.maske = m === "fehler" || m === undefined ? null : m;
        if (d.verlust && d.verlust.status === "verlust" && d.maske != null) {
          d.verlust.temporaer = d.maske >= 2 && d.maske <= 4;
        }
        d.bew = bewerte(d);
        d.aehnlich = besteAehnlichkeit(d);
        return d;
      });
    });
  }
  /** Kahlfläche: dauerhafter Kronendachverlust laut DLR (vorübergehende Störungen zählen nicht) */
  function istKahl(d) {
    return !!(d.verlust && d.verlust.status === "verlust" && !d.verlust.temporaer) ||
      !!(d.baum && d.baum !== "fehler" && d.baum.verlust);
  }

  var clickMarker = null, letzteAnalyse = null;
  function zeigeAnalyse(ll) {
    if (clickMarker) map.removeLayer(clickMarker);
    clickMarker = L.circleMarker(ll, { radius: 9, color: "#fff", weight: 3, fillColor: "#2f6b3a", fillOpacity: 1 }).addTo(map);
    openSheet("detail");
    if (navigator.onLine === false) {
      $("detailBody").innerHTML = "<h2>Standort-Analyse</h2><p>📴 Keine Internetverbindung. Die Analyse braucht Daten aus dem Netz – " +
        "Karte (soweit gespeichert), Fundorte und Rückweg funktionieren aber auch offline.</p>" +
        '<div class="btnrow"><button class="btn primary" data-act="merken">⭐ Fundort merken</button></div>';
      $("detailBody").onclick = function (e) { if (e.target.getAttribute("data-act") === "merken") fundortMerken(ll, null, null); };
      return;
    }
    $("detailBody").innerHTML = '<h2>Standort-Analyse</h2><p><span class="spinner"></span>Frage Karten- und Wetterdaten ab …</p>';
    analysiere(ll, true).then(function (d) { letzteAnalyse = d; renderDetail(d); fpNachtragen(d); }).catch(function (e) {
      $("detailBody").innerHTML = "<h2>Standort-Analyse</h2><p>Fehler: " + esc(e.message) + "</p>";
    });
  }

  function renderDetail(d) {
    var b = d.bew, ll = d.ll;
    var h = '<div class="bigscore"><div class="scorebadge" style="background:' + scoreColor(b.score) + '">' + b.score + "</div>" +
      '<div><div class="lbl">' + scoreLabel(b.score) + '</div><div class="coords">' +
      ll.lat.toFixed(5) + ", " + ll.lng.toFixed(5) + "</div></div></div>";
    if (b.deckelGrund) h += '<p class="hint">Punktzahl begrenzt: ' + esc(b.deckelGrund) + ".</p>";
    if (d.schutz && (d.schutz.nsg || d.schutz.np)) {
      h += '<div class="card warnbox">⚠️ ' + (d.schutz.nsg ? "<b>Naturschutzgebiet „" + esc(d.schutz.nsg) + "“</b> – Pilze sammeln ist hier grundsätzlich verboten." : "") +
        (d.schutz.np ? (d.schutz.nsg ? "<br>" : "") + "<b>Nationalpark „" + esc(d.schutz.np) + "“</b> – Wegegebot und Sammelverbote je nach Zone beachten." : "") + "</div>";
    }
    if (d.aehnlich && d.aehnlich.wert >= 60) {
      h += '<div class="card aehnlichbox">🧡 Ähnlich wie dein Fundort „' + esc(d.aehnlich.name) + "“" +
        (d.aehnlich.art ? " (" + esc(d.aehnlich.art) + ")" : "") + ": <b>" + d.aehnlich.wert + " %</b> Übereinstimmung (Baumart, Boden, Höhe, Hanglage).</div>";
    }
    h += b.parts.map(function (p) {
      return '<div class="part"><div class="row"><span>' + esc(p.name) + "</span><b>" + p.p + " / " + p.max + "</b></div>" +
        '<div class="meter"><div style="width:' + Math.round(100 * p.p / p.max) + "%;background:" + scoreColor(100 * p.p / p.max) + '"></div></div>' +
        '<div class="why">' + esc(p.why) + "</div></div>";
    }).join("");

    // Pilz-Tendenz
    var wald = d.baum && d.baum !== "fehler" && d.baum.wald;
    var klasse = d.ph0 != null ? phKlasse(d.ph0) : d.gestein && d.gestein.haupt ? d.gestein.haupt.klasse : null;
    var tend = [];
    if (klasse) tend.push("<b>Boden (" + esc(klasse) + "):</b> " + esc(PILZ_TENDENZ[klasse]));
    if (wald && BAUM_PILZE[d.baum.art]) tend.push("<b>Bei " + esc(d.baum.art) + ":</b> " + esc(BAUM_PILZE[d.baum.art]));
    var saison = saisonArten(klasse, wald ? d.baum.art : null, d.wetter, !!wald || (d.verlust && d.verlust.status === "intakt"));
    if (saison.length) {
      tend.push("<b>Jetzt in Saison &amp; passend hier:</b> " + saison.map(function (x) {
        return esc(x.a.de) + (x.a.gefahr === "toedlich" ? " ☠️" : "") +
          (x.s === "verlaengert" ? " (noch, da mild)" : x.s === "frueh" ? " (schon möglich)" : "");
      }).join(", ") + (saison.some(function (x) { return x.a.gefahr === "toedlich"; }) ? "<br><small>☠️ = tödlich giftiger Doppelgänger – siehe Wissen → Pilzarten</small>" : ""));
    }
    if (tend.length) h += '<div class="tendenz">' + tend.join("<br>") + "<br><small>⚠️ Nur sicher bestimmte Pilze essen.</small></div>";
    h += aussichtHtml(d.wetter);

    // Datentabelle
    var rows = [];
    rows.push(["Baumart (Satellit)", d.baum === "fehler" ? "nicht abrufbar" : d.baum.wald ? d.baum.art + " · " + d.baum.quelle :
      d.baum.verlust ? "Kronendachverlust · " + d.baum.quelle : "kein Wald erkannt · " + d.baum.quelle]);
    if (d.verlust) {
      var V = d.verlust;
      rows.push(["Waldzustand (DLR)", V.status === "intakt" ? "intakter Wald (seit 2017 kein Verlust erkannt)" :
        V.status === "verlust" ? "Kronendachverlust seit " + V.datum + (V.temporaer ? " – vorübergehende Störung" : d.maske === 1 ? " – dauerhaft" : "") +
          (V.vorlaeufig ? " (vorläufig)" : "") : "kein Wald laut Verlust-Karte"]);
    }
    rows.push(["Boden-pH 0–30 cm", d.ph0 != null ? num(d.ph0, 1) + " – " + phKlasse(d.ph0) : "keine Daten"]);
    rows.push(["Boden-pH 30–100 cm", d.ph1 != null ? num(d.ph1, 1) + " – " + phKlasse(d.ph1) : "keine Daten"]);
    if (d.gestein) {
      var g = d.gestein;
      var chips = function (arr) {
        return arr.map(function (x) {
          return '<span class="chip"><span class="dot" style="background:' + PH_KLASSEN[x.klasse].farbe + '"></span>' +
            esc(x.name) + " · pH " + esc(x.ph) + "</span>";
        }).join(" ");
      };
      if (g.decke) rows.push(["Deckschicht", esc(g.decke.kurz) + (g.deckeG.length ? '<div class="chips">' + chips(g.deckeG) + "</div>" : ""), true]);
      if (g.basis) rows.push(["Gestein", esc(g.basis.kurz || g.basis.gruppe) +
        (g.basis.text && g.basis.text !== g.basis.kurz ? "<br><small>" + esc(g.basis.text) + "</small>" : "") +
        (g.basisG.length ? '<div class="chips">' + chips(g.basisG) + "</div>" : ""), true]);
    } else rows.push(["Gestein", "keine Daten"]);
    rows.push(["Nutzbare Feldkapazität", d.nfk != null ? num(d.nfk) + " mm (" + nfkKlasse(d.nfk) + ")" : "keine Daten"]);
    if (d.wetter) {
      var w = d.wetter;
      rows.push(["Regen 7 / 14 / 30 / 90 Tage", num(w.r7) + " / " + num(w.r14) + " / " + num(w.r30) + " / " + num(w.r90) + " mm"]);
      rows.push(["Regen nächste 3 Tage", num(w.vorhersage3) + " mm (Vorhersage)"]);
      if (w.bilanz14 != null) rows.push(["Wasserbilanz 14 / 90 Tage", (w.bilanz14 >= 0 ? "+" : "") + num(w.bilanz14) + " / " +
        (w.bilanz90 >= 0 ? "+" : "") + num(w.bilanz90) + " mm (Regen − Verdunstung)"]);
      rows.push(["Temperatur Ø 7 Tage", num(w.t7, 1) + " °C" + (w.amp7 != null ? ", Tag-Nacht " + num(w.amp7) + " K" : "") + (w.frost7 ? " (" + w.frost7 + " Frostnächte)" : "")]);
      if (w.luft7 != null) rows.push(["Luftfeuchte / Wind", num(w.luft7) + " % / bis " + num(w.wind7) + " km/h (Ø 7 Tage)"]);
      if (w.feuchte != null) rows.push(["Bodenfeuchte (Modell)", num(w.feuchte * 100) + " Vol.-%" +
        (w.feuchteVor7 != null ? " (vor 7 Tagen " + num(w.feuchteVor7 * 100) + " %)" : "")]);
    }
    if (d.gelaende) {
      var g2 = d.gelaende;
      rows.push(["Höhe / Hang", num(g2.hoehe) + " m ü. NN" + (g2.neigung >= 3 ? ", " + num(g2.neigung) + "° Neigung nach " + himmelsrichtung(g2.expo) : ", eben") +
        (g2.form ? ", " + g2.form : "")]);
    }
    if (d.funde && d.funde.liste && d.funde.liste.length) {
      var fl = d.funde.liste.slice().sort(function (a, c) { return (c.datum || "").localeCompare(a.datum || ""); }).slice(0, 6);
      rows.push(["Gemeldete Funde (1,5 km)", fl.map(function (f) {
        return esc(f.art.de) + " · " + esc(f.datum || "?") + " · " + num(distM(ll, f) / 1000, 1) + " km";
      }).join("<br>"), true]);
    }
    if (d.schutz && !d.schutz.fehler && !d.schutz.nsg && !d.schutz.np) rows.push(["Schutzgebiet", "kein Naturschutzgebiet / Nationalpark"]);
    h += '<table class="kv">' + rows.map(function (r) {
      return "<tr><td>" + esc(r[0]) + "</td><td>" + (r[2] ? r[1] : esc(r[1])) + "</td></tr>";
    }).join("") + "</table>";
    if (d.fehler) h += '<p class="hint">Einige Dienste haben nicht geantwortet – Werte dort neutral bewertet.</p>';

    h += '<div class="btnrow">' +
      '<button class="btn primary" data-act="merken">⭐ Fundort merken</button>' +
      '<button class="btn" data-act="nav">🧭 Navigieren</button>' +
      '<button class="btn" data-act="topo">⛰️ topographic-map</button></div>';
    $("detailBody").innerHTML = h;
    $("detailBody").onclick = function (e) {
      var a = e.target.getAttribute("data-act");
      if (a === "merken") fundortMerken(ll, b.score, fingerabdruck(d));
      if (a === "nav") navigiere(ll);
      if (a === "topo") openWeb(topoUrl(ll, 15), "topographic-map.com");
    };
  }

  // Tippen auf die Karte: offenes Menü erst schließen, sonst Standort-Analyse
  map.on("click", function (e) {
    if (openName && openName !== "detail") { closeSheets(); return; }
    zeigeAnalyse(e.latlng);
  });

  // =====================================================================
  // 10 PILZ-CHANCEN: KARTENAUSSCHNITT SCANNEN
  // =====================================================================
  var scanLayer = L.layerGroup().addTo(map);
  var scanning = false;

  function renderWetterBox(w, ort) {
    if (!w) { $("weatherBox").innerHTML = ""; return; }
    var bars = w.letzte.map(function (mm) {
      var hgt = Math.min(40, Math.round(mm * 2));
      return '<span title="' + num(mm, 1) + ' mm" style="display:inline-block;width:6%;margin-right:1%;height:' + Math.max(2, hgt) +
        'px;background:#1e88e5;border-radius:2px 2px 0 0;vertical-align:bottom"></span>';
    }).join("");
    $("weatherBox").innerHTML = '<div class="card"><b>Wetter ' + esc(ort) + "</b><br>" +
      "Regen 7 / 14 / 30 Tage: <b>" + num(w.r7) + " / " + num(w.r14) + " / " + num(w.r30) + " mm</b><br>" +
      "Ø Temperatur 7 Tage: <b>" + num(w.t7, 1) + " °C</b> · Vorhersage 3 Tage: <b>" + num(w.vorhersage3) + " mm</b>" +
      (w.bilanz14 != null ? "<br>Wasserbilanz 14 / 90 Tage: <b>" + (w.bilanz14 >= 0 ? "+" : "") + num(w.bilanz14) + " / " +
        (w.bilanz90 >= 0 ? "+" : "") + num(w.bilanz90) + " mm</b>" : "") +
      (w.feuchte != null ? "<br>Bodenfeuchte: <b>" + num(w.feuchte * 100) + " Vol.-%</b>" : "") +
      (w.luft7 != null ? " · Luftfeuchte: <b>" + num(w.luft7) + " %</b>" : "") +
      '<div style="height:44px;display:flex;align-items:flex-end;margin-top:6px">' + bars + "</div>" +
      '<div class="hint" style="margin:2px 0 0">Tagesregen der letzten 14 Tage (rechts = gestern)</div></div>' + aussichtHtml(w);
  }

  function scan() {
    if (scanning) return;
    if (map.getZoom() < 11) {
      toast("Bitte weiter hineinzoomen (mind. Zoomstufe 11), damit der Scan aussagekräftig ist.", 4000);
      closeSheets();
      return;
    }
    if (navigator.onLine === false) { toast("Der Scan braucht eine Internetverbindung."); return; }
    scanning = true;
    $("btnScan").disabled = true;
    scanLayer.clearLayers();
    $("scanResults").innerHTML = "";
    var b = map.getBounds();
    var size = map.getSize();
    var cols = 6, rows = Math.max(5, Math.min(9, Math.round(cols * size.y / size.x)));
    var pts = [];
    for (var r = 0; r < rows; r++) {
      for (var c = 0; c < cols; c++) {
        pts.push(L.latLng(
          b.getNorth() - (r + 0.5) * (b.getNorth() - b.getSouth()) / rows,
          b.getWest() + (c + 0.5) * (b.getEast() - b.getWest()) / cols));
      }
    }
    var radius = Math.max(8, Math.min(size.x / cols, size.y / rows) / 2.8);
    var done = 0, results = [];
    var prog = $("scanProgress");
    prog.classList.remove("hidden");
    function upd() {
      prog.querySelector(".bar").style.width = Math.round(100 * done / pts.length) + "%";
      prog.querySelector(".ptext").textContent = "Analysiere " + done + " / " + pts.length + " Punkte …";
    }
    upd();
    var wetterP = fetchWetter(map.getCenter()).then(function (w) { renderWetterBox(w, "im Ausschnitt"); return w; }).catch(function () { return null; });
    var alleNachbarn = [];
    pts.forEach(function (p) { alleNachbarn = alleNachbarn.concat(nachbarn(p)); });
    var hoehenP = elevations(alleNachbarn).catch(function () { return null; });
    var dLat = 1500 / 111320, dLng = 1500 / (111320 * Math.cos(b.getCenter().lat * Math.PI / 180));
    var s = b.getSouth() - dLat, wst = b.getWest() - dLng, n = b.getNorth() + dLat, e = b.getEast() + dLng;
    var fundeP = fetchFunde(s, wst, n, e).catch(function () { return null; });
    var dichteP = fetchPilzDichte(s, wst, n, e).catch(function () { return null; });

    Promise.all([wetterP, hoehenP, fundeP, dichteP]).then(function (pre) {
      // erwartete Zahl aller Pilzmeldungen pro 1,5-km-Kreis (gleichmäßig verteilt angenommen)
      var flaecheKm2 = (n - s) * 111.32 * (e - wst) * 111.32 * Math.cos(b.getCenter().lat * Math.PI / 180);
      var erwartet = pre[3] != null && flaecheKm2 > 0 ? Math.round(pre[3] / flaecheKm2 * Math.PI * 1.5 * 1.5) : null;
      return Promise.all(pts.map(function (ll, pi) {
        var vorab = {
          wetter: pre[0],
          gelaende: pre[1] ? gelaendeAus(pre[1].slice(pi * 5, pi * 5 + 5)) : null,
          funde: pre[2] ? { liste: pre[2].filter(function (f) { return distM(ll, f) <= 1500; }), gesamt: erwartet } : null
        };
        return analysiere(ll, false, vorab).then(function (d) {
          results.push(d);
          var kahl = istKahl(d), wald = d.baum && d.baum !== "fehler" && d.baum.wald && !kahl;
          var m = L.circleMarker(ll, {
            radius: wald ? radius : radius * 0.4, weight: 1, color: "#fff",
            fillColor: wald ? scoreColor(d.bew.score) : "#777", fillOpacity: wald ? 0.8 : 0.6, bubblingMouseEvents: false
          }).bindTooltip(wald ? String(d.bew.score) : kahl ? "Kahlfläche" : "kein Wald",
            { permanent: wald, direction: "center", className: wald ? "scoretip" : "" });
          m.on("click", function (ev) { L.DomEvent.stopPropagation(ev); zeigeAnalyse(ll); });
          scanLayer.addLayer(m);
          if (wald && d.aehnlich && d.aehnlich.wert >= 75) {
            scanLayer.addLayer(L.marker(ll, { icon: L.divIcon({ className: "pilz-marker klein", html: "🧡", iconSize: [16, 16], iconAnchor: [-6, 22] }), interactive: false }));
          }
        }).catch(function () {}).then(function () { done++; upd(); });
      }));
    }).then(function () {
      scanning = false;
      $("btnScan").disabled = false;
      prog.classList.add("hidden");
      var waldErg = results.filter(function (d) { return d.baum && d.baum !== "fehler" && d.baum.wald && !istKahl(d); });
      var top = waldErg.slice().sort(function (a, b2) { return b2.bew.score - a.bew.score; }).slice(0, 5);
      if (!top.length) {
        $("scanResults").innerHTML = '<div class="card">Im Ausschnitt wurde kein Wald gefunden – Karte verschieben und erneut scannen.</div>';
        return;
      }
      top.forEach(function (d, i) {
        scanLayer.addLayer(L.marker(d.ll, {
          icon: L.divIcon({ className: "pilz-marker", html: "🍄", iconSize: [24, 24], iconAnchor: [12, 28] }),
          zIndexOffset: 1000 - i
        }).on("click", function () { zeigeAnalyse(d.ll); }));
      });
      top.forEach(function (d, i) {
        fetchSchutz(abfragePunkt(d.ll)).then(function (sg) {
          if (sg && (sg.nsg || sg.np)) {
            var el = document.getElementById("nsg-" + i);
            if (el) el.textContent = "⚠️ " + (sg.nsg ? "Naturschutzgebiet – Sammeln verboten" : "Nationalpark – Regeln beachten");
          }
        }).catch(function () {});
      });
      var aehnl = waldErg.filter(function (d) { return d.aehnlich && d.aehnlich.wert >= 60; })
        .sort(function (a, b2) { return b2.aehnlich.wert - a.aehnlich.wert; }).slice(0, 3);
      function karte(d, i, gruppe) {
        var info = [d.baum.art, d.ph0 != null ? "pH " + num(d.ph0, 1) : null, d.nfk != null ? "nFK " + num(d.nfk) + " mm" : null,
          d.gelaende && d.gelaende.neigung >= 3 ? "Hang " + himmelsrichtung(d.gelaende.expo) : null,
          d.funde && d.funde.liste && d.funde.liste.length ? d.funde.liste.length + " Funde" : null]
          .filter(Boolean).join(" · ");
        var titel = gruppe === "top" ? "#" + (i + 1) + " " + scoreLabel(d.bew.score) :
          "🧡 " + d.aehnlich.wert + " % wie „" + d.aehnlich.name + "“";
        return '<div class="card spot"><div class="scorebadge" style="background:' + scoreColor(d.bew.score) + '">' + d.bew.score +
          '</div><div class="txt"><b>' + esc(titel) + "</b><br>" + esc(info) +
          (gruppe === "top" ? '<div class="nsg" id="nsg-' + i + '"></div>' : "") + "</div>" +
          '<div class="acts"><button class="btn small" data-g="' + gruppe + '" data-i="' + i + '" data-a="show">Details</button>' +
          '<button class="btn small" data-g="' + gruppe + '" data-i="' + i + '" data-a="nav">Hin</button></div></div>';
      }
      $("scanResults").innerHTML = "<h3>Beste Stellen im Ausschnitt</h3>" + top.map(function (d, i) { return karte(d, i, "top"); }).join("") +
        (aehnl.length ? "<h3>Ähnlich wie deine Fundorte</h3>" + aehnl.map(function (d, i) { return karte(d, i, "aehnl"); }).join("") : "") +
        '<button class="btn small" id="btnClearScan">Scan-Punkte ausblenden</button>';
      $("scanResults").onclick = function (ev) {
        var i = ev.target.getAttribute("data-i"), a = ev.target.getAttribute("data-a"), gr = ev.target.getAttribute("data-g");
        if (ev.target.id === "btnClearScan") { scanLayer.clearLayers(); $("scanResults").innerHTML = ""; return; }
        if (i == null) return;
        var liste = gr === "aehnl" ? aehnl : top;
        if (a === "show") { map.setView(liste[i].ll, Math.max(map.getZoom(), 14)); zeigeAnalyse(liste[i].ll); }
        if (a === "nav") navigiere(liste[i].ll);
      };
      toast("Scan fertig – grüne Punkte = gute Chancen" + (aehnl.length ? ", 🧡 = ähnlich wie deine Funde" : "") + ".", 4000);
    });
  }
  $("btnScan").addEventListener("click", scan);
  $("btnRateCenter").addEventListener("click", function () { zeigeAnalyse(map.getCenter()); });
  $("btnRateGps").addEventListener("click", function () {
    locate(function (ll) { zeigeAnalyse(ll); });
  });

  // =====================================================================
  // 11 WISSEN: Pilzarten, Giftpilze, Gesteine, Notfall
  // =====================================================================
  $("phKlassenLegende").innerHTML = Object.keys(PH_KLASSEN).map(function (k) {
    return '<span class="chip"><span class="dot" style="background:' + PH_KLASSEN[k].farbe + '"></span>' +
      esc(k) + " (pH " + esc(PH_KLASSEN[k].bereich) + ")</span>";
  }).join("");
  function renderGesteine(filter) {
    var f = (filter || "").toLowerCase();
    var order = ["basisch", "neutral", "schwach sauer", "sauer", "stark sauer"];
    var list = GESTEINE.slice().sort(function (a, b) { return order.indexOf(a.klasse) - order.indexOf(b.klasse); })
      .filter(function (g) { return !f || (g.name + " " + g.gruppe + " " + g.info).toLowerCase().indexOf(f) >= 0; });
    $("gesteinListe").innerHTML = list.map(function (g) {
      var k = PH_KLASSEN[g.klasse];
      return '<div class="gestein" style="border-left-color:' + k.farbe + '"><div class="head"><span>' + esc(g.name) +
        '</span><span class="ph">pH ' + esc(g.ph) + '</span></div><div class="meta">' + esc(g.gruppe) + " · " + esc(g.klasse) +
        "</div><p>" + esc(g.info) + '</p><p class="meta">🍄 ' + esc(PILZ_TENDENZ[g.klasse]) + "</p></div>";
    }).join("") || '<p class="hint">Kein Gestein gefunden.</p>';
  }
  $("gesteinFilter").addEventListener("input", function (e) { renderGesteine(e.target.value); });
  renderGesteine("");

  var LEBENSRAUM = { wald: "Waldboden", holz: "an Holz", wiese: "Wiesen & Waldränder" };
  function renderArten() {
    var m = heute().getMonth() + 1, nurJetzt = $("nurSaison").checked;
    var list = PILZARTEN.map(function (a) { return { a: a, s: saisonStatus(a, m, letztesWetter) }; })
      .filter(function (x) { return !nurJetzt || x.s; });
    $("artenListe").innerHTML = list.map(function (x) {
      var a = x.a;
      var monate = MONATE.map(function (mn, i) {
        var on = inSaison(a, i + 1);
        return '<span class="mo' + (on ? " on" : "") + (i + 1 === m ? " now" : "") + '" title="' + mn + '">' + mn.charAt(0) + "</span>";
      }).join("");
      var gef = a.gefahr === "toedlich" ? '<div class="gefahr t">☠️ Verwechslung mit tödlich giftigem Pilz möglich</div>'
        : a.gefahr === "giftig" ? '<div class="gefahr g">⚠️ giftige oder ungenießbare Doppelgänger</div>' : "";
      return '<div class="art"><div class="head"><span>' + esc(a.de) + "</span><i>" + esc(a.sci) + "</i></div>" +
        '<div class="monate">' + monate + "</div>" +
        (x.s === "verlaengert" ? '<div class="meta">🌤️ Saison verlängert – es ist noch mild genug.</div>' :
          x.s === "frueh" ? '<div class="meta">🌱 Früh dran – warm und feucht genug.</div>' : "") +
        '<div class="meta">' + esc(LEBENSRAUM[a.lebensraum] || "") + " · Boden: " + esc(a.boden.join(", ")) +
        (a.baum ? " · Bäume: " + esc(a.baum.join(", ")) : "") + "</div>" +
        gef + '<p class="vorsicht">' + esc(a.vorsicht) + "</p>" +
        (a.roh ? '<p class="meta">🔥 Roh giftig – immer gut durchgaren.</p>' : "") +
        (a.cs ? '<p class="meta">☢️ Reichert Cäsium-137 an – in Teilen Süddeutschlands (v. a. Bayerischer Wald) laut BfS 2026 noch über 1.000 Bq/kg. Maßvoll essen.</p>' : "") +
        "</div>";
    }).join("") || '<p class="hint">Aktuell keine der aufgeführten Arten in Saison.</p>';
  }
  $("nurSaison").addEventListener("change", renderArten);
  renderArten();

  $("giftpilzListe").innerHTML = GIFTPILZE.map(function (g) {
    return '<div class="art gift"><div class="head"><span>☠️ ' + esc(g.de) + "</span><i>" + esc(g.sci) + "</i></div>" +
      '<p class="vorsicht"><b>Merkmale:</b> ' + esc(g.merkmale) + "</p>" +
      '<p class="vorsicht"><b>Wirkung:</b> ' + esc(g.wirkung) + "</p>" +
      '<p class="meta">Verwechslung mit: ' + esc(g.verwechslung) + "</p></div>";
  }).join("");

  $("giftnotruf").innerHTML = GIFTNOTRUF.map(function (g) {
    return '<div class="card spot"><div class="txt"><b>' + esc(g.ort) + "</b><br><small>" + esc(g.laender) + "</small></div>" +
      '<div class="acts"><button class="btn small primary" data-tel="' + esc(g.tel.replace(/\s/g, "")) + '">📞 ' + esc(g.tel) + "</button></div></div>";
  }).join("");
  $("sheet-wissen").addEventListener("click", function (e) {
    var tel = e.target.getAttribute("data-tel");
    if (tel) oeffneExtern("tel:" + tel);
    var tab = e.target.getAttribute("data-tab");
    if (tab) {
      Array.prototype.forEach.call(document.querySelectorAll("#sheet-wissen .seg button"), function (bt) { bt.classList.toggle("active", bt === e.target); });
      Array.prototype.forEach.call(document.querySelectorAll("#sheet-wissen .tabpane"), function (dv) { dv.classList.toggle("hidden", dv.id !== "tab-" + tab); });
      if (tab === "arten") renderArten();
    }
    var link = e.target.getAttribute("data-link");
    if (link) openWeb(link, e.target.textContent);
  });

  // =====================================================================
  // 12 EXTERNE SEITEN & NAVIGATION
  // =====================================================================
  function openWeb(url, title) {
    if (nativ("openWeb")) NB.openWeb(url, title || "");
    else window.open(url, "_blank");
  }
  function oeffneExtern(url) {
    if (nativ("openExternal")) NB.openExternal(url);
    else window.open(url, "_blank");
  }
  /** Übergibt das Ziel an eine Navigations-App deiner Wahl (die App selbst sendet dabei nichts). */
  function navigiere(ll) {
    var geo = "geo:" + ll.lat.toFixed(6) + "," + ll.lng.toFixed(6) + "?q=" + ll.lat.toFixed(6) + "," + ll.lng.toFixed(6) + "(Pilzstelle)";
    if (nativ("openExternal")) NB.openExternal(geo);
    else window.open("https://www.openstreetmap.org/?mlat=" + ll.lat + "&mlon=" + ll.lng + "#map=16/" + ll.lat + "/" + ll.lng, "_blank");
  }
  function topoUrl(ll, z) {
    var p = abfragePunkt(ll); // im Datensparmodus auf ca. 100 m gerundet
    return "https://de-de.topographic-map.com/map-95z57/Deutschland/?center=" + p.lat.toFixed(5) + "%2C" +
      p.lng.toFixed(5) + "&zoom=" + (z || Math.max(10, Math.min(16, map.getZoom())));
  }
  var EXTERN = [
    { t: "Waldmonitor", s: "Baumarten & Waldzustand per Satellit", u: "https://map3d.remote-sensing-solutions.de/waldmonitor-deutschland/" },
    { t: "Topografische Karte", s: "topographic-map.com – Höhen an dieser Stelle", u: function () { return topoUrl(map.getCenter()); } },
    { t: "Regensumme 24 h", s: "Kachelmannwetter (Radar) – auch 48 h bis 30 Tage", u: "https://kachelmannwetter.com/de/regensummen/niederschlagssumme-24std.html" },
    { t: "Regensummen", s: "Kachelmannwetter – Zeitraum wählbar", u: "https://kachelmannwetter.com/de/regensummen" },
    { t: "Akkumulierter Niederschlag", s: "Kachelmannwetter – Vorhersage", u: "https://kachelmannwetter.com/de/modellkarten/euro/deutschland/akkumulierter-niederschlag.html" },
    { t: "Niederschlag Messwerte", s: "Kachelmannwetter – Stationen 24 h", u: "https://kachelmannwetter.com/de/messwerte/niederschlagssumme.html" },
    { t: "Thünen-Atlas Boden-pH", s: "Originalkarte des Thünen-Instituts", u: "https://atlas.thuenen.de/catalogue/#/map/212" },
    { t: "BGR Geoviewer", s: "Geologie & Boden der BGR", u: "https://geoviewer.bgr.de/" },
    { t: "Pilzsachverständige", s: "DGfM – Pilzberatung in deiner Nähe", u: "https://www.dgfm-ev.de/service/pilzsachverstaendige" },
    { t: "Cäsium in Pilzen", s: "Bundesamt für Strahlenschutz", u: "https://www.bfs.de/DE/themen/ion/umwelt/lebensmittel/pilze-wildbret/pilze-wildbret.html" }
  ];
  $("externLinks").innerHTML = EXTERN.map(function (e, i) {
    return '<button data-i="' + i + '"><b>' + esc(e.t) + "</b><small>" + esc(e.s) + "</small></button>";
  }).join("");
  $("externLinks").addEventListener("click", function (ev) {
    var btn = ev.target.closest("button");
    if (!btn) return;
    var e = EXTERN[+btn.getAttribute("data-i")];
    openWeb(typeof e.u === "function" ? e.u() : e.u, e.t);
  });

  // =====================================================================
  // 13 FUNDORTE (nur auf dem Handy gespeichert)
  // =====================================================================
  var fundLayer = L.layerGroup().addTo(map);
  function ladeFundorte() { return store.get("pk_fundorte", []); }
  function speichereFundorte(list) { store.set("pk_fundorte", list); renderFundorte(); }
  function fpText(fp) {
    if (!fp) return "";
    return [fp.baum, fp.ph != null ? "pH " + num(fp.ph, 1) : fp.klasse, fp.hoehe != null ? num(fp.hoehe) + " m" : null,
      fp.neigung >= 3 ? "Hang " + himmelsrichtung(fp.expo) : null].filter(Boolean).join(" · ");
  }
  function renderFundorte() {
    var list = ladeFundorte();
    fundLayer.clearLayers();
    list.forEach(function (f) {
      L.marker([f.lat, f.lng], { icon: L.divIcon({ className: "pilz-marker", html: "⭐", iconSize: [24, 24], iconAnchor: [12, 12] }) })
        .bindPopup("<b>" + esc(f.name) + "</b>" + (f.art ? "<br>" + esc(f.art) : "") + "<br>" + esc(f.datum) + (f.notiz ? "<br>" + esc(f.notiz) : ""))
        .addTo(fundLayer);
    });
    var arten = {};
    list.forEach(function (f) { if (f.art) arten[f.art] = (arten[f.art] || 0) + 1; });
    var stat = Object.keys(arten).sort(function (a, b) { return arten[b] - arten[a]; }).map(function (a) { return esc(a) + " (" + arten[a] + ")"; }).join(", ");
    $("fundortListe").innerHTML = (stat ? '<p class="hint">Deine Funde: ' + stat + "</p>" : "") + (list.length ? list.map(function (f, i) {
      return '<div class="card spot"><div class="txt"><b>' + esc(f.name) + "</b>" + (f.art ? " · " + esc(f.art) : "") + "<br>" + esc(f.datum) +
        (f.score != null ? " · Chance " + f.score : "") + (f.notiz ? "<br>" + esc(f.notiz) : "") +
        (f.fp ? '<br><small class="muted">' + esc(fpText(f.fp)) + "</small>" : "") + "</div>" +
        '<div class="acts"><button class="btn small" data-f="' + i + '" data-a="zeigen">Zeigen</button>' +
        '<button class="btn small" data-f="' + i + '" data-a="nav">Hin</button>' +
        '<button class="btn small" data-f="' + i + '" data-a="del">Löschen</button></div></div>';
    }).join("") : '<p class="hint">Noch keine Fundorte gespeichert.</p>');
  }
  $("fundortListe").addEventListener("click", function (e) {
    var i = e.target.getAttribute("data-f"), a = e.target.getAttribute("data-a");
    if (i == null) return;
    var list = ladeFundorte(), f = list[+i];
    if (!f) return;
    if (a === "zeigen") { closeSheets(); map.setView([f.lat, f.lng], 15); }
    if (a === "nav") navigiere(L.latLng(f.lat, f.lng));
    if (a === "del" && confirm("Fundort „" + f.name + "“ löschen?")) {
      list.splice(+i, 1);
      speichereFundorte(list);
    }
  });

  // Eingabedialog statt Browser-Abfragen
  $("dlgArt").innerHTML = '<option value="">– Art (optional) –</option>' + PILZARTEN.map(function (a) {
    return "<option>" + esc(a.de) + "</option>";
  }).join("") + "<option>andere Art</option>";
  var dlgPunkt = null, dlgScore = null, dlgFp = null;
  function fundortMerken(ll, score, fp) {
    // Merkmale nur aus einer bereits erfolgten Standort-Analyse übernehmen – Speichern selbst sendet nichts
    var nah = letzteAnalyse && distM(letzteAnalyse.ll, ll) < 50 ? letzteAnalyse : null;
    dlgPunkt = ll;
    dlgFp = fp || (nah ? fingerabdruck(nah) : null);
    dlgScore = score != null ? score : nah ? nah.bew.score : null;
    $("dlgName").value = "";
    $("dlgNotiz").value = "";
    $("dlgArt").value = "";
    $("dlgHinweis").textContent = dlgFp ? "Wird nur auf diesem Handy gespeichert." :
      "Wird nur auf diesem Handy gespeichert. Tipp: Tippe die Stelle später einmal an (Standort-Analyse) – dann kann die App ähnliche Stellen 🧡 finden.";
    $("dlg").classList.remove("hidden");
  }
  /** Nach einer Standort-Analyse: Merkmale für Fundorte in der Nähe (≤ 50 m) ergänzen, die noch keine haben. */
  function fpNachtragen(d) {
    var list = ladeFundorte(), geaendert = false;
    list.forEach(function (f) {
      if (!f.fp && distM(d.ll, f) < 50) { f.fp = fingerabdruck(d); if (f.score == null) f.score = d.bew.score; geaendert = true; }
    });
    if (geaendert) speichereFundorte(list);
  }
  $("dlgAbbrechen").addEventListener("click", function () { $("dlg").classList.add("hidden"); });
  $("dlgSpeichern").addEventListener("click", function () {
    if (!dlgPunkt) return;
    var art = $("dlgArt").value, jetzt = heute();
    var eintrag = {
      id: jetzt.getTime().toString(36) + Math.random().toString(36).slice(2, 6),
      name: $("dlgName").value.trim() || art || "Fundort", art: art, notiz: $("dlgNotiz").value.trim(),
      lat: +dlgPunkt.lat.toFixed(6), lng: +dlgPunkt.lng.toFixed(6), score: dlgScore,
      datum: jetzt.toLocaleDateString("de-DE"), zeit: jetzt.toISOString(), fp: dlgFp
    };
    var list = ladeFundorte();
    list.unshift(eintrag);
    speichereFundorte(list);
    $("dlg").classList.add("hidden");
    toast("Fundort gespeichert ⭐ (nur auf diesem Handy)");
  });
  map.on("contextmenu", function (e) { fundortMerken(e.latlng, null, null); });

  // Export als GPX (für GPS-Geräte, Karten-Apps) – du bestimmst, wohin die Datei geht
  function fundorteGpx() {
    var list = ladeFundorte();
    return '<?xml version="1.0" encoding="UTF-8"?>\n<gpx version="1.1" creator="PilzKarte" xmlns="http://www.topografix.com/GPX/1/1">\n' +
      list.map(function (f) {
        return '  <wpt lat="' + f.lat + '" lon="' + f.lng + '">' + (f.zeit ? "<time>" + esc(f.zeit) + "</time>" : "") +
          "<name>" + esc(f.name) + "</name><desc>" + esc([f.art, f.datum, f.notiz].filter(Boolean).join(" | ")) + "</desc>" +
          (f.art ? "<type>" + esc(f.art) + "</type>" : "") + "</wpt>";
      }).join("\n") + "\n</gpx>\n";
  }
  function dateiSpeichern(name, mime, inhalt) {
    if (nativ("saveFile")) { NB.saveFile(name, mime, inhalt); return; }
    var a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([inhalt], { type: mime }));
    a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
  }
  $("btnExport").addEventListener("click", function () {
    if (!ladeFundorte().length) { toast("Noch keine Fundorte zum Exportieren."); return; }
    dateiSpeichern("pilzkarte-fundorte-" + heute().toISOString().slice(0, 10) + ".gpx", "application/gpx+xml", fundorteGpx());
  });
  $("btnImport").addEventListener("click", function () { $("importFile").click(); });
  $("importFile").addEventListener("change", function (e) {
    var file = e.target.files && e.target.files[0];
    if (!file) return;
    var r = new FileReader();
    r.onload = function () {
      var neu = [];
      try {
        var doc = new DOMParser().parseFromString(String(r.result), "application/xml");
        Array.prototype.forEach.call(doc.getElementsByTagName("wpt"), function (w) {
          var get = function (tag) { var el = w.getElementsByTagName(tag)[0]; return el ? el.textContent : ""; };
          var lat = parseFloat(w.getAttribute("lat")), lng = parseFloat(w.getAttribute("lon"));
          if (!isFinite(lat) || !isFinite(lng)) return;
          var zeit = get("time");
          neu.push({ id: "imp" + Math.random().toString(36).slice(2, 9), name: get("name") || "Fundort", art: get("type"), notiz: "",
            lat: lat, lng: lng, score: null, zeit: zeit || undefined,
            datum: zeit ? new Date(zeit).toLocaleDateString("de-DE") : "importiert" });
        });
      } catch (err) { neu = []; }
      if (!neu.length) { toast("Keine Wegpunkte in der Datei gefunden."); return; }
      var list = ladeFundorte();
      var key = function (f) { return f.lat.toFixed(5) + "," + f.lng.toFixed(5) + "," + f.name; };
      var vorhanden = {};
      list.forEach(function (f) { vorhanden[key(f)] = true; });
      var dazu = neu.filter(function (f) { return !vorhanden[key(f)]; });
      speichereFundorte(dazu.concat(list));
      toast(dazu.length + " Fundorte importiert.");
      e.target.value = "";
    };
    r.readAsText(file);
  });

  // „Meine Stellen prüfen“: aktuelles Pilzwetter an allen eigenen Fundorten (nur auf Knopfdruck)
  $("btnStellen").addEventListener("click", function () {
    var list = ladeFundorte();
    if (!list.length) { toast("Noch keine Fundorte gespeichert."); return; }
    if (navigator.onLine === false) { toast("Dafür ist eine Internetverbindung nötig."); return; }
    var zellen = {};
    list.forEach(function (f) {
      var k = (Math.round(f.lat * 10) / 10) + "," + (Math.round(f.lng * 10) / 10);
      (zellen[k] = zellen[k] || { ll: L.latLng(f.lat, f.lng), orte: [] }).orte.push(f);
    });
    $("stellenErgebnis").innerHTML = '<p><span class="spinner"></span>Prüfe das Wetter an ' + Object.keys(zellen).length + " Stelle(n) …</p>";
    Promise.all(Object.keys(zellen).map(function (k) {
      return fetchWetter(zellen[k].ll).then(function (w) { return { k: k, w: w }; }).catch(function () { return { k: k, w: null }; });
    })).then(function (res) {
      var zeilen = [];
      res.forEach(function (x) {
        var teile = wetterTeile(x.w), p = 0;
        teile.forEach(function (t) { p += t.p; });
        var proz = Math.round(100 * p / 35), au = aussicht(x.w);
        zellen[x.k].orte.forEach(function (f) { zeilen.push({ f: f, proz: x.w ? proz : null, au: au, w: x.w }); });
      });
      zeilen.sort(function (a, b) { return (b.proz || 0) - (a.proz || 0); });
      $("stellenErgebnis").innerHTML = "<h3>Pilzwetter an deinen Stellen</h3>" + zeilen.map(function (z, i) {
        var sym = z.au ? ["▼", "►", "▲"][z.au.stufe] : "";
        return '<div class="card spot"><div class="scorebadge" style="background:' + scoreColor(z.proz || 0) + '">' + (z.proz != null ? z.proz : "?") +
          '</div><div class="txt"><b>' + esc(z.f.name) + "</b>" + (z.f.art ? " · " + esc(z.f.art) : "") +
          (z.w ? "<br><small>" + num(z.w.r14) + " mm/14 Tage · Boden " + (z.w.feuchte != null ? num(z.w.feuchte * 100) + " %" : "–") +
            " · Ø " + num(z.w.t7, 1) + " °C " + sym + "</small>" : "<br><small>Wetter nicht abrufbar</small>") + "</div>" +
          '<div class="acts"><button class="btn small" data-si="' + i + '">Zeigen</button></div></div>';
      }).join("") + '<p class="hint">Prozent = Wetteranteil der Bewertung (Regen, Bodenfeuchte, Temperatur & Luft). ▲ gute, ► mittlere, ▼ schlechte Aussicht.</p>';
      $("stellenErgebnis").onclick = function (e) {
        var i = e.target.getAttribute("data-si");
        if (i == null) return;
        var f = zeilen[+i].f;
        closeSheets();
        map.setView([f.lat, f.lng], 15);
      };
    });
  });

  // =====================================================================
  // 14 RÜCKWEG ZUM AUTO (GPS und Kompass nur solange aktiv und App geöffnet)
  // =====================================================================
  var auto = store.get("pk_auto", null);
  var autoLayer = L.layerGroup().addTo(map), rueckWatch = null, rueckAktiv = false, rueckLinie = null, ichMarker = null;
  var letztePos = null, letzteGenauigkeit = null, kompass = null, angekommenGemeldet = false;
  function zeichneAuto() {
    autoLayer.clearLayers();
    rueckLinie = null; ichMarker = null;
    if (auto) {
      L.marker([auto.lat, auto.lng], { icon: L.divIcon({ className: "pilz-marker", html: "🚗", iconSize: [24, 24], iconAnchor: [12, 12] }) })
        .bindPopup("Startpunkt / Auto<br>" + esc(auto.datum)).addTo(autoLayer);
    }
    $("rueckInfo").textContent = auto ? "Gespeichert: " + auto.datum : "Noch kein Startpunkt gespeichert.";
    $("btnRueck").disabled = !auto;
  }
  function peilung(a, b) {
    var y = Math.sin((b.lng - a.lng) * Math.PI / 180) * Math.cos(b.lat * Math.PI / 180);
    var x = Math.cos(a.lat * Math.PI / 180) * Math.sin(b.lat * Math.PI / 180) -
      Math.sin(a.lat * Math.PI / 180) * Math.cos(b.lat * Math.PI / 180) * Math.cos((b.lng - a.lng) * Math.PI / 180);
    return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
  }
  function rueckAnzeige() {
    if (!rueckAktiv || !auto) return;
    if (!letztePos) {
      $("rueckPill").innerHTML = 'Suche Standort … <button id="rueckStop" class="btn small">Beenden</button>';
      return;
    }
    var ziel = L.latLng(auto.lat, auto.lng), dist = distM(letztePos, ziel), richt = peilung(letztePos, ziel);
    var pfeil = kompass != null ? (richt - kompass + 360) % 360 : richt;
    $("rueckPill").innerHTML = '<span class="pfeil" style="transform:rotate(' + Math.round(pfeil) + 'deg)">⬆</span> 🚗 ' +
      (dist >= 1000 ? num(dist / 1000, 1) + " km" : num(dist) + " m") + " · " + himmelsrichtung(richt) + " (" + Math.round(richt) + "°)" +
      '<small class="kmodus">' + (kompass != null ? "Pfeil = Richtung vom Handy aus (Handy flach halten)" : "Pfeil = Richtung auf der Karte (Norden oben)") +
      (letzteGenauigkeit > 1000 ? " · ⚠️ Nur ungefährer Standort – in den Android-Einstellungen „Genauen Standort“ für PilzKarte erlauben" :
        letzteGenauigkeit > 40 ? " · GPS ± " + num(letzteGenauigkeit) + " m" : "") + "</small>" +
      ' <button id="rueckStop" class="btn small">Beenden</button>';
    if (dist < 25 && !angekommenGemeldet) { angekommenGemeldet = true; toast("Du bist am Startpunkt angekommen 🚗", 4000); }
    if (dist > 60) angekommenGemeldet = false;
  }
  function rueckUpdate(pos) {
    letztePos = L.latLng(pos.coords.latitude, pos.coords.longitude);
    letzteGenauigkeit = pos.coords.accuracy;
    var ziel = L.latLng(auto.lat, auto.lng);
    if (!ichMarker) ichMarker = L.marker(letztePos, { icon: L.divIcon({ className: "", html: '<div class="gps-dot"></div>', iconSize: [16, 16] }) }).addTo(autoLayer);
    else ichMarker.setLatLng(letztePos);
    if (!rueckLinie) rueckLinie = L.polyline([letztePos, ziel], { color: "#1e88e5", weight: 4, dashArray: "8 8" }).addTo(autoLayer);
    else rueckLinie.setLatLngs([letztePos, ziel]);
    rueckAnzeige();
  }
  function kompassEvent(e) {
    var h = null;
    if (e.webkitCompassHeading != null) h = e.webkitCompassHeading;
    else if (e.absolute && e.alpha != null) h = (360 - e.alpha) % 360;
    if (h == null) return;
    var winkel = (screen.orientation && screen.orientation.angle) || window.orientation || 0;
    kompass = (h + winkel + 360) % 360;
    rueckAnzeige();
  }
  var kompassName = "ondeviceorientationabsolute" in window ? "deviceorientationabsolute" : "deviceorientation";
  function kompassStart() { kompass = null; window.addEventListener(kompassName, kompassEvent); }
  function kompassStop() { window.removeEventListener(kompassName, kompassEvent); kompass = null; }
  function rueckStartWatch() {
    if (!navigator.geolocation || rueckWatch !== null) return;
    rueckWatch = navigator.geolocation.watchPosition(rueckUpdate, function (err) {
      toast("Standort nicht ermittelbar: " + (err.code === 1 ? "Berechtigung fehlt" : err.message), 4000);
    }, { enableHighAccuracy: true, maximumAge: 5000, timeout: 30000 });
    kompassStart();
    if ($("optWach").checked && nativ("setKeepScreenOn")) NB.setKeepScreenOn(true);
  }
  function rueckStopWatch() {
    if (rueckWatch !== null && navigator.geolocation) navigator.geolocation.clearWatch(rueckWatch);
    rueckWatch = null;
    kompassStop();
    if (nativ("setKeepScreenOn")) NB.setKeepScreenOn(false);
  }
  function rueckwegStarten() {
    if (!auto) return;
    rueckAktiv = true;
    letztePos = null;
    angekommenGemeldet = false;
    $("rueckPill").classList.remove("hidden");
    rueckAnzeige();
    closeSheets();
    rueckStartWatch();
  }
  function rueckwegBeenden() {
    rueckAktiv = false;
    rueckStopWatch();
    $("rueckPill").classList.add("hidden");
    if (rueckLinie) { autoLayer.removeLayer(rueckLinie); rueckLinie = null; }
    if (ichMarker) { autoLayer.removeLayer(ichMarker); ichMarker = null; }
  }
  $("rueckPill").addEventListener("click", function (e) {
    if (e.target.id === "rueckStop") rueckwegBeenden();
    else if (auto) map.setView([auto.lat, auto.lng], Math.max(map.getZoom(), 15));
  });
  $("btnAutoMerken").addEventListener("click", function () {
    locate(function (ll) {
      auto = { lat: +ll.lat.toFixed(6), lng: +ll.lng.toFixed(6), datum: heute().toLocaleString("de-DE") };
      store.set("pk_auto", auto);
      zeichneAuto();
      toast("Startpunkt gespeichert 🚗 (nur auf diesem Handy)");
    });
  });
  $("btnRueck").addEventListener("click", rueckwegStarten);
  $("btnAutoLoeschen").addEventListener("click", function () {
    rueckwegBeenden();
    auto = null;
    store.set("pk_auto", null);
    zeichneAuto();
  });
  $("optWach").checked = store.get("pk_wach", true);
  $("optWach").addEventListener("change", function (e) {
    store.set("pk_wach", e.target.checked);
    if (rueckAktiv && nativ("setKeepScreenOn")) NB.setKeepScreenOn(e.target.checked);
  });
  zeichneAuto();

  // =====================================================================
  // 15 GPS & SUCHE
  // =====================================================================
  var gpsMarker = null, gpsCircle = null;
  function locate(cb) {
    if (!navigator.geolocation) { toast("Standort nicht verfügbar."); return; }
    toast("Suche Standort …", 8000);
    navigator.geolocation.getCurrentPosition(function (pos) {
      var ll = L.latLng(pos.coords.latitude, pos.coords.longitude);
      if (gpsMarker) { map.removeLayer(gpsMarker); map.removeLayer(gpsCircle); }
      gpsCircle = L.circle(ll, { radius: pos.coords.accuracy, weight: 1, color: "#1e88e5", fillOpacity: 0.1 }).addTo(map);
      gpsMarker = L.marker(ll, { icon: L.divIcon({ className: "", html: '<div class="gps-dot"></div>', iconSize: [16, 16] }) }).addTo(map);
      map.setView(ll, Math.max(map.getZoom(), 14));
      $("toast").classList.add("hidden");
      if (cb) cb(ll);
    }, function (err) {
      toast("Standort nicht ermittelbar: " + (err.code === 1 ? "Berechtigung fehlt" : err.message), 4000);
    }, { enableHighAccuracy: true, timeout: 20000, maximumAge: 60000 });
  }
  $("btnLocate").addEventListener("click", function () { locate(); });

  $("searchForm").addEventListener("submit", function (e) {
    e.preventDefault();
    var q = $("searchInput").value.trim();
    if (!q) return;
    $("searchInput").blur();
    var url = "https://nominatim.openstreetmap.org/search?format=json&limit=6&countrycodes=de&accept-language=de&q=" + encodeURIComponent(q);
    getJson(url).then(function (list) {
      var box = $("searchResults");
      if (!list.length) { toast("Nichts gefunden."); box.classList.add("hidden"); return; }
      box.innerHTML = list.map(function (r, i) {
        return '<button data-i="' + i + '">' + esc(r.display_name) + "</button>";
      }).join("");
      box.classList.remove("hidden");
      box.onclick = function (ev) {
        var i = ev.target.getAttribute("data-i");
        if (i == null) return;
        var r = list[+i];
        box.classList.add("hidden");
        closeSheets();
        if (r.boundingbox) {
          map.fitBounds([[+r.boundingbox[0], +r.boundingbox[2]], [+r.boundingbox[1], +r.boundingbox[3]]], { maxZoom: 14 });
        } else map.setView([+r.lat, +r.lon], 13);
      };
    }).catch(function (err) { toast("Suche fehlgeschlagen: " + err.message); });
  });

  // =====================================================================
  // 16 OFFLINE-KARTEN
  // Angesehene Kartenbilder speichert die App selbst (frisch 7–30 Tage, gelöscht nach 60). Vorab laden nur
  // bei TopPlusOpen – dessen Nutzungsbedingungen erlauben das Speichern.
  // =====================================================================
  function offlineInfo() {
    if (!nativ("cacheInfo")) { $("offlineInfo").textContent = "Offline-Speicher gibt es nur in der Android-App."; return; }
    try {
      var c = JSON.parse(NB.cacheInfo());
      $("offlineInfo").textContent = "Gespeichert: " + num(c.dateien) + " Kartenbilder, " + num(c.bytes / 1048576, 1) + " MB (höchstens 500 MB).";
    } catch (e) { $("offlineInfo").textContent = ""; }
  }
  function kachelnFuer(bounds, zVon, zBis) {
    var urls = [];
    for (var z = zVon; z <= zBis; z++) {
      var nw = map.project(bounds.getNorthWest(), z).divideBy(256).floor();
      var se = map.project(bounds.getSouthEast(), z).divideBy(256).floor();
      for (var x = nw.x; x <= se.x; x++) {
        for (var y = nw.y; y <= se.y; y++) {
          urls.push(TOPPLUS_URL.replace("{z}", z).replace("{x}", x).replace("{y}", y));
        }
      }
    }
    return urls;
  }
  $("btnOffline").addEventListener("click", function () {
    if (!nativ("downloadTiles")) { toast("Offline-Karten gibt es nur in der Android-App."); return; }
    // dazu drei gröbere Stufen für die Übersicht (nur wenige zusätzliche Bilder)
    var zBis = +$("offlineZoom").value, zVon = Math.max(8, Math.min(map.getZoom(), zBis) - 3);
    var urls = kachelnFuer(map.getBounds(), zVon, zBis);
    if (urls.length > 6000) { toast("Ausschnitt zu groß (" + num(urls.length) + " Bilder) – bitte weiter hineinzoomen oder eine kleinere Detailstufe wählen.", 5000); return; }
    if (!confirm(num(urls.length) + " Kartenbilder der amtlichen Karte (ca. " + num(urls.length * 25 / 1024) + " MB) für diesen Ausschnitt speichern?\nTipp: im WLAN laden.")) return;
    $("offlineProgress").classList.remove("hidden");
    NB.downloadTiles(JSON.stringify(urls));
  });
  window.__offlineProgress = function (fertig, gesamt, fehler, beendet, abgebrochen) {
    var p = $("offlineProgress");
    p.classList.remove("hidden");
    p.querySelector(".bar").style.width = Math.round(100 * fertig / Math.max(1, gesamt)) + "%";
    p.querySelector(".ptext").textContent = !beendet ? "Lade " + num(fertig) + " / " + num(gesamt) + " … (pausiert, solange die App im Hintergrund ist)" :
      abgebrochen ? "Abgebrochen nach " + num(fertig) + " von " + num(gesamt) + " Bildern" :
      "Fertig: " + num(fertig) + " Bilder" + (fehler ? ", " + fehler + " fehlgeschlagen" : "");
    if (beendet) {
      setTimeout(function () { p.classList.add("hidden"); }, 5000);
      if (!abgebrochen) toast(fehler ? "Kartenausschnitt gespeichert – " + (fehler === 1 ? "1 Bild fehlt" : fehler + " Bilder fehlen") + " (Netz prüfen)." : "Kartenausschnitt offline gespeichert ✓");
      offlineInfo();
    }
  };
  $("btnOfflineStop").addEventListener("click", function () { if (nativ("cancelDownload")) NB.cancelDownload(); });
  $("btnOfflineLoeschen").addEventListener("click", function () {
    if (!nativ("clearTileCache")) return;
    if (!confirm("Alle gespeicherten Kartenbilder löschen?")) return;
    NB.clearTileCache();
    $("offlineInfo").textContent = "Offline-Speicher wird geleert …";
    setTimeout(offlineInfo, 2500);
    toast("Offline-Speicher geleert.");
  });
  window.addEventListener("offline", function () { toast("📴 Offline – die Karte zeigt gespeicherte Bilder.", 4000); });

  // =====================================================================
  // 17 UPDATES (nur auf Knopfdruck)
  // =====================================================================
  var info = appInfo();
  $("versionInfo").textContent = "Installierte Version: " + (info.versionName || "?") + (info.versionCode ? " (Nr. " + info.versionCode + ")" : "");
  $("repoFeld").value = store.get("pk_repo", STANDARD_REPO);
  $("repoFeld").addEventListener("change", function (e) {
    var v = e.target.value.trim().replace(/^https?:\/\/github\.com\//i, "").replace(/\/+$/, "");
    if (!/^[\w.-]+\/[\w.-]+$/.test(v)) { toast("Bitte im Format NAME/PROJEKT eingeben."); e.target.value = store.get("pk_repo", STANDARD_REPO); return; }
    e.target.value = v;
    store.set("pk_repo", v);
  });

  $("btnUpdateSuchen").addEventListener("click", function () {
    var repo = store.get("pk_repo", STANDARD_REPO);
    $("updateErgebnis").innerHTML = '<p><span class="spinner"></span>Frage GitHub nach der neuesten Version …</p>';
    getJson("https://api.github.com/repos/" + repo + "/releases/latest").then(function (r) {
      var m = /(\d+)\s*$/.exec(r.tag_name || ""), neu = m ? +m[1] : 0;
      var apk = (r.assets || []).filter(function (a) { return /\.apk$/i.test(a.name); })[0];
      var apkUrl = apk && /^https:\/\/github\.com\//.test(apk.browser_download_url || "") ? apk.browser_download_url : null;
      if (apkUrl && neu > (info.versionCode || 0)) {
        var notizen = String(r.body || "").replace(/\r/g, "").trim().slice(0, 900);
        $("updateErgebnis").innerHTML = '<div class="card"><b>Neue Version ' + esc(r.tag_name) + " verfügbar.</b>" +
          (notizen ? '<div class="notizen">' + esc(notizen) + "</div>" : "") +
          '<small>Nach dem Herunterladen die Datei antippen und „Installieren“ wählen. Deine Fundorte bleiben erhalten.</small><br>' +
          '<button class="btn primary small" id="btnApkLaden">⬇️ Herunterladen</button></div>';
        $("btnApkLaden").onclick = function () { oeffneExtern(apkUrl); };
      } else {
        $("updateErgebnis").innerHTML = '<p class="hint">✓ Du hast die neueste Version' + (r.tag_name ? " (" + esc(r.tag_name) + ")" : "") + ".</p>";
      }
    }).catch(function (e) {
      $("updateErgebnis").innerHTML = '<p class="hint">GitHub nicht erreichbar (' + esc(e.message) + ").</p>";
    });
  });

  // Claude-Routine: sucht Neuigkeiten und macht Vorschläge – eingebaut wird erst nach deiner Freigabe
  var ROUTINE_MUSTER = /^https:\/\/api\.anthropic\.com\/v1\/claude_code\/routines\/[A-Za-z0-9_-]+\/fire$/;
  function claudeStatus() {
    var url = store.get("pk_routine_url", ""), token = nativ("hasSecret") && NB.hasSecret("routine_token");
    $("claudeStatus").textContent = url && token ? "✓ Eingerichtet." : "Noch nicht eingerichtet – siehe Anleitung unten.";
    $("btnClaude").disabled = !(url && token);
    $("routineUrl").value = url;
  }
  $("btnClaudeSpeichern").addEventListener("click", function () {
    var url = $("routineUrl").value.trim(), token = $("routineToken").value.replace(/\s+/g, "");
    if (!ROUTINE_MUSTER.test(url)) { toast("Die Adresse muss so aussehen: https://api.anthropic.com/v1/claude_code/routines/…/fire", 5000); return; }
    if (token && !/^sk-ant-[A-Za-z0-9_-]+$/.test(token)) { toast("Der Schlüssel beginnt mit „sk-ant-“ – bitte vollständig kopieren.", 5000); return; }
    if (!nativ("setSecret")) { toast("Nur in der Android-App möglich."); return; }
    if (token && NB.setSecret("routine_token", token) === false) { toast("Schlüssel konnte nicht gespeichert werden."); return; }
    store.set("pk_routine_url", url);
    $("routineToken").value = "";
    claudeStatus();
    toast("Gespeichert – der Schlüssel liegt verschlüsselt nur auf diesem Handy.");
  });
  $("btnClaudeEntfernen").addEventListener("click", function () {
    if (nativ("deleteSecret")) NB.deleteSecret("routine_token");
    store.set("pk_routine_url", null);
    claudeStatus();
  });
  var CLAUDE_FEHLER = {
    400: "Die Routine ist pausiert oder die Anfrage wurde abgelehnt – auf claude.ai/code/routines prüfen.",
    401: "Der Schlüssel passt nicht (mehr) – auf claude.ai/code/routines neu erzeugen und hier eintragen.",
    403: "Kein Zugriff – Claude-Abo (Pro oder höher) und Claude Code im Web prüfen.",
    404: "Routine nicht gefunden – Adresse prüfen.",
    429: "Zu viele Starts in kurzer Zeit – bitte in einer Stunde erneut versuchen.",
    500: "Claude ist gerade gestört – bitte später erneut versuchen.",
    503: "Claude ist gerade überlastet – bitte später erneut versuchen."
  };
  $("btnClaude").addEventListener("click", function () {
    var url = store.get("pk_routine_url", "");
    if (!url || !nativ("fireRoutine")) { toast("Bitte zuerst einrichten."); return; }
    var text = "Update-Anfrage aus der PilzKarte-App. Installierte Version: " + (info.versionName || "?") +
      " (Nr. " + (info.versionCode || "?") + "). Datum: " + heute().toISOString().slice(0, 10) + ".";
    var knopf = $("btnClaude");
    knopf.disabled = true; // Doppelstarts vermeiden (jeder Start ist eine eigene Sitzung)
    setTimeout(function () { claudeStatus(); }, 60000);
    $("updateErgebnis").innerHTML = '<p><span class="spinner"></span>Starte Claude …</p>';
    nativeAufruf("fireRoutine", [url, text], 75000).then(function (body) {
      var j = {};
      try { j = JSON.parse(body); } catch (e) { /* egal */ }
      var link = j.claude_code_session_url;
      $("updateErgebnis").innerHTML = '<div class="card">✓ Claude sucht jetzt nach Neuigkeiten und schreibt dir Vorschläge. ' +
        "Antworte in der Sitzung mit den Nummern, die eingebaut werden sollen – erst dann wird etwas geändert." +
        (link ? '<br><button class="btn primary small" id="btnSitzung">Sitzung öffnen</button>' : "") + "</div>";
      if (link) {
        $("btnSitzung").onclick = function () { oeffneExtern(link); };
        oeffneExtern(link);
      }
    }).catch(function (e) {
      var m = /HTTP (\d+)/.exec(e.message || ""), code = m ? +m[1] : 0;
      if (/Zeitüberschreitung/.test(e.message)) {
        // Ausgang unbekannt – Knopf bleibt kurz gesperrt, damit keine zweite Sitzung entsteht
        $("updateErgebnis").innerHTML = '<p class="hint">Keine Antwort erhalten. Bitte in Claude (claude.ai/code) nachsehen, ob die Sitzung trotzdem gestartet wurde.</p>';
        return;
      }
      $("updateErgebnis").innerHTML = '<p class="hint">Start fehlgeschlagen: ' +
        esc(CLAUDE_FEHLER[code] || (e.message + " – Internetverbindung, Adresse und Schlüssel prüfen.")) + "</p>";
      claudeStatus();
    });
  });
  claudeStatus();

  // =====================================================================
  // 18 DATENSCHUTZ & SPERRE
  // =====================================================================
  $("optPrivat").checked = privat;
  $("optPrivat").addEventListener("change", function (e) {
    privat = e.target.checked;
    store.set("pk_privat", privat);
    toast(privat ? "Datensparmodus an: Koordinaten werden auf ca. 100 m gerundet." : "Datensparmodus aus: genaue Koordinaten.");
  });
  function einstellungen() {
    try { if (nativ("getSettings")) return JSON.parse(NB.getSettings()); } catch (e) { /* egal */ }
    return { lock: false, secure: false, lockAvailable: false };
  }
  var es = einstellungen();
  $("optSperre").checked = !!es.lock;
  $("optSchutz").checked = !!es.secure;
  if (!nativ("setAppLock")) { $("optSperre").disabled = true; $("optSchutz").disabled = true; }
  var sperrTimer = null;
  $("optSperre").addEventListener("change", function (e) {
    if (!nativ("setAppLock")) return;
    if (!e.target.checked) { NB.setAppLock(false); toast("App-Sperre aus."); return; }
    // Einschalten erst nach erfolgreicher Bestätigung – so kann sich niemand aussperren
    e.target.checked = false;
    if (!NB.setAppLock(true)) {
      toast("Bitte zuerst eine Displaysperre (PIN, Muster oder Fingerabdruck) im Handy einrichten.", 5000);
      return;
    }
    e.target.disabled = true;
    toast("Bitte mit Fingerabdruck, Gesicht oder PIN bestätigen …", 4000);
    clearTimeout(sperrTimer);
    sperrTimer = setTimeout(function () { $("optSperre").disabled = false; }, 120000);
  });
  window.__sperreErgebnis = function (ok) {
    clearTimeout(sperrTimer);
    $("optSperre").disabled = false;
    $("optSperre").checked = !!ok;
    toast(ok ? "App-Sperre an: Beim Öffnen fragt die App nach Fingerabdruck, Gesicht oder PIN." : "App-Sperre nicht eingeschaltet (nicht bestätigt).", 4000);
  };
  $("optSchutz").addEventListener("change", function (e) {
    if (nativ("setSecureScreen")) NB.setSecureScreen(e.target.checked);
    toast(e.target.checked ? "Bildschirmfotos und Vorschau in der App-Übersicht sind jetzt gesperrt." : "Bildschirmfotos wieder erlaubt.");
  });
  $("btnAllesLoeschen").addEventListener("click", function () {
    if (!confirm("Wirklich ALLE App-Daten löschen? (Fundorte, Startpunkt, Einstellungen, Offline-Karten, Claude-Schlüssel)\nTipp: vorher Fundorte exportieren.")) return;
    rueckwegBeenden();
    if (nativ("deleteSecret")) NB.deleteSecret("routine_token");
    if (nativ("clearTileCache")) NB.clearTileCache();
    store.clearAll();
    location.reload();
  });

  // =====================================================================
  // 19 MENÜ, ZURÜCK-TASTE, HINTERGRUND & START
  // =====================================================================
  var openName = "";
  function openSheet(name) {
    Array.prototype.forEach.call(document.querySelectorAll(".sheet"), function (s) { s.classList.toggle("open", s.id === "sheet-" + name); });
    Array.prototype.forEach.call(document.querySelectorAll("#bottomnav button"), function (bt) {
      bt.classList.toggle("active", bt.getAttribute("data-sheet") === (name === "detail" ? "" : name));
    });
    openName = name;
    $("searchResults").classList.add("hidden");
    if (name === "ebenen") renderLayerMenu();
    if (name === "mehr") offlineInfo();
    if (name === "chancen" && !$("weatherBox").innerHTML && navigator.onLine !== false) {
      fetchWetter(map.getCenter()).then(function (w) { renderWetterBox(w, "in Kartenmitte"); }).catch(function () {});
    }
  }
  function closeSheets() { openSheet(""); }
  Array.prototype.forEach.call(document.querySelectorAll("#bottomnav button"), function (bt) {
    bt.addEventListener("click", function () {
      var n = bt.getAttribute("data-sheet");
      openSheet(openName === n ? "" : n);
    });
  });
  Array.prototype.forEach.call(document.querySelectorAll(".sheet-handle"), function (hd) { hd.addEventListener("click", closeSheets); });

  // Zurück-Taste von Android
  window.handleBack = function () {
    if (!$("dlg").classList.contains("hidden")) { $("dlg").classList.add("hidden"); return true; }
    if (!$("searchResults").classList.contains("hidden")) { $("searchResults").classList.add("hidden"); return true; }
    if (openName) { closeSheets(); return true; }
    return false;
  };

  // App im Hintergrund: GPS und Kompass aus, nichts abrufen (Android hält zusätzlich alle Anfragen an)
  window.onAppPause = function () { appPausiert = true; rueckStopWatch(); };
  window.onAppResume = function () {
    appPausiert = false;
    rueckkehrZeit = Date.now();
    neuZeichnen.splice(0).forEach(planeNeuzeichnen);
    if (rueckAktiv) rueckStartWatch();
  };
  document.addEventListener("visibilitychange", function () {
    if (document.hidden) window.onAppPause(); else window.onAppResume();
  });

  // Start
  setBase(state.base);
  Object.keys(state.ov || {}).forEach(function (id) {
    var def = overlayDef(id);
    if (def) overlayLayers[id] = makeOverlay(def).addTo(map);
  });
  renderLegends();
  renderFundorte();
  if (!store.get("pk_seen", false)) {
    store.set("pk_seen", true);
    setTimeout(function () { toast("Tipp: Auf die Karte tippen = Standort-Analyse. Lange drücken = Fundort merken. Wissen → Notfall: Giftnotruf.", 7000); }, 800);
  }

  // für Tests
  window.PK = {
    bewerte: bewerte, map: map, analysiere: analysiere, setOverlay: setOverlay, openSheet: openSheet,
    wetterAuswerten: wetterAuswerten, aehnlich: aehnlich, saisonStatus: saisonStatus, monatAusIndex: monatAusIndex
  };
})();
