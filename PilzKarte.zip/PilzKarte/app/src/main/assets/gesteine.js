/*
 * Gesteine / Ausgangsmaterialien in Deutschland und die typische Bodenreaktion
 * (pH-Wert) der daraus entstehenden Böden. Werte sind Richtwerte für Waldböden
 * bzw. naturnahe Böden (pH in Wasser); Kalkung, Nadelstreu und Lössauflagen
 * können den Wert vor Ort deutlich verschieben.
 *
 * "muster" sind reguläre Ausdrücke, mit denen die Beschreibung der BGR-Karte
 * (GÜK250, Petrographie) einem Gestein zugeordnet wird. Reihenfolge = Priorität
 * (spezifische Begriffe zuerst).
 */
window.PH_KLASSEN = {
  "stark sauer":   { farbe: "#c62828", bereich: "< 4,5" },
  "sauer":         { farbe: "#ef6c00", bereich: "4,5 – 5,5" },
  "schwach sauer": { farbe: "#c0ca33", bereich: "5,5 – 6,5" },
  "neutral":       { farbe: "#2e7d32", bereich: "6,5 – 7,3" },
  "basisch":       { farbe: "#1565c0", bereich: "> 7,3" }
};

window.GESTEINE = [
  { name: "Kalksandstein", gruppe: "Sedimentgestein", klasse: "neutral", ph: "6,5 – 7,8",
    muster: [/kalksandstein/, /kalkig(er)? sandstein/],
    info: "Sandstein mit kalkigem Bindemittel. Böden meist basenreich, oberflächlich oft entkalkt." },
  { name: "Geschiebemergel", gruppe: "Eiszeitliche Ablagerung", klasse: "neutral", ph: "6,5 – 8,0",
    muster: [/geschiebemergel/, /\bmergel.*\bgeschiebe/],
    info: "Kalkhaltige Grundmoräne (Norddeutschland, Alpenvorland). In den oberen 1–2 m oft zu Geschiebelehm entkalkt." },
  { name: "Geschiebelehm", gruppe: "Eiszeitliche Ablagerung", klasse: "schwach sauer", ph: "4,5 – 6,0",
    muster: [/geschiebelehm/, /\bgeschiebe/, /\bmoräne/, /grundmoräne/, /\btill\b/],
    info: "Entkalkte Grundmoräne. Nährstoffreicher als Sande, Buchen- und Eichenmischwälder." },
  { name: "Lösslehm", gruppe: "Windablagerung", klasse: "schwach sauer", ph: "4,5 – 6,5",
    muster: [/lösslehm/, /lößlehm/, /\bentkalkt/],
    info: "Entkalkter Löss. Tiefgründige Parabraunerden, gute Wasserspeicherung." },
  { name: "Löss", gruppe: "Windablagerung", klasse: "basisch", ph: "7,0 – 8,2",
    muster: [/\blöss/, /\blöß/, /\bloess/],
    info: "Frischer Löss ist kalkhaltig (bis 20 % Kalk). Unter Wald meist oberflächlich entkalkt (dann Lösslehm)." },
  { name: "Kalktuff / Travertin", gruppe: "Sedimentgestein", klasse: "basisch", ph: "7,5 – 8,5",
    muster: [/kalktuff/, /travertin/, /sinterkalk/, /quellkalk/, /wiesenkalk/, /seekreide/],
    info: "Aus Quellwasser ausgefällter Kalk. Sehr kalkreich." },
  { name: "Dolomit", gruppe: "Sedimentgestein", klasse: "basisch", ph: "7,0 – 8,3",
    muster: [/dolomit/],
    info: "Calcium-Magnesium-Karbonat (z. B. Frankenjura, Zechstein). Flachgründige Rendzinen." },
  { name: "Kreide (Schreibkreide)", gruppe: "Sedimentgestein", klasse: "basisch", ph: "7,5 – 8,3",
    muster: [/schreibkreide/, /kreidekalk/, /pläner/],
    info: "Sehr reiner, weicher Kalk (Rügen, Teutoburger Wald, Münsterland)." },
  { name: "Mergel / Mergelstein", gruppe: "Sedimentgestein", klasse: "neutral", ph: "6,8 – 8,0",
    muster: [/mergel/],
    info: "Gemisch aus Ton und Kalk (z. B. Keuper, Jura, Tertiär). Schwere, basenreiche Böden." },
  { name: "Kalkstein", gruppe: "Sedimentgestein", klasse: "basisch", ph: "7,0 – 8,3",
    muster: [/kalkstein/, /muschelkalk/, /riffkalk/, /plattenkalk/, /massenkalk/, /oolith/, /karbonat/, /\bkalk\b/, /\bkalke\b/, /kalkig/],
    info: "Muschelkalk, Jurakalk, Devon-Massenkalk. Rendzina und Terra fusca, typische Kalkbuchenwälder." },
  { name: "Gips / Anhydrit", gruppe: "Sedimentgestein", klasse: "neutral", ph: "7,0 – 7,8",
    muster: [/gips/, /anhydrit/],
    info: "Sulfatgestein (Südharz, Keuper). Neutrale Böden, oft Karst." },
  { name: "Marsch / Klei", gruppe: "Küsten- und Flussablagerung", klasse: "neutral", ph: "6,5 – 7,8",
    muster: [/marsch/, /\bklei\b/, /\bwatt/, /schlick/],
    info: "Junge Meeres- und Flussablagerungen, anfangs kalkhaltig." },
  { name: "Auelehm / Auensediment", gruppe: "Flussablagerung", klasse: "neutral", ph: "5,5 – 7,5",
    muster: [/auelehm/, /auenlehm/, /\baue/, /hochflut/, /fluviatil/],
    info: "Nährstoffreiche Ablagerungen in Flusstälern. Auwälder – z. B. Morcheln im Frühjahr." },
  { name: "Basalt", gruppe: "Vulkanit", klasse: "neutral", ph: "5,5 – 7,0",
    muster: [/basalt/, /basanit/, /nephelinit/, /phonolith/, /trachyt/, /\btephrit/, /\btuff\b/, /vulkanit/],
    info: "Basenreiches Vulkangestein (Vogelsberg, Rhön, Eifel, Westerwald). Nährstoffreiche Braunerden." },
  { name: "Diabas / Spilit", gruppe: "Vulkanit (alt)", klasse: "schwach sauer", ph: "5,0 – 6,5",
    muster: [/diabas/, /spilit/, /\bgabbro/, /amphibolit/, /\bmetabasit/, /grünstein/, /\bdiorit/],
    info: "Basisch zusammengesetzte Gesteine (Lahn-Dill, Harz, Fichtelgebirge). Deutlich basenreicher als Granit." },
  { name: "Ton- / Schluffstein", gruppe: "Sedimentgestein", klasse: "schwach sauer", ph: "5,0 – 7,0",
    muster: [/tonstein/, /schluffstein/, /siltstein/, /\bton\b/, /tonig/, /letten/, /schieferton/],
    info: "Je nach Kalkgehalt schwach sauer bis neutral. Schwere, oft staunasse Böden (Pseudogley)." },
  { name: "Niedermoortorf", gruppe: "Organische Ablagerung", klasse: "schwach sauer", ph: "5,0 – 7,0",
    muster: [/niedermoor/, /anmoor/, /\bmudde/, /bruchtorf/, /schilftorf/, /seggentorf/, /erlenbruch/],
    info: "Grundwassergespeistes Moor, basenreicher als Hochmoor." },
  { name: "Hochmoortorf", gruppe: "Organische Ablagerung", klasse: "stark sauer", ph: "3,0 – 4,0",
    muster: [/hochmoor/, /sphagnum/, /torfmoos/, /weißtorf/, /\btorf/, /\bmoor/],
    info: "Regenwassergespeistes Moor, extrem nährstoffarm und sauer." },
  { name: "Grauwacke", gruppe: "Sedimentgestein", klasse: "sauer", ph: "4,0 – 5,5",
    muster: [/grauwacke/],
    info: "Harte Sandsteinart (Harz, Rheinisches Schiefergebirge). Mäßig basenarm." },
  { name: "Tonschiefer", gruppe: "Metamorphit (schwach)", klasse: "sauer", ph: "3,8 – 5,0",
    muster: [/tonschiefer/, /\bschiefer/, /dachschiefer/, /\bslate/],
    info: "Rheinisches Schiefergebirge, Thüringer Wald. Basenarme, saure Braunerden." },
  { name: "Phyllit / Glimmerschiefer", gruppe: "Metamorphit", klasse: "sauer", ph: "3,8 – 5,0",
    muster: [/phyllit/, /glimmerschiefer/, /quarzitschiefer/],
    info: "Erzgebirge, Fichtelgebirge, Schwarzwald-Rand. Saure Böden." },
  { name: "Gneis", gruppe: "Metamorphit", klasse: "sauer", ph: "3,8 – 5,0",
    muster: [/gneis/, /migmatit/, /granulit/],
    info: "Schwarzwald, Bayerischer Wald, Erzgebirge. Saure Braunerden, Fichten- und Buchenwälder." },
  { name: "Granit", gruppe: "Plutonit", klasse: "stark sauer", ph: "3,5 – 5,0",
    muster: [/granit/, /granodiorit/, /pegmatit/, /plutonit/],
    info: "Harz, Fichtelgebirge, Bayerischer Wald, Schwarzwald. Sandig-grusige, saure Böden." },
  { name: "Rhyolith / Quarzporphyr", gruppe: "Vulkanit (sauer)", klasse: "sauer", ph: "3,8 – 5,0",
    muster: [/rhyolith/, /porphyr/, /ignimbrit/, /keratophyr/],
    info: "Kieselsäurereiche Vulkanite (Thüringer Wald, Odenwald, Saar-Nahe). Saure Böden." },
  { name: "Quarzit", gruppe: "Metamorphit", klasse: "stark sauer", ph: "3,3 – 4,5",
    muster: [/quarzit/, /\bquarz/, /kieselschiefer/, /lydit/, /hornstein/],
    info: "Fast reiner Quarz (Taunus, Hunsrück). Sehr nährstoffarm." },
  { name: "Sandstein (z. B. Buntsandstein)", gruppe: "Sedimentgestein", klasse: "stark sauer", ph: "3,3 – 4,5",
    muster: [/buntsandstein/, /sandstein/, /arkose/, /konglomerat/],
    info: "Pfälzerwald, Spessart, Odenwald, Solling. Podsolige, sehr saure Böden – klassisches Pfifferling- und Heidelbeergebiet." },
  { name: "Schotter / Kies", gruppe: "Fluss- und Schmelzwasserablagerung", klasse: "sauer", ph: "4,0 – 7,5",
    muster: [/schotter/, /\bkies/, /geröll/],
    info: "Stark herkunftsabhängig: Alpine Schotter (Alpenvorland) sind kalkhaltig und basisch, Mittelgebirgs- und nordische Kiese eher sauer." },
  { name: "Sand (Flug-, Tal-, Schmelzwassersand)", gruppe: "Lockersediment", klasse: "stark sauer", ph: "3,5 – 5,0",
    muster: [/flugsand/, /dünensand/, /\bdüne/, /talsand/, /schmelzwasser/, /sander/, /\bsand\b/, /\bsande\b/, /sandig/],
    info: "Norddeutsches Tiefland, Lausitz, Brandenburg. Kiefernwälder auf armen, sauren Böden." },
  { name: "Lehm / Schluff (allgemein)", gruppe: "Lockersediment", klasse: "schwach sauer", ph: "4,5 – 6,5",
    muster: [/\blehm/, /\bschluff/, /\bsilt\b/, /fließerde/, /solifluktion/, /hangschutt/, /deckschicht/],
    info: "Verwitterungs- und Umlagerungsdecken. pH hängt stark vom Ausgangsgestein darunter ab." }
];

/** Ordnet einen Beschreibungstext der BGR-Karte bis zu 3 Gesteinen zu. */
window.gesteineAusText = function (text) {
  if (!text) return [];
  var t = String(text).toLowerCase();
  var treffer = [];
  for (var i = 0; i < GESTEINE.length && treffer.length < 3; i++) {
    var g = GESTEINE[i];
    var hit = false;
    for (var j = 0; j < g.muster.length; j++) {
      var re = new RegExp(g.muster[j].source, "g");
      if (re.test(t)) {
        hit = true;
        // gefundenes Wort entfernen, damit allgemeinere Muster es nicht erneut zählen
        t = t.replace(new RegExp(g.muster[j].source, "g"), " ");
      }
    }
    if (hit) treffer.push(g);
  }
  // "kalkfrei"/"entkalkt" macht einen reinen Kalk-Treffer unzuverlässig
  if (/kalkfrei|entkalkt/.test(t)) {
    treffer = treffer.filter(function (g) { return g.name !== "Kalkstein"; });
  }
  return treffer;
};

/** pH-Zahl -> Klasse */
window.phKlasse = function (ph) {
  if (ph < 4.5) return "stark sauer";
  if (ph < 5.5) return "sauer";
  if (ph < 6.5) return "schwach sauer";
  if (ph <= 7.3) return "neutral";
  return "basisch";
};

/** Pilz-Tendenz je Bodenreaktion (nur als grobe Orientierung) */
window.PILZ_TENDENZ = {
  "stark sauer": "Saure, arme Böden (oft Kiefer/Fichte, Heidelbeere): typisch für Pfifferling, Maronen-Röhrling, Fichten-Steinpilz, Krause Glucke (an Kiefer), Birkenpilz (bei Birke).",
  "sauer": "Saure Böden: gute Chancen auf Pfifferling, Steinpilz, Maronen-Röhrling, Perlpilz; bei Birke Birkenpilz und Rotkappen.",
  "schwach sauer": "Mäßig saure, meist nährstoffreichere Böden: breites Artenspektrum – Steinpilze, Perlpilz, Semmel-Stoppelpilz, Rotkappen (bei Espe/Birke), Täublinge.",
  "neutral": "Basenreiche Böden (oft Buche/Eiche): Sommer-Steinpilz, Herbsttrompete, Semmel-Stoppelpilz; im Frühjahr Maipilz und Morcheln.",
  "basisch": "Kalkböden: kalkliebende Arten wie Herbsttrompete, Maipilz und Speisemorchel (Frühjahr). Vorsicht: hier wachsen auch Satans-Röhrling und viele giftige Risspilze."
};
