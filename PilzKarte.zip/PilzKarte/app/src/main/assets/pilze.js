/*
 * Häufig gesammelte Speisepilze mit grober Saison (Monate), bevorzugter
 * Bodenreaktion, Baumpartnern und den wichtigsten Verwechslungen.
 * Werte sind Richtwerte aus der Pilzliteratur; Wetter und Höhenlage verschieben
 * die Saison um Wochen. Diese Hinweise ersetzen KEINE Pilzberatung.
 *
 * boden: Klassen aus PH_KLASSEN; baum: Baumarten der Thünen-Karte (null = egal)
 * gefahr: "toedlich" = lebensgefährlicher Doppelgänger, "giftig", "gering"
 * cs: reichert laut BfS besonders viel radioaktives Cäsium an (v. a. Süddeutschland)
 */
window.PILZARTEN = [
  { de: "Fichten-Steinpilz", sci: "Boletus edulis", von: 7, bis: 11,
    boden: ["stark sauer", "sauer", "schwach sauer"], baum: ["Fichte", "Buche", "Kiefer", "Tanne", "Eiche", "Birke", "Douglasie"],
    gefahr: "giftig",
    vorsicht: "Gallenröhrling (ungiftig, aber extrem bitter: dunkles Netz am Stiel, Röhren später rosa). Satans-Röhrling (giftig: blutrote Poren, weißlich-grauer Hut, blaut stark)." },
  { de: "Sommer-Steinpilz", sci: "Boletus reticulatus", von: 5, bis: 9,
    boden: ["schwach sauer", "neutral", "basisch"], baum: ["Eiche", "Buche"],
    gefahr: "giftig",
    vorsicht: "Wie Fichten-Steinpilz: Gallenröhrling (bitter) und Satans-Röhrling (giftig, rote Poren) – gerade auf warmen Kalkböden unter Eiche/Buche." },
  { de: "Kiefern-Steinpilz", sci: "Boletus pinophilus", von: 6, bis: 10,
    boden: ["stark sauer", "sauer"], baum: ["Kiefer", "Fichte"],
    gefahr: "giftig",
    vorsicht: "Gallenröhrling (bitter). Echte Steinpilze haben ein helles Netz und weiße bis olivgelbe Röhren." },
  { de: "Pfifferling", sci: "Cantharellus cibarius", von: 6, bis: 10,
    boden: ["stark sauer", "sauer", "schwach sauer"], baum: ["Fichte", "Kiefer", "Buche", "Eiche", "Birke", "Tanne"],
    gefahr: "giftig",
    vorsicht: "Falscher Pfifferling (weiche, echte Lamellen, orange). Ölbaumtrichterling (giftig: büschelig an Holz/Wurzeln, echte Lamellen). Echter Pfifferling: gegabelte Leisten, festes weißliches Fleisch." },
  { de: "Trompetenpfifferling", sci: "Craterellus tubaeformis", von: 9, bis: 12,
    boden: ["stark sauer", "sauer"], baum: ["Fichte", "Kiefer", "Tanne"],
    gefahr: "gering", cs: true,
    vorsicht: "Kaum gefährliche Doppelgänger: hohler, gelber Stiel, graue Leisten, oft in Moospolstern." },
  { de: "Maronen-Röhrling", sci: "Imleria badia", von: 8, bis: 11,
    boden: ["stark sauer", "sauer"], baum: ["Fichte", "Kiefer", "Douglasie", "Lärche", "Tanne", "Buche"],
    gefahr: "giftig", cs: true,
    vorsicht: "Gallenröhrling (bitter). Maronen: gelbe Poren, blauen auf Druck. Rot-porige Röhrlinge meiden." },
  { de: "Krause Glucke", sci: "Sparassis crispa", von: 8, bis: 11,
    boden: ["stark sauer", "sauer"], baum: ["Kiefer", "Douglasie", "Fichte"],
    gefahr: "gering",
    vorsicht: "Korallen (z. B. Bauchweh-Koralle, abführend) – diese sind aufrecht verzweigt, nicht blättrig-kraus. Wächst am Stammfuß von Kiefern." },
  { de: "Herbsttrompete", sci: "Craterellus cornucopioides", von: 8, bis: 11,
    boden: ["schwach sauer", "neutral", "basisch"], baum: ["Buche", "Eiche"],
    gefahr: "gering",
    vorsicht: "Kaum Doppelgänger: schwarzgrauer, hohler Trichter mit glatter Außenseite." },
  { de: "Semmel-Stoppelpilz", sci: "Hydnum repandum", von: 8, bis: 11,
    boden: ["sauer", "schwach sauer", "neutral", "basisch"], baum: ["Buche", "Fichte", "Eiche", "Kiefer", "Tanne"],
    gefahr: "gering", cs: true,
    vorsicht: "Kaum Doppelgänger (Stacheln statt Lamellen). Laut BfS am stärksten mit Cäsium belastet." },
  { de: "Birkenpilz", sci: "Leccinum scabrum", von: 6, bis: 10,
    boden: ["stark sauer", "sauer", "schwach sauer", "neutral"], baum: ["Birke"],
    gefahr: "gering",
    vorsicht: "Gallenröhrling (bitter). Birkenpilz: Stiel mit dunklen Schüppchen, nur bei Birken." },
  { de: "Perlpilz", sci: "Amanita rubescens", von: 6, bis: 10,
    boden: ["stark sauer", "sauer", "schwach sauer", "neutral"], baum: null,
    gefahr: "toedlich",
    vorsicht: "LEBENSGEFAHR: Pantherpilz (stark giftig: ungeriefter Ring, Knolle mit Rand, Fleisch rötet nicht). Perlpilz rötet an Fraßstellen, Ring gerieft. Nur für Erfahrene!" },
  { de: "Parasol", sci: "Macrolepiota procera", von: 7, bis: 10,
    boden: ["sauer", "schwach sauer", "neutral", "basisch"], baum: null,
    gefahr: "toedlich",
    vorsicht: "Kleine Schirmlinge sind teils tödlich giftig – nur große Exemplare (Hut ab ca. 10 cm) mit genattertem Stiel und verschiebbarem, doppeltem Ring sammeln." },
  { de: "Goldröhrling", sci: "Suillus grevillei", von: 7, bis: 10,
    boden: ["schwach sauer", "neutral", "basisch"], baum: ["Lärche"],
    gefahr: "gering",
    vorsicht: "Kaum gefährliche Doppelgänger; wächst nur unter Lärchen." },
  { de: "Butterpilz", sci: "Suillus luteus", von: 7, bis: 11,
    boden: ["stark sauer", "sauer", "schwach sauer"], baum: ["Kiefer"],
    gefahr: "gering",
    vorsicht: "Kaum gefährliche Doppelgänger; schleimige Huthaut vor dem Kochen abziehen." },
  { de: "Edelreizker", sci: "Lactarius deliciosus", von: 8, bis: 10,
    boden: ["neutral", "basisch"], baum: ["Kiefer"],
    gefahr: "giftig",
    vorsicht: "Birkenreizker (giftig: weiße, scharfe Milch, zottiger Hutrand, bei Birken). Edelreizker hat karottenrote Milch." },
  { de: "Maipilz", sci: "Calocybe gambosa", von: 4, bis: 6,
    boden: ["neutral", "basisch"], baum: null,
    gefahr: "toedlich",
    vorsicht: "LEBENSGEFAHR: Ziegelroter Risspilz (tödlich giftig, gleiche Zeit und Orte, rötet, faserig-rissiger Hut). Maipilz riecht stark nach frischem Mehl." },
  { de: "Speisemorchel", sci: "Morchella esculenta", von: 3, bis: 5,
    boden: ["neutral", "basisch"], baum: null,
    gefahr: "toedlich",
    vorsicht: "LEBENSGEFAHR: Frühjahrs-Giftlorchel (hirnartig gewundener Hut, gekammerter Stiel). Echte Morchel: wabenartiger Hut, innen durchgehend hohl." }
];

/** Monate als Kurztext */
window.MONATE = ["Jan", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];

/** Giftnotruf-Zentralen nach Bundesland (Quelle: BVL-Liste der Giftnotrufzentralen) */
window.GIFTNOTRUF = [
  { ort: "Berlin", laender: "Berlin, Brandenburg", tel: "030 19240" },
  { ort: "Bonn", laender: "Nordrhein-Westfalen", tel: "0228 19240" },
  { ort: "Erfurt", laender: "Mecklenburg-Vorpommern, Sachsen, Sachsen-Anhalt, Thüringen", tel: "0361 730730" },
  { ort: "Freiburg", laender: "Baden-Württemberg", tel: "0761 19240" },
  { ort: "Göttingen", laender: "Bremen, Hamburg, Niedersachsen, Schleswig-Holstein", tel: "0551 19240" },
  { ort: "Mainz", laender: "Rheinland-Pfalz, Hessen, Saarland", tel: "06131 19240" },
  { ort: "München", laender: "Bayern", tel: "089 19240" }
];
