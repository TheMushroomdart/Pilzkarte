package de.pilzkarte.app

/**
 * Bekannte Werbe-, Tracking- und Analysedienste, die auf externen Seiten
 * (Kachelmannwetter, Waldmonitor, topographic-map …) blockiert werden.
 * Gilt auch für alle Unter-Domains. Einwilligungs-Dialoge (Cookie-Banner) bleiben erlaubt,
 * damit die Seiten funktionieren.
 */
object Tracker {

    private val DOMAINS = setOf(
        // Google Werbung & Statistik
        "google-analytics.com", "analytics.google.com", "googletagmanager.com", "googletagservices.com",
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "adservice.google.de", "pagead2.googlesyndication.com", "imasdk.googleapis.com",
        // Meta, Microsoft, X, TikTok, LinkedIn, Pinterest
        "connect.facebook.net", "facebook.net", "pixel.facebook.com", "an.facebook.com",
        "clarity.ms", "bat.bing.com", "ads.linkedin.com", "px.ads.linkedin.com", "snap.licdn.com",
        "analytics.twitter.com", "static.ads-twitter.com", "ads-api.twitter.com", "analytics.tiktok.com",
        "ct.pinterest.com",
        // Werbenetzwerke
        "adnxs.com", "adsrvr.org", "amazon-adsystem.com", "criteo.com", "criteo.net", "taboola.com", "outbrain.com",
        "rubiconproject.com", "pubmatic.com", "openx.net", "casalemedia.com", "smartadserver.com", "adform.net",
        "yieldlab.net", "yieldlove.com", "yieldlove-ad-serving.net", "adition.com", "theadex.com", "emetriq.de",
        "nuggad.net", "meetrics.net", "adalliance.io", "stroeerdigitalgroup.de", "stroeerdigitalmedia.de",
        "ad.71i.de", "adscale.de", "uimserv.net", "adup-tech.com", "plista.com", "seedtag.com", "teads.tv",
        "3lift.com", "triplelift.com", "sharethrough.com", "bidswitch.net", "media.net", "moatads.com",
        "doubleverify.com", "adsafeprotected.com", "id5-sync.com", "liveintent.com", "rlcdn.com", "bluekai.com",
        "demdex.net", "everesttech.net", "quantserve.com", "quantcount.com", "scorecardresearch.com",
        "zemanta.com", "permutive.com", "permutive.app", "onetag-sys.com", "adnxs-simple.com", "lijit.com",
        "sovrn.com", "smaato.net", "inmobi.com", "applovin.com", "unityads.unity3d.com", "ampproject.net",
        // Reichweitenmessung & Nutzungsanalyse
        "ioam.de", "iocnt.net", "xiti.com", "chartbeat.com", "chartbeat.net", "hotjar.com", "hotjar.io",
        "mouseflow.com", "crazyegg.com", "fullstory.com", "mixpanel.com", "amplitude.com", "segment.com",
        "segment.io", "heap.io", "heapanalytics.com", "newrelic.com", "nr-data.net", "cloudflareinsights.com",
        "statcounter.com", "webtrekk.net", "wt-safetag.com", "mapp.com", "etracker.com", "econda-monitor.de",
        "kameleoon.eu", "optimizely.com", "branch.io", "adjust.com", "appsflyer.com", "onesignal.com",
        "pushwoosh.com", "sentry-cdn.com", "browser.sentry-cdn.com", "matomo.cloud", "piwik.pro"
    )

    /** true, wenn der Host oder eine übergeordnete Domain auf der Liste steht. */
    fun blockiert(host: String?): Boolean {
        if (host.isNullOrEmpty()) return false
        var h = host.lowercase().trimEnd('.')
        while (true) {
            if (h in DOMAINS) return true
            val punkt = h.indexOf('.')
            if (punkt < 0 || h.indexOf('.', punkt + 1) < 0) return false
            h = h.substring(punkt + 1)
        }
    }
}
