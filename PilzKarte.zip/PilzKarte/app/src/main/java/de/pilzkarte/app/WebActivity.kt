package de.pilzkarte.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayInputStream
import java.util.concurrent.atomic.AtomicInteger

/**
 * Zeigt externe Seiten (Waldmonitor, Kachelmannwetter, topographic-map.com …) innerhalb der App.
 * Datenschutz: bekannte Tracker und Werbedienste werden blockiert (Zähler oben rechts),
 * kein Standortzugriff, keine Cookies von Dritten, neutraler User-Agent;
 * beim Schließen werden Cookies und Web-Speicher dieser Seiten gelöscht.
 */
class WebActivity : Activity() {

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_TITLE = "title"
    }

    private lateinit var web: WebView
    private lateinit var zaehler: TextView
    private val blockiert = AtomicInteger(0)
    private var webOk = false

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra(EXTRA_URL) ?: run { finish(); return }
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty().ifEmpty { Uri.parse(url).host ?: "" }

        if (getSharedPreferences(MainActivity.EINSTELLUNGEN, Context.MODE_PRIVATE).getBoolean("schutz", false)) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#2F6B3A"))
            setPadding(dp(4), dp(4), dp(8), dp(4))
        }
        val back = Button(this).apply {
            text = "✕"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            contentDescription = "Schließen"
            setOnClickListener { finish() }
        }
        val titleView = TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
        }
        zaehler = TextView(this).apply {
            text = "🛡 0"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(8), 0, dp(4), 0)
            contentDescription = "Blockierte Tracker"
            setOnClickListener {
                Toast.makeText(this@WebActivity,
                    "${blockiert.get()} Anfragen an Werbe- und Tracking-Dienste blockiert.", Toast.LENGTH_SHORT).show()
            }
        }
        val browser = Button(this).apply {
            text = "↗"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.TRANSPARENT)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            contentDescription = "Im Browser öffnen"
            setOnClickListener {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(web.url ?: url)))
                } catch (_: ActivityNotFoundException) { }
            }
        }
        bar.addView(back, LinearLayout.LayoutParams(dp(48), dp(48)))
        bar.addView(titleView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(zaehler, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        bar.addView(browser, LinearLayout.LayoutParams(dp(48), dp(48)))

        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            isIndeterminate = false
        }

        web = WebView(this)
        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.setSupportZoom(true)
        s.setGeolocationEnabled(false)
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.userAgentString = s.userAgentString.replace(Regex("\\(Linux; Android [^)]*\\)"), "(Linux; Android 10; K; wv)")
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                if (!Tracker.blockiert(request.url.host)) return null
                val n = blockiert.incrementAndGet()
                runOnUiThread { zaehler.text = "🛡 $n" }
                return WebResourceResponse("text/plain", "utf-8", 204, "No Content", emptyMap(), ByteArrayInputStream(ByteArray(0)))
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val scheme = request.url.scheme?.lowercase()
                if (scheme == "http" || scheme == "https") return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                } catch (_: ActivityNotFoundException) { }
                return true
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                // Alle WebViews der App teilen sich die Darstellung: abgestürzt → diese Seite schließen, App läuft weiter
                if (webOk) {
                    webOk = false
                    (web.parent as? ViewGroup)?.removeView(web)
                    web.destroy()
                }
                finish()
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }

            override fun onReceivedTitle(view: WebView, t: String?) {
                if (!t.isNullOrBlank() && title.isEmpty()) titleView.text = t
            }
        }

        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(progress, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)))
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        webOk = true

        if (savedInstanceState != null) web.restoreState(savedInstanceState) else web.loadUrl(url)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        if (webOk) web.saveState(outState)
    }

    @Deprecated("Einfache Zurück-Behandlung für alle Android-Versionen")
    override fun onBackPressed() {
        if (webOk && web.canGoBack()) {
            web.goBack()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }

    override fun onStart() {
        super.onStart()
        AppZustand.gestartet(MainActivity.SPERRE_NACH_MS)
    }

    override fun onStop() {
        AppZustand.gestoppt()
        super.onStop()
    }

    override fun onPause() {
        // Im Hintergrund laufen auch auf externen Seiten keine Skripte weiter
        if (webOk) {
            web.onPause()
            web.pauseTimers()
        }
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (webOk) {
            web.resumeTimers()
            web.onResume()
        }
    }

    override fun onDestroy() {
        // Spuren der externen Seiten entfernen (App-eigene Daten liegen separat und bleiben erhalten)
        if (webOk) {
            webOk = false
            web.clearHistory()
            web.clearFormData()
            web.clearCache(true)
            (web.parent as? ViewGroup)?.removeView(web)
            web.destroy()
        }
        CookieManager.getInstance().removeAllCookies(null)
        CookieManager.getInstance().flush()
        WebStorage.getInstance().deleteAllData()
        super.onDestroy()
    }
}
