package de.pilzkarte.app

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Gemeinsame Netz-Hilfen: Weiterleitungen nur zu freigegebenen Servern. */
object Netz {

    /**
     * Öffnet eine HTTPS-Verbindung und folgt höchstens drei Weiterleitungen – aber nur zu Servern,
     * die [erlaubt] zulässt. So kann ein freigegebener Server Anfragen nicht an fremde Server umleiten.
     * [einrichten] setzt Zeitlimits und Kopfzeilen; danach ist die Antwort (responseCode) abrufbar.
     */
    fun oeffnen(url: String, erlaubt: (String?) -> Boolean, einrichten: (HttpURLConnection) -> Unit): HttpURLConnection {
        var ziel = URL(url)
        repeat(4) {
            if (ziel.protocol != "https" || !erlaubt(ziel.host?.lowercase())) throw IOException("Server nicht freigegeben")
            val conn = ziel.openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = false
            einrichten(conn)
            val code = conn.responseCode
            if (code !in 300..399) return conn
            val ort = conn.getHeaderField("Location")
            conn.disconnect()
            if (ort.isNullOrEmpty()) throw IOException("Weiterleitung ohne Ziel")
            ziel = URL(ziel, ort)
        }
        throw IOException("Zu viele Weiterleitungen")
    }
}
