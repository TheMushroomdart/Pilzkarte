package de.pilzkarte.app

import android.content.Context
import android.net.Uri
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Speichert Kartenbilder auf dem Gerät – für Funklöcher und weniger Abrufe.
 *
 * Regeln je Anbieter (nach deren Nutzungsbedingungen):
 *  - TopPlusOpen (BKG): Speichern und Vorab-Laden erlaubt, 30 Tage frisch
 *  - OpenStreetMap / OpenTopoMap: nur angesehene Kacheln, 7 Tage frisch, kein Vorab-Laden
 *  - Fachkarten der Behörden (Thünen, BGR, DLR, BfN) und Luftbilder der Länder: 30 Tage frisch
 *  - Nie gespeichert: Live-Daten (DWD-Niederschlag/Radar) und Esri-Satellitenbilder
 * Veraltete Bilder werden nur noch gezeigt, wenn das Netz fehlt. Nach 60 Tagen wird alles gelöscht,
 * höchstens 500 MB werden belegt. Der Ordner liegt im App-Bereich ohne Backup.
 */
class Kachelspeicher(context: Context, private val userAgent: String) {

    companion object {
        private const val TAG_MS = 24L * 60 * 60 * 1000
        const val HOECHSTALTER_MS = 60 * TAG_MS
        const val MAX_BYTES = 500L * 1024 * 1024
        private const val ZIEL_BYTES = 420L * 1024 * 1024
        private const val MAX_DATEI = 8 * 1024 * 1024
        const val MAX_VORAB = 6000
        private const val TOPPLUS_PREFIX =
            "https://sgx.geodatenzentrum.de/wmts_topplus_open/tile/1.0.0/web/default/WEBMERCATOR/"
        private val TOPPLUS_MUSTER = Regex("^\\d{1,2}/\\d{1,7}/\\d{1,7}\\.png$")

        private val OSM_HOSTS = setOf(
            "tile.openstreetmap.org", "a.tile.opentopomap.org", "b.tile.opentopomap.org", "c.tile.opentopomap.org"
        )
        private val AMT_HOSTS = setOf(
            "sgx.geodatenzentrum.de", "atlas.thuenen.de", "services.bgr.de", "geoservice.dlr.de", "geodienste.bfn.de",
            // Luftbilder der Länder (dl-de/by-2-0)
            "owsproxy.lgl-bw.de", "geoservices.bayern.de", "gdi.berlin.de", "isk.geobasis-bb.de", "geodienste.bremen.de",
            "geodienste.hamburg.de", "www.gds-srv.hessen.de", "www.geodaten-mv.de", "opendata.lgln.niedersachsen.de",
            "www.wms.nrw.de", "www.geoportal.rlp.de", "geoportal.saarland.de", "geodienste.sachsen.de",
            "www.geodatenportal.sachsen-anhalt.de", "dienste.gdi-sh.de", "www.geoproxy.geoportal-th.de"
        )
    }

    private val ordner = File(context.noBackupFilesDir, "kacheln").apply { mkdirs() }
    private val schreibZaehler = AtomicInteger(0)
    private val aufraeumer: ExecutorService = Executors.newSingleThreadExecutor()

    /** Wie lange ein Bild dieses Servers als frisch gilt; null = nicht speichern. */
    fun frischDauer(host: String?): Long? = when {
        host == null -> null
        host in OSM_HOSTS -> 7 * TAG_MS
        host in AMT_HOSTS -> 30 * TAG_MS
        else -> null
    }

    private fun datei(url: String): File {
        val h = MessageDigest.getInstance("SHA-256").digest(url.toByteArray(Charsets.UTF_8))
        val name = h.joinToString("") { "%02x".format(it) }
        return File(ordner, name.substring(0, 2) + "/" + name)
    }

    private class Ergebnis(val status: Int, val typ: String, val daten: ByteArray)

    private fun laden(url: String): Ergebnis? {
        var conn: HttpURLConnection? = null
        return try {
            // Weiterleitungen nur zu Kartenservern, die ohnehin gespeichert werden dürfen
            conn = Netz.oeffnen(url, { frischDauer(it) != null }) { c ->
                c.connectTimeout = 15000
                c.readTimeout = 25000
                c.useCaches = false
                c.setRequestProperty("User-Agent", userAgent)
                c.setRequestProperty("Accept", "image/png,image/jpeg,image/*;q=0.8,*/*;q=0.5")
            }
            val status = conn.responseCode
            val typ = (conn.contentType ?: "").substringBefore(';').trim().lowercase()
            val stream = if (status in 200..299) conn.inputStream else conn.errorStream
            val puffer = ByteArrayOutputStream()
            stream?.use { s ->
                val b = ByteArray(16 * 1024)
                while (true) {
                    val n = s.read(b)
                    if (n < 0) break
                    puffer.write(b, 0, n)
                    if (puffer.size() > MAX_DATEI) throw java.io.IOException("Datei zu groß")
                }
            }
            Ergebnis(status, typ, puffer.toByteArray())
        } catch (e: Exception) {
            null
        } finally {
            conn?.disconnect()
        }
    }

    private fun speichern(ziel: File, daten: ByteArray) {
        try {
            ziel.parentFile?.mkdirs()
            // eigener Name je Thread, falls dasselbe Bild gleichzeitig zweimal geladen wird
            val tmp = File(ziel.parentFile, ziel.name + "." + Thread.currentThread().id + ".tmp")
            tmp.writeBytes(daten)
            if (!tmp.renameTo(ziel)) {
                ziel.delete()
                tmp.renameTo(ziel)
            }
            if (schreibZaehler.incrementAndGet() % 300 == 0) aufraeumenSpaeter()
        } catch (_: Exception) {
        }
    }

    private fun bildTyp(kopf: ByteArray): String = when {
        kopf.size >= 4 && kopf[0] == 0x89.toByte() && kopf[1] == 'P'.code.toByte() -> "image/png"
        kopf.size >= 2 && kopf[0] == 0xFF.toByte() && kopf[1] == 0xD8.toByte() -> "image/jpeg"
        kopf.size >= 4 && kopf[0] == 'G'.code.toByte() && kopf[1] == 'I'.code.toByte() -> "image/gif"
        kopf.size >= 12 && kopf[8] == 'W'.code.toByte() && kopf[9] == 'E'.code.toByte() -> "image/webp"
        else -> "image/png"
    }

    private fun kopfzeilen(): Map<String, String> = mapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "no-cache")

    private fun ausDatei(f: File): WebResourceResponse? = try {
        val kopf = ByteArray(12)
        val n = FileInputStream(f).use { it.read(kopf) }
        WebResourceResponse(bildTyp(if (n > 0) kopf.copyOf(n) else ByteArray(0)), null, 200, "OK", kopfzeilen(), FileInputStream(f))
    } catch (_: Exception) {
        null
    }

    private fun antwort(status: Int, grund: String, typ: String, daten: ByteArray): WebResourceResponse {
        // WebView akzeptiert nur Statuscodes 100–599 ohne Weiterleitungen (3xx)
        val s = if (status < 100 || status > 599 || status in 300..399) 502 else status
        return WebResourceResponse(typ.ifEmpty { "application/octet-stream" }, null, s, grund, kopfzeilen(), ByteArrayInputStream(daten))
    }

    /** Antwort für ein Kartenbild aus dem Speicher oder dem Netz; null = nicht zuständig. */
    fun abfangen(url: String): WebResourceResponse? {
        val host = Uri.parse(url).host?.lowercase()
        val frisch = frischDauer(host) ?: return null
        val f = datei(url)
        if (f.exists() && System.currentTimeMillis() - f.lastModified() < frisch) {
            ausDatei(f)?.let { return it }
        }
        val e = laden(url)
        if (e != null && e.status == 200 && e.typ.startsWith("image/") && e.daten.isNotEmpty()) {
            speichern(f, e.daten)
            return antwort(200, "OK", e.typ, e.daten)
        }
        // Kein Netz oder Serverfehler: lieber das ältere Bild zeigen
        if (f.exists()) ausDatei(f)?.let { return it }
        if (e != null) return antwort(e.status, "Server", e.typ, e.daten)
        return antwort(504, "Offline", "text/plain", ByteArray(0))
    }

    // ---------------- Vorab-Laden (nur TopPlusOpen) ----------------
    private val laeuft = AtomicBoolean(false)
    private val abbrechen = AtomicBoolean(false)

    fun ladenLaeuft(): Boolean = laeuft.get()

    /** Prüft, dass nur Kacheln der amtlichen Karte TopPlusOpen vorab geladen werden. */
    fun erlaubteUrls(urls: List<String>): List<String> = urls.filter {
        it.startsWith(TOPPLUS_PREFIX) && TOPPLUS_MUSTER.matches(it.substring(TOPPLUS_PREFIX.length))
    }.distinct().take(MAX_VORAB)

    /**
     * Lädt die Kacheln mit zwei parallelen Verbindungen (schont den Server).
     * [warten] blockiert, solange die App im Hintergrund ist; false = abbrechen.
     * [fortschritt] erhält (fertig, gesamt, fehler, beendet, abgebrochen).
     */
    fun vorabLaden(
        urls: List<String>,
        warten: () -> Boolean,
        fortschritt: (Int, Int, Int, Boolean, Boolean) -> Unit
    ): Boolean {
        if (!laeuft.compareAndSet(false, true)) return false
        abbrechen.set(false)
        Thread {
            val gesamt = urls.size
            val fertig = AtomicInteger(0)
            val fehler = AtomicInteger(0)
            var zuletzt = 0L
            val pool = Executors.newFixedThreadPool(2)
            try {
                for (u in urls) {
                    pool.execute {
                        try {
                            if (abbrechen.get() || !warten()) {
                                abbrechen.set(true)
                                return@execute
                            }
                            val f = datei(u)
                            if (!(f.exists() && System.currentTimeMillis() - f.lastModified() < 30 * TAG_MS)) {
                                val e = laden(u)
                                if (e != null && e.status == 200 && e.typ.startsWith("image/") && e.daten.isNotEmpty()) speichern(f, e.daten)
                                else fehler.incrementAndGet()
                            }
                            val n = fertig.incrementAndGet()
                            val jetzt = System.currentTimeMillis()
                            if (jetzt - zuletzt > 400) {
                                zuletzt = jetzt
                                fortschritt(n, gesamt, fehler.get(), false, false)
                            }
                        } catch (_: Throwable) {
                            fehler.incrementAndGet()
                        }
                    }
                }
                pool.shutdown()
                pool.awaitTermination(6, TimeUnit.HOURS)
            } catch (_: Throwable) {
                abbrechen.set(true)
                pool.shutdownNow()
            } finally {
                laeuft.set(false)
                fortschritt(fertig.get(), gesamt, fehler.get(), true, abbrechen.get())
                aufraeumenSpaeter()
            }
        }.start()
        return true
    }

    fun abbrechen() = abbrechen.set(true)

    // ---------------- Verwaltung ----------------
    private fun alleDateien(): List<File> = ordner.listFiles()?.flatMap { d ->
        if (d.isDirectory) d.listFiles()?.toList() ?: emptyList() else listOf(d)
    } ?: emptyList()

    fun info(): String {
        var n = 0
        var bytes = 0L
        alleDateien().forEach { if (!it.name.endsWith(".tmp")) { n++; bytes += it.length() } }
        return "{\"dateien\":$n,\"bytes\":$bytes}"
    }

    fun allesLoeschen() {
        abbrechen.set(true)
        try {
            aufraeumer.execute {
                try { ordner.deleteRecursively(); ordner.mkdirs() } catch (_: Throwable) { }
            }
        } catch (_: Exception) {
        }
    }

    private class Eintrag(val datei: File, val zeit: Long, val groesse: Long)

    /** Löscht Bilder älter als 60 Tage und hält den Speicher unter 500 MB (älteste zuerst). */
    fun aufraeumenSpaeter() {
        try {
            aufraeumer.execute {
                try {
                    val jetzt = System.currentTimeMillis()
                    // Zeitstempel einmal lesen – Dateien können sich währenddessen ändern
                    val liste = alleDateien().map { Eintrag(it, it.lastModified(), it.length()) }.filter { e ->
                        val alt = jetzt - e.zeit > HOECHSTALTER_MS || (e.datei.name.endsWith(".tmp") && jetzt - e.zeit > 3_600_000)
                        if (alt) e.datei.delete()
                        !alt
                    }
                    var summe = liste.sumOf { it.groesse }
                    if (summe > MAX_BYTES) {
                        for (e in liste.sortedBy { it.zeit }) {
                            if (summe <= ZIEL_BYTES) break
                            summe -= e.groesse
                            e.datei.delete()
                        }
                    }
                } catch (_: Throwable) {
                    // Aufräumen ist nicht kritisch – beim nächsten Mal erneut
                }
            }
        } catch (_: Exception) {
            // Executor bereits beendet
        }
    }

    fun beenden() {
        abbrechen.set(true)
        aufraeumer.shutdown()
    }
}
