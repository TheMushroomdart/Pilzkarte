package de.pilzkarte.app

import android.Manifest
import android.app.Activity
import android.app.KeyguardManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock

/**
 * Gemeinsamer Zustand beider Bildschirme: Wann war die App zuletzt ganz im Hintergrund?
 * (für die App-Sperre: nach mehr als einer Minute Abwesenheit wird wieder gesperrt)
 */
object AppZustand {
    private var sichtbar = 0
    private var hintergrundSeit = 0L
    var sperreFaellig = false
    /** true, solange unser eigener Entsperr-Dialog die App verdeckt */
    var eigeneAbfrage = false

    fun gestartet(sperrenNachMs: Long) {
        if (sichtbar == 0 && hintergrundSeit > 0 && System.currentTimeMillis() - hintergrundSeit > sperrenNachMs) sperreFaellig = true
        hintergrundSeit = 0
        sichtbar++
    }

    fun gestoppt() {
        sichtbar = maxOf(0, sichtbar - 1)
        if (sichtbar == 0 && !eigeneAbfrage) hintergrundSeit = System.currentTimeMillis()
    }
}

/**
 * Hauptbildschirm: eine WebView mit der Karten-Oberfläche aus den App-Assets.
 *
 * Datenschutz:
 *  - Netzwerkabfragen laufen nur, solange die App sichtbar (und entsperrt) ist. Im Hintergrund
 *    werden JavaScript-Timer angehalten, Datenabfragen bis zur Rückkehr zurückgehalten und
 *    Kartenbilder gar nicht geladen.
 *  - Daten nur von freigegebenen Servern (auch Weiterleitungen); der Standort nur auf Knopfdruck.
 *  - Neutraler User-Agent ohne Gerätemodell, keine Cookies von Dritten.
 *  - Fundorte und Einstellungen nur lokal; Geheimnisse verschlüsselt im Android-Keystore.
 */
class MainActivity : Activity() {

    companion object {
        const val ASSET_HOST = "appassets.androidplatform.net"
        private const val REQ_LOCATION = 42
        private const val REQ_FILE_OPEN = 43
        private const val REQ_FILE_SAVE = 44
        private const val REQ_ENTSPERREN = 45
        const val APP_UA = "PilzKarte/1.4 (Android-App; privat)"
        const val EINSTELLUNGEN = "pilzkarte_einstellungen"
        const val SPERRE_NACH_MS = 60_000L

        /** Server, von denen die Oberfläche Daten abrufen darf (wie ERLAUBTE_HOSTS in app.js) */
        private val ERLAUBTE_HOSTS = setOf(
            "atlas.thuenen.de", "services.bgr.de", "maps.dwd.de", "geoservice.dlr.de", "geodienste.bfn.de",
            "api.open-meteo.com", "api.gbif.org", "nominatim.openstreetmap.org", "api.github.com"
        )
        private val ROUTINE_URL = Regex("^https://api\\.anthropic\\.com/v1/claude_code/routines/[A-Za-z0-9_-]+/fire$")
        private val GEHEIMNIS_NAME = Regex("^[a-z_]{1,40}$")
    }

    private lateinit var web: WebView
    private lateinit var wurzel: FrameLayout
    private lateinit var sperrAnsicht: View
    private lateinit var prefs: SharedPreferences
    private lateinit var einstellungen: SharedPreferences
    private lateinit var tresor: Tresor
    private lateinit var kacheln: Kachelspeicher
    private val netz: ExecutorService = Executors.newFixedThreadPool(6)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var geoCallback: GeolocationPermissions.Callback? = null
    private var geoOrigin: String? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingSaveContent: String? = null
    private var webOk = true

    // Netz-Sperre: Datenabfragen im Hintergrund (oder bei gesperrter App) warten bis zur Rückkehr
    private val netzLock = ReentrantLock()
    private val netzFrei = netzLock.newCondition()
    @Volatile private var paused = false
    private var zerstoert = false
    private val heldRequests = mutableListOf<Pair<Int, Runnable>>()

    // App-Sperre
    private var gesperrt = false
    private var abfrageLaeuft = false
    private var autoAbfrage = false
    private var seiteGeladen = false
    private var vordergrund = false
    private var nachKeyguard: ((Boolean) -> Unit)? = null

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("pilzkarte", Context.MODE_PRIVATE)
        einstellungen = getSharedPreferences(EINSTELLUNGEN, Context.MODE_PRIVATE)
        tresor = Tresor(this)
        kacheln = Kachelspeicher(this, APP_UA)
        kacheln.aufraeumenSpaeter()
        schutzAnwenden()

        web = WebView(this)
        sperrAnsicht = baueSperrAnsicht()
        wurzel = FrameLayout(this)
        wurzel.addView(web, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        wurzel.addView(sperrAnsicht, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(wurzel)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.setGeolocationEnabled(true)
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.userAgentString = neutralUserAgent(s.userAgentString) + " " + APP_UA
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)

        web.addJavascriptInterface(Bridge(), "AndroidBridge")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val uri = request.url
                val host = uri.host?.lowercase()
                if (host == ASSET_HOST) return asset(uri)
                // Im Hintergrund oder gesperrt: nichts aus dem Netz laden (die Karte lädt nach der Rückkehr neu)
                if (paused) return leereAntwort(503, "Paused")
                if (request.method != "GET" || kacheln.frischDauer(host) == null) return null
                return kacheln.abfangen(uri.toString())
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.host == ASSET_HOST) return false
                openUrl(uri.toString(), "")
                return true
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                // Darstellung abgestürzt oder vom System beendet: Bildschirm neu aufbauen statt App-Absturz
                if (webOk) {
                    webOk = false
                    wurzel.removeView(web)
                    web.destroy()
                    recreate()
                }
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                if (hasLocationPermission()) {
                    // retain = false: die Freigabe gilt nur für diese Sitzung
                    callback.invoke(origin, true, false)
                } else {
                    geoOrigin = origin
                    geoCallback = callback
                    requestPermissions(
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                        REQ_LOCATION
                    )
                }
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(fileChooserParams.createIntent(), REQ_FILE_OPEN)
                    true
                } catch (e: ActivityNotFoundException) {
                    fileCallback = null
                    false
                }
            }
        }

        if (sperreAktiv()) {
            // Gesperrt starten: die Karte wird erst nach dem Entsperren geladen
            gesperrt = true
            autoAbfrage = true
            paused = true
            web.visibility = View.INVISIBLE
            sperrAnsicht.visibility = View.VISIBLE
        } else {
            sperrAnsicht.visibility = View.GONE
            ladeSeite()
        }
    }

    private fun ladeSeite() {
        if (seiteGeladen || !webOk) return
        seiteGeladen = true
        web.loadUrl("https://$ASSET_HOST/index.html")
    }

    private fun asset(uri: Uri): WebResourceResponse {
        var path = uri.path?.trimStart('/') ?: ""
        if (path.isEmpty()) path = "index.html"
        return try {
            val type = mimeType(path)
            val enc = if (type.startsWith("text/") || type.endsWith("javascript") || type.endsWith("json")) "utf-8" else null
            WebResourceResponse(type, enc, assets.open(path))
        } catch (e: IOException) {
            leereAntwort(404, "Not Found")
        }
    }

    private fun leereAntwort(status: Int, grund: String) =
        WebResourceResponse("text/plain", "utf-8", status, grund, emptyMap(), ByteArrayInputStream(ByteArray(0)))

    /** Ersetzt Gerätemodell und Android-Version im User-Agent durch neutrale Angaben. */
    private fun neutralUserAgent(ua: String): String =
        ua.replace(Regex("\\(Linux; Android [^)]*\\)"), "(Linux; Android 10; K; wv)")

    private fun hasLocationPermission(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOCATION) {
            val granted = grantResults.any { it == PackageManager.PERMISSION_GRANTED }
            geoCallback?.invoke(geoOrigin, granted, false)
            geoCallback = null
            geoOrigin = null
            if (!granted) Toast.makeText(this, "Ohne Standort-Berechtigung kein GPS in der Karte.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Einfache Ergebnis-Behandlung ohne AndroidX")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_FILE_OPEN -> {
                fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
                fileCallback = null
            }
            REQ_FILE_SAVE -> {
                val content = pendingSaveContent
                pendingSaveContent = null
                val uri = data?.data
                if (resultCode == RESULT_OK && uri != null && content != null) {
                    try {
                        contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
                        Toast.makeText(this, "Datei gespeichert.", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Toast.makeText(this, "Speichern fehlgeschlagen: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
            REQ_ENTSPERREN -> {
                val weiter = nachKeyguard
                nachKeyguard = null
                abfrageBeendet()
                weiter?.invoke(resultCode == RESULT_OK)
            }
        }
    }

    // ---------------- Lebenszyklus ----------------
    override fun onStart() {
        super.onStart()
        AppZustand.gestartet(SPERRE_NACH_MS)
    }

    override fun onStop() {
        AppZustand.gestoppt()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        vordergrund = true
        if (AppZustand.sperreFaellig) {
            AppZustand.sperreFaellig = false
            if (!gesperrt && sperreAktiv()) sperren()
        }
        if (gesperrt) {
            if (autoAbfrage && !abfrageLaeuft) {
                autoAbfrage = false
                mainHandler.post { entsperrenAnfragen() }
            }
            return
        }
        aktivieren()
    }

    override fun onPause() {
        vordergrund = false
        deaktivieren()
        super.onPause()
    }

    private fun aktivieren() {
        if (webOk) {
            web.resumeTimers()
            web.onResume()
        }
        netzFreigeben()
        if (webOk) web.evaluateJavascript("window.onAppResume && window.onAppResume()", null)
    }

    private fun deaktivieren() {
        netzLock.lock()
        try { paused = true } finally { netzLock.unlock() }
        if (webOk) {
            web.evaluateJavascript("window.onAppPause && window.onAppPause()", null)
            web.onPause()
            web.pauseTimers()
        }
        CookieManager.getInstance().flush()
    }

    @Deprecated("Einfache Zurück-Behandlung für alle Android-Versionen")
    override fun onBackPressed() {
        if (gesperrt || !webOk) {
            finish()
            return
        }
        web.evaluateJavascript("(window.handleBack && window.handleBack()) ? 'y' : 'n'") { result ->
            if (result != "\"y\"") {
                @Suppress("DEPRECATION")
                super.onBackPressed()
            }
        }
    }

    override fun onDestroy() {
        netzLock.lock()
        try {
            zerstoert = true
            heldRequests.clear()
            netzFrei.signalAll()
        } finally {
            netzLock.unlock()
        }
        kacheln.beenden()
        netz.shutdownNow()
        if (webOk) {
            webOk = false
            wurzel.removeView(web)
            web.destroy()
        }
        super.onDestroy()
    }

    // ---------------- Netz-Sperre ----------------
    private fun netzFreigeben() {
        val los: List<Runnable>
        netzLock.lock()
        try {
            paused = false
            los = heldRequests.map { it.second }
            heldRequests.clear()
            netzFrei.signalAll()
        } finally {
            netzLock.unlock()
        }
        los.forEach { ausfuehrenJetzt(it) }
    }

    private fun ausfuehren(id: Int, task: Runnable) {
        netzLock.lock()
        try {
            if (paused) {
                heldRequests.add(id to task)
                return
            }
        } finally {
            netzLock.unlock()
        }
        ausfuehrenJetzt(task)
    }

    private fun ausfuehrenJetzt(task: Runnable) {
        try {
            netz.execute(task)
        } catch (_: Exception) {
            // App wird gerade beendet
        }
    }

    /** Wartet, bis die App wieder sichtbar und entsperrt ist. false = abbrechen. */
    private fun warteBisFrei(maxMs: Long): Boolean {
        netzLock.lock()
        try {
            var rest = TimeUnit.MILLISECONDS.toNanos(maxMs)
            while (paused && !zerstoert) {
                if (rest <= 0L) return false
                rest = netzFrei.awaitNanos(rest)
            }
            return !zerstoert
        } catch (_: InterruptedException) {
            return false
        } finally {
            netzLock.unlock()
        }
    }

    // ---------------- App-Sperre & Bildschirmschutz ----------------
    private fun sperreAktiv(): Boolean = einstellungen.getBoolean("sperre", false)

    private fun displaysperreVorhanden(): Boolean =
        (getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isDeviceSecure

    /**
     * Bildschirmschutz (keine Bildschirmfotos, keine Vorschau in der App-Übersicht): auf Wunsch – und
     * bei aktiver App-Sperre bis Android 12 immer, weil sonst die Vorschau die Karte zeigen würde.
     */
    private fun schutzAnwenden() {
        val an = einstellungen.getBoolean("schutz", false) || (sperreAktiv() && Build.VERSION.SDK_INT < 33)
        if (an) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        if (Build.VERSION.SDK_INT >= 33) setRecentsScreenshotEnabled(!sperreAktiv())
    }

    private fun baueSperrAnsicht(): View {
        val dunkel = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val hinten = Color.parseColor(if (dunkel) "#161A16" else "#F6F4EF")
        val schrift = Color.parseColor(if (dunkel) "#E9EDE6" else "#1F2A1F")
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(hinten)
            isClickable = true // Berührungen nicht an die Karte durchreichen
            addView(TextView(context).apply {
                text = "🍄🔒"
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 48f)
                gravity = Gravity.CENTER
            })
            addView(TextView(context).apply {
                text = "PilzKarte ist gesperrt"
                setTextColor(schrift)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                setPadding(0, dp(12), 0, dp(20))
            })
            addView(Button(context).apply {
                text = "Entsperren"
                setOnClickListener { entsperrenAnfragen() }
            })
        }
    }

    private fun sperren() {
        gesperrt = true
        autoAbfrage = true
        // Karte unsichtbar machen: auch Bedienungshilfen und Tastatur erreichen sie nicht mehr
        if (webOk) {
            web.clearFocus()
            web.visibility = View.INVISIBLE
        }
        sperrAnsicht.visibility = View.VISIBLE
    }

    private fun entsperrt() {
        gesperrt = false
        sperrAnsicht.visibility = View.GONE
        if (webOk) web.visibility = View.VISIBLE
        ladeSeite()
        if (vordergrund) aktivieren()
    }

    private fun abfrageBeendet() {
        abfrageLaeuft = false
        AppZustand.eigeneAbfrage = false
    }

    private fun entsperrenAnfragen() {
        if (abfrageLaeuft || !gesperrt) return
        if (!displaysperreVorhanden()) {
            // Ohne Displaysperre (PIN, Muster, Fingerabdruck) ist keine App-Sperre möglich
            einstellungen.edit().putBoolean("sperre", false).apply()
            schutzAnwenden()
            Toast.makeText(this, "App-Sperre ausgeschaltet: Am Handy ist keine Displaysperre mehr eingerichtet.", Toast.LENGTH_LONG).show()
            entsperrt()
            return
        }
        authentifizieren("PilzKarte entsperren") { ok -> if (ok) entsperrt() }
    }

    /**
     * Fragt Fingerabdruck, Gesicht oder die Displaysperre ab. Ab Android 11 über BiometricPrompt,
     * davor (und wenn BiometricPrompt scheitert) über den Bestätigungsbildschirm der Displaysperre.
     */
    private fun authentifizieren(titel: String, ergebnis: (Boolean) -> Unit) {
        if (abfrageLaeuft) return
        abfrageLaeuft = true
        AppZustand.eigeneAbfrage = true
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                BiometricPrompt.Builder(this)
                    .setTitle(titel)
                    .setSubtitle("Fingerabdruck, Gesicht oder Displaysperre")
                    .setAllowedAuthenticators(
                        BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL
                    )
                    .build()
                    .authenticate(CancellationSignal(), mainExecutor, object : BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                            abfrageBeendet()
                            ergebnis(true)
                        }

                        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                            abfrageBeendet()
                            if (errorCode == BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED ||
                                errorCode == BiometricPrompt.BIOMETRIC_ERROR_CANCELED
                            ) {
                                ergebnis(false) // abgebrochen: gesperrt bleiben, „Entsperren“ startet neu
                            } else {
                                // Gerät kann BiometricPrompt nicht anzeigen → Displaysperre direkt abfragen
                                displaysperreAbfragen(titel, ergebnis)
                            }
                        }
                    })
                return
            } catch (_: Exception) {
                abfrageBeendet()
            }
        } else {
            abfrageBeendet()
        }
        displaysperreAbfragen(titel, ergebnis)
    }

    @Suppress("DEPRECATION")
    private fun displaysperreAbfragen(titel: String, ergebnis: (Boolean) -> Unit) {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val i = km.createConfirmDeviceCredentialIntent(titel, "Bitte mit deiner Displaysperre bestätigen")
        if (i == null) {
            // keine Displaysperre eingerichtet – dann gibt es nichts abzufragen
            ergebnis(!km.isDeviceSecure)
            return
        }
        abfrageLaeuft = true
        AppZustand.eigeneAbfrage = true
        nachKeyguard = ergebnis
        try {
            startActivityForResult(i, REQ_ENTSPERREN)
        } catch (e: ActivityNotFoundException) {
            nachKeyguard = null
            abfrageBeendet()
            Toast.makeText(this, "Entsperren nicht möglich.", Toast.LENGTH_LONG).show()
            ergebnis(false)
        }
    }

    /** App-Sperre einschalten – erst nach einer erfolgreichen Bestätigung, damit niemand ausgesperrt wird. */
    private fun sperreEinschalten() {
        authentifizieren("App-Sperre einschalten") { ok ->
            if (ok) {
                einstellungen.edit().putBoolean("sperre", true).apply()
                schutzAnwenden()
            }
            js("window.__sperreErgebnis && window.__sperreErgebnis($ok)")
        }
    }

    // ---------------- Externe Seiten & Apps ----------------
    private fun openUrl(url: String, title: String) {
        val lower = url.lowercase()
        if (lower.startsWith("https://") || lower.startsWith("http://")) {
            startActivity(
                Intent(this, WebActivity::class.java)
                    .putExtra(WebActivity.EXTRA_URL, url)
                    .putExtra(WebActivity.EXTRA_TITLE, title)
            )
        } else {
            openExternal(url)
        }
    }

    private fun starte(intent: Intent, fehlt: String) {
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, fehlt, Toast.LENGTH_LONG).show()
        }
    }

    private fun openExternal(url: String) {
        val uri = Uri.parse(url)
        when (uri.scheme?.lowercase()) {
            // Navigation: du wählst die App (die PilzKarte selbst sendet dabei nichts)
            "geo" -> starte(Intent.createChooser(Intent(Intent.ACTION_VIEW, uri), "Navigieren mit …"),
                "Keine Navigations-App gefunden.")
            // Telefon: Nummer nur vorwählen, anrufen musst du selbst
            "tel" -> starte(Intent(Intent.ACTION_DIAL, uri), "Keine Telefon-App gefunden.")
            "https" -> starte(Intent(Intent.ACTION_VIEW, uri), "Kein Browser gefunden.")
            else -> Toast.makeText(this, "Dieser Link wird nicht geöffnet.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun mimeType(path: String): String = when (path.substringAfterLast('.', "").lowercase()) {
        "html", "htm" -> "text/html"
        "js" -> "application/javascript"
        "css" -> "text/css"
        "json" -> "application/json"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "svg" -> "image/svg+xml"
        "webp" -> "image/webp"
        else -> "application/octet-stream"
    }

    private fun js(code: String) {
        mainHandler.post { if (!isDestroyed && webOk) web.evaluateJavascript(code, null) }
    }

    private fun antwortLesen(conn: HttpURLConnection): Pair<Int, String> {
        val status = conn.responseCode
        val stream = if (status in 200..299) conn.inputStream else conn.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        conn.disconnect()
        return status to body
    }

    /** Schnittstelle, die das JavaScript der Karten-Oberfläche aufruft. */
    inner class Bridge {

        /** HTTP-GET ohne CORS-Beschränkung, nur zu freigegebenen Servern; Ergebnis über window.__httpDone. */
        @JavascriptInterface
        fun httpGet(id: Int, url: String) {
            val uri = Uri.parse(url)
            if (uri.scheme != "https" || uri.host?.lowercase() !in ERLAUBTE_HOSTS) {
                deliver(id, 0, "Server nicht freigegeben")
                return
            }
            ausfuehren(id, Runnable {
                var status = 0
                var body: String
                try {
                    val conn = Netz.oeffnen(url, { it in ERLAUBTE_HOSTS }) { c ->
                        c.connectTimeout = 15000
                        c.readTimeout = 25000
                        c.useCaches = false
                        c.setRequestProperty("User-Agent", APP_UA)
                        c.setRequestProperty("Accept", "application/json, text/plain, */*")
                    }
                    val a = antwortLesen(conn)
                    status = a.first
                    body = a.second
                } catch (e: Exception) {
                    body = e.message ?: "Netzwerkfehler"
                }
                deliver(id, status, body)
            })
        }

        /** Gibt eine zurückgehaltene Anfrage auf, deren Ergebnis die Oberfläche nicht mehr braucht. */
        @JavascriptInterface
        fun cancelRequest(id: Int) {
            netzLock.lock()
            try {
                heldRequests.removeAll { it.first == id }
            } finally {
                netzLock.unlock()
            }
        }

        /**
         * Startet die Claude-Routine (nur auf Knopfdruck). Gesendet werden nur der übergebene Text
         * (Versionsnummer und Datum) und der verschlüsselt gespeicherte Schlüssel – an Anthropic.
         */
        @JavascriptInterface
        fun fireRoutine(id: Int, url: String, text: String) {
            if (!ROUTINE_URL.matches(url)) {
                deliver(id, 0, "Ungültige Adresse")
                return
            }
            ausfuehren(id, Runnable {
                var status = 0
                var body: String
                try {
                    val token = tresor.lesen("routine_token")
                    if (token.isNullOrEmpty()) throw IOException("Kein Schlüssel gespeichert")
                    val payload = JSONObject().put("text", text.take(2000)).toString().toByteArray(Charsets.UTF_8)
                    // keine Weiterleitungen: der Schlüssel geht nur an api.anthropic.com
                    val conn = Netz.oeffnen(url, { it == "api.anthropic.com" }) { c ->
                        c.requestMethod = "POST"
                        c.doOutput = true
                        c.connectTimeout = 15000
                        c.readTimeout = 30000
                        c.useCaches = false
                        c.setRequestProperty("Authorization", "Bearer $token")
                        c.setRequestProperty("anthropic-version", "2023-06-01")
                        c.setRequestProperty("anthropic-beta", "experimental-cc-routine-2026-04-01")
                        c.setRequestProperty("Content-Type", "application/json")
                        c.setRequestProperty("User-Agent", APP_UA)
                        c.outputStream.use { it.write(payload) }
                    }
                    val a = antwortLesen(conn)
                    status = a.first
                    body = a.second
                } catch (e: Exception) {
                    body = e.message ?: "Netzwerkfehler"
                }
                deliver(id, status, body)
            })
        }

        @JavascriptInterface
        fun openWeb(url: String, title: String) {
            mainHandler.post { openUrl(url, title) }
        }

        @JavascriptInterface
        fun openExternal(url: String) {
            mainHandler.post { this@MainActivity.openExternal(url) }
        }

        // ---- lokale Ablage (nur auf diesem Gerät, kein Cloud-Backup) ----
        @JavascriptInterface
        fun storeGet(key: String): String? = prefs.getString(key, null)

        @JavascriptInterface
        fun storeSet(key: String, value: String?) {
            val e = prefs.edit()
            if (value == null) e.remove(key) else e.putString(key, value)
            e.apply()
        }

        /** Löscht alle Daten der App: Ablage, Einstellungen und Geheimnisse. */
        @JavascriptInterface
        fun storeClear() {
            prefs.edit().clear().apply()
            einstellungen.edit().clear().apply()
            tresor.allesLoeschen()
            mainHandler.post {
                schutzAnwenden()
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        /** Datei speichern: der Nutzer wählt selbst den Speicherort (z. B. Downloads). */
        @JavascriptInterface
        fun saveFile(name: String, mime: String, content: String) {
            mainHandler.post {
                pendingSaveContent = content
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType(mime)
                    .putExtra(Intent.EXTRA_TITLE, name)
                try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(intent, REQ_FILE_SAVE)
                } catch (e: ActivityNotFoundException) {
                    pendingSaveContent = null
                    Toast.makeText(this@MainActivity, "Keine Datei-App gefunden.", Toast.LENGTH_LONG).show()
                }
            }
        }

        // ---- App-Infos & Einstellungen ----
        @JavascriptInterface
        fun appInfo(): String = try {
            @Suppress("DEPRECATION")
            val pi = packageManager.getPackageInfo(packageName, 0)
            val code = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else {
                @Suppress("DEPRECATION")
                pi.versionCode.toLong()
            }
            JSONObject().put("versionCode", code).put("versionName", pi.versionName ?: "").toString()
        } catch (e: Exception) {
            "{\"versionCode\":0,\"versionName\":\"?\"}"
        }

        @JavascriptInterface
        fun getSettings(): String = JSONObject()
            .put("lock", sperreAktiv())
            .put("secure", einstellungen.getBoolean("schutz", false))
            .put("lockAvailable", displaysperreVorhanden())
            .toString()

        /**
         * App-Sperre an/aus. Beim Einschalten wird erst eine Bestätigung verlangt; das Ergebnis kommt über
         * window.__sperreErgebnis(ok). Rückgabe false = nicht möglich (keine Displaysperre eingerichtet).
         */
        @JavascriptInterface
        fun setAppLock(on: Boolean): Boolean {
            if (!on) {
                einstellungen.edit().putBoolean("sperre", false).apply()
                mainHandler.post { schutzAnwenden() }
                return true
            }
            if (!displaysperreVorhanden()) return false
            mainHandler.post { sperreEinschalten() }
            return true
        }

        @JavascriptInterface
        fun setSecureScreen(on: Boolean) {
            einstellungen.edit().putBoolean("schutz", on).apply()
            mainHandler.post { schutzAnwenden() }
        }

        @JavascriptInterface
        fun setKeepScreenOn(on: Boolean) {
            mainHandler.post {
                if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }

        // ---- Geheimnisse: setzen und löschen ja, auslesen nie ----
        @JavascriptInterface
        fun setSecret(name: String, value: String): Boolean =
            GEHEIMNIS_NAME.matches(name) && value.length in 1..4000 && tresor.setzen(name, value)

        @JavascriptInterface
        fun hasSecret(name: String): Boolean = GEHEIMNIS_NAME.matches(name) && tresor.vorhanden(name)

        @JavascriptInterface
        fun deleteSecret(name: String) {
            tresor.loeschen(name)
        }

        // ---- Offline-Karten ----
        @JavascriptInterface
        fun cacheInfo(): String = kacheln.info()

        @JavascriptInterface
        fun clearTileCache() {
            kacheln.allesLoeschen()
        }

        @JavascriptInterface
        fun downloadTiles(json: String) {
            val liste = try {
                val a = JSONArray(json)
                (0 until a.length()).map { a.getString(it) }
            } catch (e: Exception) {
                emptyList()
            }
            val urls = kacheln.erlaubteUrls(liste)
            if (urls.isEmpty()) {
                fortschritt(0, 0, 0, true, true)
                return
            }
            // Lädt nur, solange die App sichtbar ist; im Hintergrund pausiert der Download
            val gestartet = kacheln.vorabLaden(urls, { warteBisFrei(6 * 3_600_000L) }) { f, g, fe, ende, ab ->
                fortschritt(f, g, fe, ende, ab)
            }
            if (!gestartet) mainHandler.post {
                Toast.makeText(this@MainActivity, "Es läuft bereits ein Download.", Toast.LENGTH_SHORT).show()
            }
        }

        @JavascriptInterface
        fun cancelDownload() {
            kacheln.abbrechen()
        }

        private fun fortschritt(fertig: Int, gesamt: Int, fehler: Int, beendet: Boolean, abgebrochen: Boolean) {
            js("window.__offlineProgress && window.__offlineProgress($fertig,$gesamt,$fehler,$beendet,$abgebrochen)")
        }

        private fun deliver(id: Int, status: Int, body: String) {
            js("window.__httpDone($id,$status,${JSONObject.quote(body)})")
        }
    }
}
