package de.pilzkarte.app

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Hauptbildschirm: eine WebView mit der Karten-Oberfläche aus den App-Assets.
 *
 * Datenschutz:
 *  - Netzwerkabfragen laufen nur, solange die App im Vordergrund ist. Im Hintergrund
 *    werden JavaScript-Timer angehalten und neue Anfragen bis zur Rückkehr zurückgehalten.
 *  - Der Standort wird nur abgefragt, wenn die Karte ihn anfordert (Knopfdruck).
 *  - Neutraler User-Agent ohne Gerätemodell, keine Cookies von Dritten.
 *  - Gespeicherte Daten (Fundorte, Einstellungen) liegen nur lokal in der App.
 */
class MainActivity : Activity() {

    companion object {
        const val ASSET_HOST = "appassets.androidplatform.net"
        private const val REQ_LOCATION = 42
        private const val REQ_FILE_OPEN = 43
        private const val REQ_FILE_SAVE = 44
        private const val APP_UA = "PilzKarte/1.3 (privat)"
    }

    private lateinit var web: WebView
    private lateinit var prefs: SharedPreferences
    private val executor: ExecutorService = Executors.newFixedThreadPool(6)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var geoCallback: GeolocationPermissions.Callback? = null
    private var geoOrigin: String? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pendingSaveContent: String? = null

    // Anfragen, die im Hintergrund eintreffen, warten bis zur Rückkehr in die App
    private val lock = Any()
    private var paused = false
    private val heldRequests = mutableListOf<Runnable>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("pilzkarte", Context.MODE_PRIVATE)
        web = WebView(this)
        setContentView(web)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.setGeolocationEnabled(true)
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.userAgentString = neutralUserAgent(s.userAgentString) + " " + APP_UA
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, false)

        web.addJavascriptInterface(Bridge(), "AndroidBridge")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val uri = request.url
                if (uri.host != ASSET_HOST) return null
                var path = uri.path?.trimStart('/') ?: ""
                if (path.isEmpty()) path = "index.html"
                return try {
                    val type = mimeType(path)
                    val enc = if (type.startsWith("text/") || type.endsWith("javascript") || type.endsWith("json")) "utf-8" else null
                    WebResourceResponse(type, enc, assets.open(path))
                } catch (e: IOException) {
                    WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                        emptyMap(), ByteArrayInputStream(ByteArray(0)))
                }
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.host == ASSET_HOST) return false
                openUrl(uri.toString(), "")
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                if (hasLocationPermission()) {
                    // retain = false: die Freigabe gilt nur für diese Sitzung
                    callback.invoke(origin, true, false)
                } else {
                    geoOrigin = origin
                    geoCallback = callback
                    requestPermissions(
                        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                        REQ_LOCATION
                    )
                }
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(fileChooserParams.createIntent(), REQ_FILE_OPEN)
                    true
                } catch (e: ActivityNotFoundException) {
                    fileCallback = null
                    false
                }
            }
        }

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState)
        } else {
            web.loadUrl("https://$ASSET_HOST/index.html")
        }
    }

    /** Ersetzt Gerätemodell und Android-Version im User-Agent durch neutrale Angaben. */
    private fun neutralUserAgent(ua: String): String =
        ua.replace(Regex("\\(Linux; Android [^)]*\\)"), "(Linux; Android 10; K; wv)")

    private fun hasLocationPermission(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOCATION) {
            val granted = grantResults.any { it == PackageManager.PERMISSION_GRANTED }
            geoCallback?.invoke(geoOrigin, granted, false)
            geoCallback = null
            geoOrigin = null
            if (!granted) Toast.makeText(this, "Ohne Standort-Berechtigung kein GPS in der Karte.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Einfache Ergebnis-Behandlung ohne AndroidX")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_FILE_OPEN) {
            fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCallback = null
        } else if (requestCode == REQ_FILE_SAVE) {
            val content = pendingSaveContent
            pendingSaveContent = null
            val uri = data?.data
            if (resultCode == RESULT_OK && uri != null && content != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
                    Toast.makeText(this, "Datei gespeichert.", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Speichern fehlgeschlagen: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onPause() {
        synchronized(lock) { paused = true }
        web.evaluateJavascript("window.onAppPause && window.onAppPause()", null)
        web.onPause()
        web.pauseTimers()
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.resumeTimers()
        web.onResume()
        val toRun: List<Runnable>
        synchronized(lock) {
            paused = false
            toRun = heldRequests.toList()
            heldRequests.clear()
        }
        toRun.forEach { executor.execute(it) }
        web.evaluateJavascript("window.onAppResume && window.onAppResume()", null)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    @Deprecated("Einfache Zurück-Behandlung für alle Android-Versionen")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.handleBack && window.handleBack()) ? 'y' : 'n'") { result ->
            if (result != "\"y\"") {
                @Suppress("DEPRECATION")
                super.onBackPressed()
            }
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        web.destroy()
        super.onDestroy()
    }

    private fun openUrl(url: String, title: String) {
        val lower = url.lowercase()
        if (lower.startsWith("http://") || lower.startsWith("https://")) {
            startActivity(
                Intent(this, WebActivity::class.java)
                    .putExtra(WebActivity.EXTRA_URL, url)
                    .putExtra(WebActivity.EXTRA_TITLE, title)
            )
        } else {
            openExternal(url)
        }
    }

    private fun openExternal(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Keine passende App gefunden (z. B. Karten- oder Telefon-App).", Toast.LENGTH_LONG).show()
        }
    }

    private fun mimeType(path: String): String = when (path.substringAfterLast('.', "").lowercase()) {
        "html", "htm" -> "text/html"
        "js" -> "application/javascript"
        "css" -> "text/css"
        "json" -> "application/json"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "svg" -> "image/svg+xml"
        "webp" -> "image/webp"
        else -> "application/octet-stream"
    }

    /** Schnittstelle, die das JavaScript der Karten-Oberfläche aufruft. */
    inner class Bridge {

        /** HTTP-GET ohne CORS-Beschränkung; Ergebnis kommt über window.__httpDone zurück. */
        @JavascriptInterface
        fun httpGet(id: Int, url: String) {
            if (!url.startsWith("https://")) {
                deliver(id, 0, "Nur https erlaubt")
                return
            }
            val task = Runnable {
                var status = 0
                var body: String
                try {
                    val conn = URL(url).openConnection() as HttpURLConnection
                    conn.connectTimeout = 15000
                    conn.readTimeout = 25000
                    conn.useCaches = false
                    conn.setRequestProperty("User-Agent", APP_UA)
                    conn.setRequestProperty("Accept", "application/json, text/plain, */*")
                    status = conn.responseCode
                    val stream = if (status in 200..299) conn.inputStream else conn.errorStream
                    body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                    conn.disconnect()
                } catch (e: Exception) {
                    body = e.message ?: "Netzwerkfehler"
                }
                deliver(id, status, body)
            }
            synchronized(lock) {
                if (paused) {
                    heldRequests.add(task)
                    return
                }
            }
            executor.execute(task)
        }

        @JavascriptInterface
        fun openWeb(url: String, title: String) {
            mainHandler.post { openUrl(url, title) }
        }

        @JavascriptInterface
        fun openExternal(url: String) {
            mainHandler.post { this@MainActivity.openExternal(url) }
        }

        // ---- lokale Ablage (nur auf diesem Gerät, kein Cloud-Backup) ----
        @JavascriptInterface
        fun storeGet(key: String): String? = prefs.getString(key, null)

        @JavascriptInterface
        fun storeSet(key: String, value: String?) {
            val e = prefs.edit()
            if (value == null) e.remove(key) else e.putString(key, value)
            e.apply()
        }

        @JavascriptInterface
        fun storeClear() {
            prefs.edit().clear().apply()
        }

        /** Datei speichern: der Nutzer wählt selbst den Speicherort (z. B. Downloads). */
        @JavascriptInterface
        fun saveFile(name: String, mime: String, content: String) {
            mainHandler.post {
                pendingSaveContent = content
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType(mime)
                    .putExtra(Intent.EXTRA_TITLE, name)
                try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(intent, REQ_FILE_SAVE)
                } catch (e: ActivityNotFoundException) {
                    pendingSaveContent = null
                    Toast.makeText(this@MainActivity, "Keine Datei-App gefunden.", Toast.LENGTH_LONG).show()
                }
            }
        }

        private fun deliver(id: Int, status: Int, body: String) {
            val js = "window.__httpDone($id,$status,${JSONObject.quote(body)})"
            mainHandler.post { if (!isDestroyed) web.evaluateJavascript(js, null) }
        }
    }
}
