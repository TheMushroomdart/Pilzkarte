package de.pilzkarte.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Verschlüsselte Ablage für Geheimnisse (z. B. den Schlüssel der Claude-Routine).
 * Der AES-Schlüssel liegt im Android-Keystore und kann das Gerät nicht verlassen.
 * Die Karten-Oberfläche kann Geheimnisse nur setzen und löschen, aber nie auslesen.
 */
class Tresor(context: Context) {

    private val prefs = context.getSharedPreferences("pilzkarte_tresor", Context.MODE_PRIVATE)
    private val alias = "pilzkarte_tresor_v1"

    private fun schluessel(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(alias, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return kg.generateKey()
    }

    fun setzen(name: String, wert: String): Boolean = try {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, schluessel())
        val geheim = c.doFinal(wert.toByteArray(Charsets.UTF_8))
        prefs.edit().putString(
            name,
            Base64.encodeToString(c.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(geheim, Base64.NO_WRAP)
        ).apply()
        true
    } catch (e: Exception) {
        false
    }

    /** Nur für den nativen Teil der App (z. B. den Routine-Aufruf). */
    fun lesen(name: String): String? {
        val s = prefs.getString(name, null) ?: return null
        return try {
            val teile = s.split(":", limit = 2)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, schluessel(), GCMParameterSpec(128, Base64.decode(teile[0], Base64.NO_WRAP)))
            String(c.doFinal(Base64.decode(teile[1], Base64.NO_WRAP)), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * true, wenn das Geheimnis gespeichert ist UND entschlüsselt werden kann. Ist der Keystore-Schlüssel
     * verloren (z. B. nach einem Geräteumzug), wird der unbrauchbare Eintrag entfernt.
     */
    fun vorhanden(name: String): Boolean {
        if (!prefs.contains(name)) return false
        if (lesen(name) != null) return true
        loeschen(name)
        return false
    }

    fun loeschen(name: String) {
        prefs.edit().remove(name).apply()
    }

    fun allesLoeschen() {
        prefs.edit().clear().apply()
        try {
            KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.deleteEntry(alias)
        } catch (_: Exception) {
        }
    }
}
