plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "de.pilzkarte.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "de.pilzkarte.app"
        minSdk = 26
        targetSdk = 34
        // Build-Nummer von GitHub, damit jede neue APK als Update erkannt wird
        val run = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
        versionCode = run
        versionName = "1.0.$run"
    }

    // Fester Schlüssel, damit spätere Versionen einfach über die alte installiert werden können
    signingConfigs {
        create("pilz") {
            storeFile = file("pilzkarte.keystore")
            storePassword = "pilzkarte"
            keyAlias = "pilzkarte"
            keyPassword = "pilzkarte"
        }
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("pilz")
        }
        getByName("debug") {
            signingConfig = signingConfigs.getByName("pilz")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
